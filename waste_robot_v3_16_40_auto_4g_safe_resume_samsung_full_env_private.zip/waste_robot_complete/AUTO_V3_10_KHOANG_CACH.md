> Tài liệu lịch sử trước V3.12. Với bản hiện tại, đọc README_CHAY_TRUOC.md và TINH_TOAN_V3_12.md.

# V3.10 — bước hạ 50 µs, dừng bánh theo khoảng cách cm

## Những thay đổi chính

- Mỗi lần quan sát xong, tay hạ S2 tối đa **50 µs**, không tự giảm về 5 µs khi gần vùng mờ. `motion.arm_step_us=50`, `visibility.min_step_us=50`, `control.s2_step_us=50`.
- Nếu bước 50 µs dự đoán làm vật ra khỏi vùng quan sát, robot giữ chờ. Bước cuối được ngắn hơn để dừng đúng giới hạn S2, không vượt giới hạn. Vẫn kiểm tra D19, giữ bánh đứng yên khi tay hạ và quan sát lại sau từng bước.
- Khi bật `distance.enabled`, mốc đáy 54%, rộng/cao bbox **không còn quyết định đã đủ gần**. Bánh chỉ dừng để chuyển tay khi khoảng cách đo theo mặt sàn nằm trong vùng dừng đã lưu và căn ngang đủ ảnh ổn định.
- Bánh vẫn dừng giữa mỗi nhịp để nhận ảnh; các giới hạn tầm nhìn, bước tiến tối đa, cảm biến và STOP vẫn có hiệu lực. “Tiếp tục tiến” không có nghĩa là chạy xuyên qua vùng mất tầm nhìn.

## Khoảng cách được đo từ đâu?

Khoảng cách hiển thị là **Y trên mặt sàn, tính từ một mốc cố định ở mép trước xe đến điểm chân chai nhìn thấy**, không phải khoảng cách xiên 3D từ ống kính đến thân chai. Chọn mốc trên xe rồi chiếu thẳng xuống sàn; trục X ngang xe (phải dương), Y về phía trước xe.

Camera một mắt không tự biết đơn vị cm nếu chưa có số đo thật. Bộ giấy 17 cm cũ có gốc ở giấy, chưa phải gốc xe, chưa có vị trí gắp, ảnh gốc 1920×1080 khác hình học luồng 640×480 hiện tại và chưa được kiểm chứng độc lập. Bản này giữ bộ cũ làm tham khảo, không dùng nó để tự gán khoảng cách.

Giá trị là ước lượng có hiệu chuẩn, không phải số đo từ cảm biến đo khoảng cách. Sai số hiển thị dùng giới hạn kiểm chứng cộng ảnh hưởng thử ±2 pixel ở chân box; không phải khoảng tin cậy thống kê hoặc bảo đảm sai số trong mọi tình huống. Chân chai bị che, chai nằm trên vật khác, mặt sàn dốc hoặc nhận diện sai thì phép đo này không hợp lệ.

## Cập nhật từ bản đang dùng

1. STOP, tắt Python. Sao lưu thư mục hiện tại.
2. Cập nhật các file mã Python mới; giữ `.env`, `robot_config.json`, `auto_config.json` đã chỉnh của bạn.
3. Trong thư mục `python`, chạy `python upgrade_v310.py`. Lệnh chỉ cập nhật bước tay và thêm điều kiện khoảng cách; tự lưu `auto_config.before_v310.json`, không chạy cơ khí. Nếu dùng AUTO_CONFIG ở chỗ khác, chạy `python upgrade_v310.py --config DUONG_DAN_FILE`.
4. Chạy `python main.py`. Để đo cm cần USB local: `LIVEKIT_PUBLISHER=1`, camera index đúng như khi hiệu chuẩn.
5. Mở http://127.0.0.1:8766, làm mục “Khoảng cách cm để dừng bánh”. Bản mới cố ý chưa cho START AUTO theo cm nếu chưa có hiệu chuẩn hợp lệ hoặc chưa đo khoảng dừng. MANUAL vẫn dùng để chuẩn bị.

Không cần nạp lại firmware nếu đã dùng firmware V3.9 có `smooth_protocol=1`.

## Đo một lần trên robot thật

1. Ở MANUAL, đưa tay về SEARCH đã lưu, dừng hẳn bánh/tay. Giữ đúng camera, độ phân giải/tỷ lệ, zoom và tư thế này trong quá trình đo và tiếp cận.
2. Đặt các dấu có tâm rõ trên **cùng mặt sàn**, ít nhất 4 dấu FIT bao quanh vùng từ xa tới sát vùng sẽ gắp. Đo tọa độ X,Y bằng thước so với mốc trước xe. Đặt thêm ít nhất 2 dấu CHECK nằm bên trong vùng đó; đo riêng và không tái dùng điểm FIT.
3. Chụp bằng nút “Chụp ảnh SEARCH để chọn dấu sàn”. Nhấn từng dấu trong ảnh, nhập X,Y cm, chọn FIT hoặc CHECK rồi Thêm điểm. Không chọn tâm chai hoặc chi tiết trên kẹp. Nên chuẩn bị các số đo trước; ảnh lưu có hiệu lực 5 phút.
4. Xác định khoảng dừng bằng thử MANUAL: đưa chai tới vị trí mà kẹp thực sự có thể gắp khi xe đứng yên; đọc khoảng Y của chân chai từ mốc trước xe. Nhập số này vào “Khoảng dừng Y”. Không mặc định 10/20/30 cm vì chưa biết tầm gắp robot của bạn.
5. Dung sai mặc định ±3 cm, sai số kiểm chứng tối đa 2 cm; dung sai phải lớn hơn sai số. Đây là thông số để hiệu chỉnh theo cơ khí, không xác nhận tầm gắp. Khoảng dừng phải nằm trong vùng khoảng cách FIT đã đo.
6. Xác nhận điểm sàn, bấm “Kiểm chứng và bật dừng theo cm”. Không đạt sai số hoặc thiếu điểm → từ chối lưu. Lưu không điều khiển motor/servo.
7. Thử thêm vị trí độc lập bằng thước trước khi START: xem khoảng Y trong log khi AUTO quan sát; giữ STOP sẵn để dừng nếu mốc xe/ảnh bị đặt sai.

## Luồng sau hiệu chuẩn

SEARCH → khóa chai và phân loại → xoay BIN với nắp đóng → lấy đáy giữa bbox làm điểm chân chai trên sàn → đổi sang X,Y cm trong vùng đã đo.

- Xa hơn vùng dừng: căn ngang rồi tiến từng nhịp. Gần vùng dừng thì nhịp tiến ngắn hơn.
- Vào vùng dừng, kể cả dự phòng sai số, và căn ngang ổn định: dừng bánh → hạ S2 50 µs → quan sát lại → D19 xác nhận → kẹp/nâng/thả như trước.
- Chai đã gần hơn vùng dừng, chân chai ra ngoài vùng FIT, camera đổi tỷ lệ hoặc vật bị che trước khi đủ khoảng cách: giữ chờ, không tự lùi/tiến mù và không coi đã tới nơi.
- Tay đã hạ: không tiếp tục trả số cm từ hiệu chuẩn SEARCH. Log/telemetry và video chỉ hiện số cm ở lần quan sát bánh tương ứng; xóa số cũ khi robot chuyển động/chuyển giai đoạn.

Ví dụ định dạng log (số minh họa, không phải cấu hình đã đo cho robot của bạn): `cách mốc trước xe ... cm (±...); dừng ... cm`. Trường gửi app: `distance_mode=floor_cm`, `distance_cm`, `distance_uncertainty_cm`. App đang dùng vẫn nhận trạng thái và video; không triển khai lại app trong bản ZIP này.

Camera bỏ đường chuyển tay 54% khi chế độ cm bật, thay bằng chỉ dẫn dừng theo cm và đường chiếu vị trí dừng sau khi đã lưu hiệu chuẩn. Mốc xanh lá vẫn là vùng tâm mục tiêu, không phải box vật. Không vẽ box nhận diện.

Nếu muốn quay lại logic ảnh V3.9 để thử MANUAL/AUTO cũ, có thể đặt `distance.enabled=false`; khi đó không có điều kiện dừng theo cm. Không nhầm chế độ này với AUTO đã hiệu chuẩn khoảng cách.

Chưa kiểm thử trên robot thật; cần số đo mốc sàn và tầm gắp của chính robot để bật chế độ cm.
