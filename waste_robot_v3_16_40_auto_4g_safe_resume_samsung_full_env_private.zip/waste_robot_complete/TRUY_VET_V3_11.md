> Tài liệu lịch sử trước V3.12. Với bản hiện tại, đọc README_CHAY_TRUOC.md và TINH_TOAN_V3_12.md.

> LỊCH SỬ V3.11: hướng dẫn ghi mốc SEARCH bên dưới đã được thay thế trong V3.11.1 bởi ảnh gắp 27 cm được người dùng xác nhận. Xem README_CHAY_TRUOC.md. Ma trận giấy gốc vẫn được lưu, không dùng cho tư thế tay đã hạ.

# Truy vết và phép tính V3.11

## Dữ liệu đã tìm lại và dùng

| Dữ liệu | Giá trị | Nguồn / cách dùng |
|---|---|---|
| Giấy sàn | 17 × 17 cm | JSON hiệu chuẩn cũ, không giả định kích thước chai |
| Ảnh ma trận cuối | 1920 × 1080 px | Bản JSON có ma trận đầy đủ; bản nháp 1649 × 928 không dùng trộn |
| Góc giấy TL/TR/BR/BL | (816,606), (1007,594), (1050,711), (838,737) | Suy từ đường viền vẽ tay, chưa kiểm chứng độc lập |
| Ống kính → tâm giấy | 92–93 cm | Số đo người dùng, là đoạn xiên |
| Camera SEARCH cao | 64 cm | Số đo người dùng |
| Trục S2 cao | 42 cm | Số đo người dùng |
| Camera theo tay / lệch vuông góc | 22 / 7 cm | Dữ liệu cơ khí; chưa đủ xác định dấu và hướng trục |
| Camera → kẹp | 9 cm | Lưu làm tham khảo |
| Góc camera được báo | 60° | Chưa rõ đo so với trục nào; không coi là nội thông số K hoặc extrinsic |
| SEARCH | P1=1300, P10=950, P11=1250, D2=2100, D3=600 µs | Dữ liệu đã chốt từ lần chạy trước |
| Đích gắp mới | P1=2310, P10=650 µs | Số đo mới của người dùng; thay mặc định P1=2900 |
| Tầm gắp mới | 27 cm | Hình chiếu trục S2 → tâm chai; không phải mép trước xe |
| IR | D19 gắp/giữ; D18 nhận rác sau | Giữ luồng riêng, không đổi firmware |
| Camera | USB index 0 | Lần chạy thành công gần nhất; sửa trong robot_params.py |

Nguồn đối chiếu: bộ ZIP V3.10, bộ `waste_robot_camera_calibration_17cm_preliminary.zip`,
`waste_robot_search_floor_calibration_preliminary.json`, tài liệu `Văn bản đã dán (1).txt` và các ảnh robot người dùng gửi.
Các file ma trận gốc trong `calibration_reference` được giữ làm nguồn tham chiếu.
`calibration_reference/paper_17cm_overlay.jpg` là ảnh kiểm tra đã tạo trước đây, không phải ảnh USB ở mốc gắp 27 cm.

## Ma trận pixel → cm ở hệ tờ giấy

H =
```
[ 0.123560389262  -0.020750599723  -88.250414205085 ]
[ 0.014031921331   0.223341414521 -146.794945006252 ]
[-0.000581698978   0.001664403481    1.000000000000 ]
```
Với ảnh cùng trường nhìn và tỉ lệ, lấy u0=u*1920/W, v0=v*1080/Hanh.
Tính q=H·[u0,v0,1], sau đó X=q0/q2, Y=q1/q2.
Tâm hình vuông (8.5,8.5) cm ánh xạ về (931.545,657.847) px.
Điểm chuẩn (928,661) px trả khoảng (8.14,8.88) cm trong hệ giấy.
Không có một tỉ lệ cm/pixel cố định cho toàn ảnh phối cảnh.

Từ Pythagore: khoảng sàn hình chiếu CAMERA → tâm giấy = sqrt(L²−64²)
= 66.09–67.48 cm, với L=92–93 cm. Đây không phải khoảng S2 → giấy.
Chỉ biết đoạn này và 27 cm chưa xác định được phép tịnh tiến/đổi trục từ gốc giấy sang gốc S2.
Ba ảnh chụp bên ngoài không thuộc hệ pixel camera USB, không dùng thay tọa độ USB.

## Quỹ đạo xung mới

P1(t)=1300+1010t; P10(t)=950−300t, t từ 0 đến 1.
Suy ra P10(P1)=950−300(P1−1300)/1010; làm tròn về µs nguyên.
P11=1250 và D2=2100 giữ nguyên. P1 tăng danh định 50 µs mỗi lần quan sát:
21 bước, bước cuối 2300→2310 là 10 µs; không vượt 2310.
Khi nâng sau gắp, P1/P10 chạy ngược cùng đường; không nhảy riêng P1 về SEARCH trong khi P10 còn 650.

Hai đầu là xung đã có số đo; các điểm giữa là nội suy lệnh.
Không gọi đó là quỹ đạo đầu kẹp đã đo, không quy xung thành góc S2 từ các góc 195°/90° cũ,
vì bộ khớp P10 đã thay đổi.

## Khi nào hệ thống dùng cm để dừng bánh?

Chưa có `grasp_reference.py`: cấu hình khởi động hợp lệ, AUTO tương đối chạy được;
không xuất con số S2 giả. Box cần đồng thời qua điều kiện ảnh và tối thiểu rw=8%, rh=12%.
Đây là ngưỡng thử để chặn trường hợp rw=4% trong log, có thể sửa trực tiếp; không phải đo tầm gắp.
Khi vật bị che hoặc không có phản hồi, AUTO giữ tại chỗ dù file cấu hình đủ.

Có mốc 3 ảnh USB tại vị trí 27 cm: điểm chân box (giữa cạnh dưới) được đặt tại (0,27) cm;
ma trận giấy cho thang đo cục bộ, chiều X lấy từ đạo hàm ảnh ngang và Y vuông góc hướng lên ảnh.
Chỉ dùng trong vùng nối từ giấy tới mốc gắp; kiểm tra SEARCH, camera index, tỷ lệ ảnh và đường chân trời.
Dừng khi khoảng cách vào dải cấu hình và ngang ổn định; đáy box 54% không thay thế điều kiện cm.

Đây vẫn là ước lượng sơ bộ: điểm chân box không luôn là hình chiếu tâm chai chính xác,
hướng trục lấy xấp xỉ, viền giấy cũ vẽ tay và chưa có mẫu đo kiểm độc lập.
`max_error_cm=2` ở chế độ này chỉ là phần dự phòng giả định cho điều khiển, không phải sai số đã đo.
Log/video ghi rõ ESTIMATE/ƯỚC LƯỢNG; không trình bày ±2 cm là bảo đảm.
Nếu không thấy chân chai, ngoài vùng hoặc camera đổi tư thế thì giữ robot; không tái dùng cm SEARCH lúc hạ tay.

## Thay đổi và phần giữ lại

- Một nguồn tham số: `python/robot_params.py`; đọc lại ở START, nguồn lỗi không bị lặng lẽ thay bằng dữ liệu cũ.
- JSON vẫn được hỗ trợ cho người dùng chủ động chỉ định đường dẫn cũ.
- Giao diện camera vẫn vẽ mốc, không vẽ box; ảnh Modal và ảnh ghi mốc vẫn nguyên bản.
- Giữ khóa mục tiêu, xác nhận nhiều ảnh, STOP/hủy lệnh, giới hạn khớp, D19 và luồng D18.
- Phân loại → đóng nắp/xoay BIN → gắp/nâng/đưa tới thả → mới mở nắp.
- Không có firmware thay đổi. Các kết quả kiểm thử là mô phỏng/ngoại tuyến, chưa thử trên robot thật.

Tài liệu kỹ thuật đối chiếu: https://docs.opencv.org/4.13.0/d9/dab/tutorial_homography.html
