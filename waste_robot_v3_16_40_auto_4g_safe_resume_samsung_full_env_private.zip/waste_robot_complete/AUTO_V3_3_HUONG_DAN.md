> Tài liệu lịch sử trước V3.12. Với bản hiện tại, đọc README_CHAY_TRUOC.md và TINH_TOAN_V3_12.md.

# Waste Robot V3.8.1 — tiến gần bằng Mecanum rồi mới hạ tay

## Điểm thay đổi

Vật gần giữa ảnh không còn đủ điều kiện để hạ tay. Mặc định approach.enabled=true trong auto_config.json mới. Bánh tiến gần ở tư thế SEARCH, đạt mốc gần rồi đứng yên; sau đó mới hạ S2. Không có chuyển động bánh sau khi bắt đầu hạ trong luồng mới.

## Giai đoạn 1: bánh tiến gần, tay giữ SEARCH

1. Đóng nắp, mở kẹp, về SEARCH: P1=1300, P10=950, P11=1250, D2=2100, D3=600 µs.
2. D19 phải chưa thấy vật. Lấy ảnh mới gửi Modal. Chưa có vật thì đứng yên chờ, không tự chạy tìm khắp phòng.
3. Phân loại và xoay P9 tới ngăn với nắp đóng: 1 tái chế=2350, 2 hữu cơ=1000, 3 nguy hại=1450, 4 khác=1900 µs.
4. Căn ngang: tâm bbox về 50% chiều rộng, sai số ±3%. Lệch ngang thì chạy LEFT/RIGHT, mỗi nhịp 100 ms; học chiều bù từ dịch ảnh sau nhịp ngang.
5. Khi đã căn ngang nhưng vật còn xa, chạy FORWARD 120 ms ở PWM20, dừng XM, chờ đứng yên rồi lấy ảnh mới. Không dùng lệch dọc để tự đổi thành BACK. Không giữ motor chạy trong lúc chờ HTTP Modal.
6. Đủ gần tương đối khi một trong các điều kiện đạt: đáy bbox ≥60% chiều cao ảnh; rw ≥40%; rh ≥70%. Đồng thời tâm ngang phải trong vùng cho phép qua 2 ảnh liên tiếp. Bánh dừng rồi mới chuyển giai đoạn 2.

Với ảnh 640×480: đường giữa x=320; vùng ngang khoảng x=301–339; mốc đáy y=288. Đáy bbox là y2, không phải tâm bbox. Các mốc co giãn theo độ phân giải, không phải số cm hoặc chứng minh vật đã nằm trong tầm kẹp. Đáy bbox chỉ là xấp xỉ điểm tiếp xúc sàn khi vật đứng trên sàn và nhìn rõ chân vật.

Khi target_lock bật, xét mức tăng rw/rh/đáy cộng dồn trên nhóm 5 nhịp tiến, dùng trung vị hai mẫu đầu và hai mẫu cuối để giảm dao động box. Chênh ít nhất 0,3% theo một đại lượng mới có bằng chứng tiến triển. Tới mốc gần thì ưu tiên dừng bánh/chuyển sang tay, không giữ vì tiêu chí tiến triển. Nếu cả nhóm không có tiến triển thì giữ vị trí và báo kiểm tra motor/PWM; không tự tăng tốc. Chế độ cũ target_lock tắt vẫn kiểm tra từng nhịp như trước. Tối đa 40 nhịp tiến, 25 nhịp ngang. Nếu vật mất hoặc D19 xuất hiện trong lúc bánh tiếp cận thì giữ vị trí, không tự hạ tay.

## Giai đoạn 2: bánh đứng yên, hạ tay

S2 hạ 20 µs mỗi bước tới tối đa grasp_final_s2_us=2900. P10/P11/D2 giữ nguyên SEARCH. Sau mỗi bước, nhận diện lại để biết vật dịch trên ảnh. Điểm tham chiếu ban đầu vẫn 50%/50%, sai số ngang ±3%, dọc ±8%.

- Khi vật đã trong vùng qua 2 ảnh, ghi mốc căn hiện tại. Nếu D19 phát hiện liên tục 300 ms thì đóng kẹp.
- Nếu D19 xuất hiện giữa hai bước, chỉ dùng mốc căn hợp lệ mới nhất để xác nhận; không hạ thêm trong lúc chờ.
- Khi ảnh chưa vào vùng mà D19 thấy vật, hoặc lệch ngang >6%, giữ vị trí. Bánh không chạy để sửa khi tay đang thấp.
- Khi tới giới hạn 2900 µs, không ra lệnh hạ tiếp. Có mốc căn hợp lệ thì đứng yên chờ D19 tối đa 2 giây; không đủ điều kiện thì giữ vị trí.
- rw≥60% hoặc bbox sát/chạm vùng mép 1%: dừng căn ảnh, giữ tay/bánh, chỉ xét mốc căn trước và D19 như V3.6. Không có mốc căn hợp lệ thì không gắp.

Với target_lock.enabled=true, các giới hạn cơ khí chuyển auto_hold: giữ xung servo, bánh đứng yên, AUTO vẫn giữ quyền điều khiển; không xử lý chuyển động D18 trong khi giữ. STOP rồi chuyển MANUAL để kiểm tra. Với chế độ cũ target_lock.enabled=false vẫn dùng auto_near_hold và cần START lại. STOP/mất kết nối dùng cơ chế khẩn cấp và có thể tắt xung.

## Gắp và thả

Đóng kẹp D3=1400 → nâng S2 về SEARCH → D19 phải còn hiện diện 300 ms → PLACE (P10=1750, P11=1100, P1=1300, D2=2100) → kiểm tra hiện diện → mở nắp P4=1600 → mở kẹp D3=600 → IR hết thấy vật → rút tay → đóng nắp P4=500.

Các tư thế/xung là lệnh, không phải phản hồi vị trí thực. IR báo hiện diện, không đo lực kẹp.

## Các tham số approach

| Tham số | Mặc định trong gói | Ý nghĩa |
|---|---|---|
| enabled | true | Bật luồng hai giai đoạn, cần mode relative |
| target_x_norm | 0.50 | Tâm ngang cần căn |
| x_tolerance_norm | 0.03 | Sai số ngang lúc bánh chạy |
| stop_bottom_norm | 0.78 | Mốc đáy bbox để dừng tiến |
| stop_rw / stop_rh | 0.40 / 0.70 | Mốc kích thước để dừng tiến sớm |
| forward_ms / lateral_ms | 120 / 100 | Thời gian mỗi nhịp tiến/ngang |
| max_forward_steps / max_lateral_steps | 40 / 25 | Giới hạn số nhịp |
| max_no_progress | 5 | Số nhịp liên tiếp không phản hồi trước khi giữ |
| min_progress_norm | 0.003 | Mức dịch ảnh/tăng kích thước tối thiểu |
| arm_x_tolerance_norm | 0.06 | Lệch ngang tối đa trong lúc hạ tay |

PWM dùng control.speed=20. Các thời gian chờ và giới hạn model vẫn dùng control. Không có quy đổi PWM/nhịp chạy sang cm. Dùng auto_config.json mới; file cũ thiếu approach mặc định giữ đường chạy cũ để tương thích.

## Khóa vật qua nhiều box

Mặc định target_lock.enabled=true. Tên và BIN không dùng để quyết định danh tính vật. So mọi box với tham chiếu đã khóa theo IoU, tâm, tỷ lệ diện tích và histogram HSV từ đúng ảnh gửi Modal. Không có descriptor màu thì chỉ chấp nhận box còn giao nhau. Nếu hai box có điểm so khớp gần nhau, giữ chờ trong AUTO, không chọn theo thứ tự trả về. Các ngưỡng chỉ là giá trị thử ban đầu.

Lần đầu chọn vật gần tâm ảnh nhất; hai vật gần tâm tương đương thì chờ cho rõ. Cần 3 ảnh có cùng BIN để chốt phân loại trước khi bánh/tay tiếp cận. Sau đó giữ BIN đã chốt cho cả lượt, kể cả Modal đổi tên/ngăn. Log auto_target_observe có detections[], observed_bin và bin đã chốt để đối chiếu. Nếu phân loại đầu sai, STOP và xác nhận lại; code không tự đổi ngăn giữa lượt.

Mất dấu/box không khớp/ảnh Modal quá cũ/lỗi mạng Modal tạm thời: XM, giữ tay, auto_reacquire nhưng auto_running=true. Không quay xe hoặc hạ tay để dò mù. Nhận lại đúng tham chiếu qua 2 ảnh liên tiếp mới tiếp tục cùng bước còn dở. Thời gian chờ xác nhận không tính vào hạn chu kỳ; số nhịp bánh vẫn giữ nguyên. Sau 30 giây không xác nhận lại, tham chiếu hết hạn: giữ chờ tới khi người dùng STOP rồi START; không tự bỏ khóa để chọn vật khác. D18 vẫn có thể ngắt chu kỳ tiếp cận theo ưu tiên phía sau; sau lượt REAR sẽ tìm vật phía trước từ đầu như trước.

Khi target_lock.enabled=false, tracking.allow_label_variation và ngưỡng nhảy cũ vẫn áp dụng để tương thích cấu hình cũ.


## D18 phía sau

D18 LOW → xếp yêu cầu → dừng bánh/rút S2/đóng nắp → REAR → chờ 700 ms → 2 ảnh cùng nhãn/ngăn trong tối đa 4 lần → xoay ngăn → mở nắp → chờ tối thiểu 1500 ms và D18 hết phát hiện liên tục 500 ms → đóng nắp → SEARCH.

D18 phải còn thấy vật trước khi xoay và mở. Quá 12 giây mà chưa đủ điều kiện đóng thì dừng. Khi đang mang vật phía trước, chờ thả xong rồi xử lý D18. Khi đang tìm/tiến/hạ trước gắp, chuyển qua D18 tại điểm kiểm tra và tìm lại vật phía trước sau đó. START AUTO bật D18; DỪNG tắt cả hai. Có thể bật riêng tại trang 8766.

## Hiệu chuẩn và camera

Camera hiện chọn trực tiếp index 0 theo log thử thành công. Giữ file hiệu chuẩn giấy 17×17 cm, ảnh gốc 1920×1080 và ma trận pixel→sàn trong calibration_reference. Hiệu chuẩn đó vẫn PRELIMINARY_NOT_VALIDATED, chưa có điểm gắp/điểm dừng trong hệ robot; feed 640×480 cũng chưa xác nhận crop/resize so với ảnh gốc. Luồng mặc định này không tự dùng ma trận sơ bộ để ra lệnh cm. Không coi 92–93 cm từ ống kính đến giấy là khoảng cách dừng của xe.

Trang http://127.0.0.1:8766 cho chỉnh mốc tiếp cận, PWM, theo dõi vật, vùng ảnh, giới hạn S2 và near. Lưu khi AUTO dừng, hiệu lực ở lần START tiếp theo. Chọn chế độ calibrated trong mục nâng cao sẽ tắt approach mới; lúc đó dùng quy trình mốc cũ.

Mặc định target_lock.continuous_auto=true: sau mỗi lượt vẫn trong AUTO, không giới hạn bởi repeat/max_cycles. Muốn thử một lượt, đặt continuous_auto=false và repeat=false trước khi START. Chưa chạy bản V3.8 trên robot/camera/Modal thật của bạn. Xem MODAL_BOX_V3_8.md và README_CHAY_TRUOC.md để kiểm tra box trên camera.

Mốc đáy 60% ở V3.8.1 được chọn để thử theo ảnh càng che phần dưới và log vật dừng quanh 60–61%; chưa được hiệu chuẩn tầm gắp. Video có ô SNAPSHOT với tuổi ảnh để xem box trên đúng ảnh đã gửi Modal khi kết quả về chậm. Box lớn trên live vẫn hết hạn sau 2 giây hoặc bị xóa khi chuyển động. Xem README_CHAY_TRUOC.md để áp dụng đúng auto_config.json mới.
