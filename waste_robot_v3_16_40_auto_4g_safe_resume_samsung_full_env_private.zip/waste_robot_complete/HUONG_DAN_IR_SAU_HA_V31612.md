# V3.16.12 — Hạ hết rồi kiểm tra IR

## Trình tự AUTO hiện tại

1. Camera căn vật như trước; VL53L1X hợp lệ **200–250mm** cho phép chuyển sang vị trí gắp.
2. Bánh dừng. Python hạ tay theo toàn bộ các bước trên quỹ đạo đã lưu, tới **P1/S2=2310us, P10/S1=650us**. Trong đoạn hạ cuối, D19 báo vật không làm dừng giữa đường và không cho đóng kẹp sớm.
3. Chờ các lệnh di chuyển hoàn tất và thời gian ổn định đã cấu hình. Đọc trạng thái mới, kiểm tra cặp xung cuối rồi mới xét D19.
4. Nếu D19 activeLOW ổn định300ms: cho phép chu trình xoay kẹp (nếu đã hiệu chuẩn/bật), đóngD3=2000us, nâng và thả như trước.
5. Nếu D19 chưa nhận: tiến một nhịp **160ms thực thi** (ramp80+80), dừng, chờ250ms rồi kiểm tra lại. Nếu D19 nhận giữa nhịp, bánh phanh sớm. Không đóng kẹp khi chưa có xác nhậnIR.
6. Giới hạn mặc định12 nhịp cuối hoặc15giây; hết giới hạn thì giữ chờ, không đóng kẹp. STOP, mất USB và quyền điều khiển vẫn chặn chuyển động.

## Phạm vi thay đổi

- Sửa `python/box_tof_flow.py`: ưu tiên khoảng cách VL53 đã đủ trước kiểm tra D19 sớm, bỏ dừng D19 giữa các bước hạ cuối, chỉ bật bước xétIR sau khi trạng thái xác nhận tay đã tới cặp xung cuối.
- `python/auto_controller.py` đặt lại cờ hiển thị xétIR khi bắt đầu lượt mới.
- **Giữ bảo vệ IR cho bánh trước khi đủ khoảng cách**, kiểm tra IR ở SEARCH, cảm biếnD18, giới hạn quỹ đạo và STOP. Thay đổi này không vô hiệu hóa toàn bộ cảm biếnIR của robot.
- Trạng thái khớp do firmware trả về là xung lệnh; servo thường không có phản hồi vị trí thật. Cặp xung đúng và hết thời gian chờ không chứng minh cơ khí không bị kẹt.

## Cài đặt

- Giải nén toàn bộ ZIP vào thư mục mới; dừng Python cũ và chạy Python ở thư mục mới.
- Nếu đã nạp firmwareV3.16.11 với ROI10×10 và servoquàD4, không cần nạp lại vì firmware không đổi trong lần sửa này. Nếu đang dùng firmware cũ hơn chưa đúng cấu hình, nạp tệp `.ino` kèm theo.
- Giữ **VL53=20–25cm; ROI10×10; kẹpD3 đóng2000us; quàD4 2500→600→2500us**.
- Thời gian/số nhịp sửa ở `AUTO_CONFIG['box_tof_flow']` trong `python/robot_params.py`: `final_pulse_ms`, `final_settle_ms`, `max_final_pulses`, `final_timeout_ms`, `ir_confirm_ms`.

Có kiểm thử tình huống IR báo trước/khi hạ, không được đóng kẹp trước bước cuối, chỉ nhích ở tư thế cuối, giới hạnnhịp, STOP và D18. Kết quả ở `verification/v31612_KET_QUA.md`. Chưa thử trên robot thật.
