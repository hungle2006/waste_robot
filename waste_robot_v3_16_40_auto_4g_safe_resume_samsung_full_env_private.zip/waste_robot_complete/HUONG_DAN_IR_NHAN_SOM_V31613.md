# V3.16.13 — IR nhận sớm, hạ hết rồi kiểm tra lại

## Thứ tự xử lý

1. Camera vẫn phải khóa được vật, xác nhận phân loại và ngănBIN. Nếu chưa khóa được vật thì không tự hạ chỉ vìIR sáng.
2. Bình thường, VL53L1X hợp lệ200–250mm cho chuyển sang hạ cuối như trước.
3. Nếu **IR D19 nhận sớm** khi đã khóa vật/BIN: dừng bánh, hủy yêu cầu camera đang chờ nếu có, chuyển sang hạ hết tay tới **P1/S2=2310us, P10/S1=650us**. NhánhIR này không bắt buộcVL53 đạt20–25cm. Không coiIR là một phép đo khoảng cách hay ghi `distance_ready=true` giả.
4. D19 đổi trạng thái trong đoạn hạ cuối không làm giữ tay giữa đường, không đóng kẹp trước tư thế cuối.
5. Hoàn thành toàn bộ lệnh hạ, chờ ổn định, đọc trạng thái mới và kiểm tra cặp xung cuối. **DùngIR hiện tại**, không dùng tín hiệuIR đã nhận lúc trước.
6. IR activeLOW vẫn nhận liên tục300ms: cho phép xoay kẹp nếu đã hiệu chuẩn/bật, đóngD3=2000us, nâng/thả như trước.
7. IR không còn nhận: tiến từng nhịp160ms thực thi, dừng và chờ250ms rồi kiểm tra lại. CóIR giữa nhịp thì phanh sớm; mặc định tối đa12nhịp hoặc15giây, hết giới hạn thì giữ chờ và không đóng kẹp.

## Những chỗ đã sửa

- AUTOSEARCH không từ chối luồngbox/VL53 chỉ vìD19 đang nhận; vẫn cần camera khóa được vật/BIN trước khi hạ.
- NhậnIR trước/sau bước hạ theo box; trước/trong nhịp tiến; trong nhịp căn ngang; khi chờ camera; trong giai đoạn tiếp cậnVL53: dừng bánh và chuyển sang hạ cuối thay vì giữ tay doIR sớm.
- Gỡ kiểm traIR cũ giữa các bước hạ cuối từ bản trước; kiểm traIR để cho đóng kẹp nằm sau vị trí cuối.
- Giữ kiểm traSTOP, mấtUSB, quyềnAUTO, D18, giới hạn quỹ đạo/thời gian và xác nhận giữ vật sau nâng/thả.
- Các luồng hiệu chuẩn cũ không dùngbox/VL53 và điều khiển tay giữ hành vi riêng. Không tắt cảm biếnIR hay bảo vệ bánh của firmware.

## Cài đặt và thông số giữ nguyên

Giải nén toàn bộZIP vào thư mục mới, dừngPython cũ và chạy lạiPython mới. Nếu đã nạp firmwareV3.16.11 đúngROI10×10/D4 thì không cần nạp lại trong lần này. ZIP vẫn kèm firmware và thư việnArduino đầy đủ.

| Mục | Giá trị |
|---|---|
| Khoảng cách luồngVL53 | 20–25cm, gồm hai đầu |
| ROI | 10×10SPAD; một khoảng cách |
| Vị trí gắp cuối | P1=2310us; P10=650us |
| KẹpD3 | Mở600us; đóng2000us |
| ServoquàD4 | 2500→600→2500us |
| Nhịp tìmIR cuối | 160ms thực thi; phanh sớm nếu cóIR |

Sửa ngưỡng/thời gian trong `python/robot_params.py`. Sửa xungquà trong `python/gift_params.py`. Bản này sửa `python/box_tof_flow.py`, `python/auto_controller.py` và chuỗi phiên bản/thông báo liên quan; firmware không đổi.

## Kiểm tra

Kết quả ở `verification/v31613_KET_QUA.md`, gồmIR sớm tạiSEARCH/giữa quỹ đạo/mốc2050, IR thoáng qua rồi mất, IR khi bánh tiến/căn ngang, hủy camera đang chờ trước khi hạ, không hạ khi chưa khóa vật, STOP và chu trình mô phỏng gắp–nâng–thả.

Chưa thử trên robot thật. Xung lệnh và thời gian ổn định không phải phản hồi vị trí cơ khí; servo bịkẹt vẫn cần kiểm tra thực tế.
