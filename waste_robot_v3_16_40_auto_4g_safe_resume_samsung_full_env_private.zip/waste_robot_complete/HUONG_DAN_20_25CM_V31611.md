# Waste Robot V3.16.11 — Gắp trong khoảng 20–25 cm

## Cài đặt hiện tại

| Chức năng | Giá trị |
|---|---|
| Khoảng cách gắp VL53L1X | 200–250 mm = 20–25 cm, bao gồm hai đầu |
| ROI VL53L1X | 10×10 SPAD, center 199; trả một khoảng cách, không phải 100 khoảng cách |
| Chế độ cảm biến | Short; timing budget 50 ms; period 60 ms |
| Đóng/mở kẹp D3 | Đóng 2000 us; mở 600 us |
| Servo quà | Digital D4 Arduino Mega, khác kênh P4 của PCA9685 |
| Chu trình đổi quà | Ban đầu 2500 us → bấm đổi quà 600 us → giữ 800 ms → về 2500 us |

## Cách chạy

1. Dừng Python cũ; giải nén ZIP vào thư mục mới.
2. Mở `arduino/robot_control_v3/robot_control_v3.ino`, chọn Mega2560, biên dịch và nạp lại.
3. Đóng Serial Monitor. Chạy `python check_system.py` trong thư mục `python`: ngưỡng phải là **200–250 mm**, ROI10×10.
4. Chạy `start_windows.bat` như trước, kết nối Python trên app và tải lại giao diện. Dòng khởi động phải là V3.16.11.
5. Bản gốc tự đưa tay về SEARCH khi kết nối/RESUME; hành vi này được giữ.

## Logic khoảng cách

- AUTO tiếp tục tiến theo từng nhịp giới hạn khi VL53 chưa có số đo hoặc mẫu không hợp lệ, như bản V3.16.4.
- Một số đo **hợp lệ** trong khoảng **200 ≤ mm ≤ 250** cho chuyển sang tư thế gắp. AUTO giữ chính sách không chặn theo tuổi mẫu ToF của bản đang dùng.
- Số đo trên 250 mm: tiếp tục tiếp cận; số đo dưới 200 mm: giữ tại chỗ theo logic hiện có, không tự gắp hoặc lùi.
- Sau khi đủ khoảng cách, bánh dừng; chu trình tay và xác nhận D19 trước đóng kẹp vẫn được giữ. Đủ khoảng cách cho phép chuyển bước, không bỏ qua điều kiện D19.
- Nút gắp theo cảm biến ở chế độ điều khiển tay vẫn dùng ba mẫu mới trong khoảng này; STOP và giới hạn số nhịp/thời gian vẫn hoạt động.

## Tệp chỉnh thông số

- `python/robot_params.py`: `TOF_MIN_MM = 200`, `TOF_MAX_MM = 250`. Đây là cấu hình chính khi chạy mặc định; đơn vị **mm**.
- `python/box_tof_flow.py`: ngưỡng dự phòng cho cấu hình JSON cũ cũng là 200–250 mm.
- `arduino/robot_control_v3/robot_control_v3.ino`: `tofMinMm=200`, `tofMaxMm=250`; Python gửi `TF AUTO 200 250` khi bật bảo vệ tiếp cận.
- `python/gift_params.py`: `GIFT_OPEN_US=600`, `GIFT_CLOSE_US=2500`, `GIFT_OPEN_HOLD_MS=800`.
- `python/robot_params.py`: `ROBOT_CONFIG['grip']['close']=2000`; cấu hình JSON kèm theo cũng đã là 2000 us.

Nếu tự đặt `AUTO_CONFIG` trỏ tới một tệp khác có khai báo `box_tof_flow`, kiểm tra lại hai ngưỡng trong tệp đó để không ghi đè thông số mới.

## Kiểm tra

Có kiểm thử phần mềm riêng cho hai biên 200/250 mm, giữa khoảng 225 mm, ngoài khoảng 199/251 mm, cấu hình Python/JSON, AUTO khi VL53 lỗi và mã firmware qua trình biên dịch host. Kết quả chính xác của lần kiểm tra nằm ở `verification/v31611_KET_QUA.md`.

Chưa kiểm tra trên robot thật; kiểm thử mô phỏng không xác nhận vị trí cơ khí hay độ chính xác cảm biến thực tế. Các tài liệu phiên bản cũ giữ để tham khảo lịch sử; thông số ở hướng dẫn này được ưu tiên.
