# Rà soát logic V3.16.1

Bản này sửa tiếp từ đúng ZIP V3.16 đã gửi. Đã tái hiện lỗi trước khi sửa, bổ sung kiểm thử hồi quy và kiểm tra các luồng liên quan. Chưa nối robot thật; kết quả dưới đây là kiểm thử phần mềm và phần cứng mô phỏng.

## Năm lỗi đã xác nhận và sửa

| Lỗi | Khi xảy ra và ảnh hưởng | Cách sửa |
|---|---|---|
| HOLD ghi đè ngăn của vật đang giữ | Sau gắp tay, ngăn Auto của lượt trước còn lưu; bấm HOLD có thể đổi ngăn thả | Giữ ngăn đã ghi nhận cho thao tác tay. Khi chuyển từ chu trình Auto thực sự đang giữ quyền, lấy ngăn của chu trình Auto hiện tại |
| START trong khi đang gắp/thả | START xanh có thể thay token trước khi nhận quyền thành công, làm chu trình hỗ trợ hiện tại mất quyền; START đỏ có thể khởi động quan sát chen vào thao tác | Từ chối START trong lúc assist còn chạy; chỉ gán token mới sau khi claim thành công |
| Gắp theo camera khi kẹp đóng | Lệnh GRASP cũ thiếu chặn D3, có thể tiếp tục chuỗi hạ/xoay dù kẹp chưa mở | Chặn tại Python trước claim/motion và khóa nút tương ứng trên giao diện |
| Lỗi USB làm kẹt chuyển quyền | detach_auto ném lỗi khiến transitioning không được xóa, nút chuyển quyền bị khóa mãi | Dọn transitioning trong finally cả khi lỗi hoặc bị hủy; không tự thử lại chuyển động |
| Đổi quyền khi đang giữ nút bánh bị mất lệnh | Giao diện gửi XM rồi lập tức gửi đổi quyền; pending của XM làm lệnh tiếp theo bị bỏ qua | Chờ ACK phanh, dùng epoch đã cập nhật rồi mới gửi thao tác. Nếu STOP/HOLD khác chen vào, hủy thao tác đang chờ |

Các điểm sửa chính: `python/operator_control.py`, `python/auto_controller.py`, `web/operator.html`; phần ứng dụng là `app/components/MechanicalControl.tsx` trong kho Waste_App.

## Kiểm chứng bản sửa

155 trường hợp Python liên quan đã đạt qua các nhóm dưới đây, cùng 18 kiểm thử giao diện. Các nhóm Python có trùng trường hợp, không cộng trực tiếp số dòng. Đây không phải lượt chạy toàn bộ danh mục của dự án.

| Nhóm | Kết quả | Nhật ký trong verification/ |
|---|---|---|
| Điều khiển V3.15/V3.16 và hồi quy mới | 69 đạt, gồm 6 ca mới của lần rà soát này | python_logic_review_v3161.txt |
| Brain, giao thức Realtime và hồi quy | 38 đạt; có 5 ca trùng với nhóm trên | python_control_review_v3161.txt |
| Auto, cấu hình/hiệu chuẩn và D18 | 53 đạt | python_auto_review_v3161.txt |
| Giao diện React, gồm phanh trước đổi quyền, STOP chen vào, kẹp đóng | 18 đạt | app_logic_review_v3161.txt |
| Next.js production build và TypeScript | Đạt | app_build_review_v3161.txt |
| Kiểm tra cấu hình/quỹ đạo | Đạt | check_system_review_v3161.txt |
| Cú pháp 31 tệp Python và JavaScript trang cục bộ | Đạt | integrity_review_v3161.json |
| So với ZIP V3.16 | 81 tệp Arduino và .env giống từng byte | integrity_review_v3161.json |

Các nhật ký V3.16 cũ được giữ với tên cũ để đối chiếu, không phải kết quả chạy mới. Có cảnh báo deprecation của thư viện TestClient trong kiểm thử; không có lỗi kiểm thử trong các nhóm nêu trên.

## Ứng dụng Vercel

- Production: https://waste-app-control.vercel.app/
- Nhánh `main` và production cùng commit `1d235f5b4cf526e1e24f81333d6029e89b780e3c`.
- Commit: https://github.com/hungle2006/Waste_App/commit/1d235f5b4cf526e1e24f81333d6029e89b780e3c
- Deployment: `dpl_4XL8hkNwyBz2zVDzXv4bBa51uyMX`, trạng thái `READY`, môi trường production; alias chính đã được gán thành công.
- Bản build Vercel hoàn tất trong khoảng 28 giây. Lần cập nhật nhánh ngày 19/10/2026 đã thành công; lỗi quá tải ở bước phê duyệt trước đó không còn chặn lần triển khai này.

Đã mở trang production và chuyển Manual/Auto, kiểm tra bốn nhóm Cánh tay, Bánh xe, Thùng & nắp, Auto & lệnh. Khung camera và bảng điều khiển cùng hiện; các nút cơ khí khóa khi chưa nhận trạng thái Arduino mới. Không gửi lệnh kết nối hoặc chuyển động đến robot thật trong lần kiểm tra này. Trang đang chờ ảnh camera và dữ liệu robot; chưa xác minh được hình ảnh trực tiếp hay phản hồi cảm biến thật.

Nhật ký error/fatal của deployment mới trong cửa sổ 08:36–08:46 UTC ngày 19/10/2026 không trả về bản ghi. Đây là kiểm tra cửa sổ log ngắn, không phải bằng chứng hệ thống sẽ không có lỗi về sau. Chi tiết trạng thái triển khai lưu trong `verification/deployment_v3161.json`.

Kết quả 155 kiểm thử Python liên quan, 18 kiểm thử React và build local ở phần trên là kết quả của lần sửa mã trước khi triển khai. Lần tiếp tục này chỉ cập nhật nhánh, triển khai, kiểm tra production và cập nhật tài liệu; không sửa thêm logic chạy robot.

## Sử dụng và giới hạn

Giải nén bản này và khởi động lại Python. Giữ cấu hình, hiệu chuẩn và firmware đang dùng; các hướng dẫn V3.16 vẫn áp dụng. Chạy lại nhóm mới bằng `python -m pytest tests/test_logic_review_v3161.py -q`.

Chưa xác minh servo, tải gắp, khoảng cách VL53, cực tính D19 hoặc camera trên robot thật. Góc D2 hiển thị là ước tính từ xung lệnh đã xác nhận, không phải góc đo bằng encoder. Tự xoay theo ảnh vẫn cần hiệu chuẩn camera–D2; không thể cam kết nhận diện/gắp hoàn hảo từ kiểm thử mô phỏng.
