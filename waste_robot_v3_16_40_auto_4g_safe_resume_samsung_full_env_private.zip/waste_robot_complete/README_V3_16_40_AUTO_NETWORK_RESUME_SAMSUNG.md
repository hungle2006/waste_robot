# WASTE ROBOT V3.16.40 — AUTO tiếp tục an toàn sau 4G chập chờn

## Mục tiêu

Phiên bản này kế thừa V3.16.39, không thay chân Arduino, tư thế servo, thuật toán OpenCV/Modal AI, cơ chế LiveKit hoặc cấu hình mạng đang có. Bản `python/.env` của V3.16.39 được giữ nguyên theo yêu cầu người dùng, bao gồm cấu hình riêng tư; không tải ZIP lên GitHub công khai.

Khi mạng 4G làm Supabase Realtime ngắt kết nối, AUTO **không còn gọi STOP khẩn rồi xóa checkpoint** theo đường lỗi mạng thông thường. Chương trình ghi lại *ý định xử lý* vào `.auto_checkpoint.json`, hủy tác vụ AUTO và lệnh cũ, tách quyền điều khiển cơ khí, gửi `XM` phanh bánh, tắt quyền D18 điều khiển cơ khí, giữ nguyên xung servo nếu Arduino còn kết nối. Nếu không thể phanh/giữ an toàn, chương trình chuyển sang STOP khẩn và yêu cầu kiểm tra. Không tin checkpoint như cảm biến vị trí thật: xung servo chỉ là **lệnh đã gửi**, không phải encoder.

## Quy tắc phục hồi

- **Tự phục hồi tại bước SEARCH**: chỉ sau khi Realtime đã SUBSCRIBED ổn định tối thiểu 3 giây, Arduino còn kết nối, STATUS mới, không STOP, cơ khí không BUSY, cả bốn bánh đứng yên, D19 = 1 (kẹp không giữ vật), D18 = 1, tay nằm đúng SEARCH, kẹp mở, nắp đóng, không có chuyển động dở và camera có frame mới không quá 2 giây. Hệ thống khởi tạo **một lượt nhận diện mới**, không tái sử dụng bounding box/toạ độ/khung hình cũ, không phát lại xung đã ngắt. Checkpoint giữ số lượt xử lý.
- **Không tự tiếp tục các bước khác**: tay đang hạ, đang căn/chạy bánh, đã gắp vật, đang chuyển vật, thả rác, D18 kích hoạt, không xác nhận xung servo hoặc cảm biến → giữ nguyên tay/kẹp và báo `auto_network_inspection`. Người vận hành phải quan sát vị trí tay và **đỡ/giữ vật thật an toàn trước khi bấm STOP**, vì STOP có thể ngắt xung servo và làm rơi vật. Sau đó mới bàn giao sang MANUAL hoặc khởi động AUTO mới.
- **Chờ camera**: Realtime phục hồi nhưng camera chưa có frame mới → `auto_network_wait_camera`, thử lại trong thời gian hữu hạn, không tự chạy bánh.
- **Lệnh STOP từ người dùng**: luôn hủy checkpoint tự phục hồi, cắt quyền AUTO và khóa lệnh mới cho đến khi được cho phép.
- **Chuyển MANUAL**: hủy ý định tự phục hồi. Lệnh bánh xe cũ không được phát lại, cho dù ACK đến muộn.
- **Khởi động lại hẳn Python** hoặc reset USB Arduino: checkpoint được giữ để xem xét nhưng **không tự phục hồi vận động chỉ từ tệp trên đĩa**; cần xác minh trạng thái bằng giao diện và cảm biến trước.
- Khi giữ vật trong kẹp, ưu tiên không làm mất lực giữ; không bao giờ tự mở D3, quay thùng hoặc mở nắp chỉ do có mạng trở lại.

## Kiến trúc

```
USB Camera → Jetson (OpenCV) → Modal AI (HTTPS /detect) → Python AUTO → Arduino
                         ↑
Vercel ↔ Supabase Realtime ↔ Python RealtimeSupervisor
LiveKit: Jetson → LiveKit → Vercel (video, độc lập lệnh AUTO)
```

`auto_checkpoint.py`: ghi file nguyên tử và trạng thái `waiting_network`.
`auto_controller.py`: `pause_for_network()` + `resume_after_network()`, an toàn theo trạng thái/phần cứng, chặn D18 AUTO khi giữ do mất mạng.
`realtime_bridge.py`: phân biệt rớt mạng với STOP do người dùng; chỉ khôi phục với AUTO đang bị tạm giữ; không xử lý lệnh từ channel đã offline.
`realtime_supervisor.py`: tự tạo phiên WebSocket mới, đăng ký lại kênh, chỉ cho phép thử phục hồi sau thời gian ổn định; xử lý lỗi `_reconnect` của thư viện.

## Lời chào cuộc thi Samsung — chỉ ở Vercel

Sau khi nhấn **Kết nối Python** và nhận ACK, trình duyệt sử dụng `speechSynthesis` đọc:

> “Chào mừng bạn đến với cuộc thi sáng tạo Samsung! Waste Robot đã kết nối. Cùng biến công nghệ thành hành động vì một môi trường xanh hơn!”

Âm thanh phát trên thiết bị đang mở web, không qua Jetson, Arduino, LiveKit, Supabase hay loa robot. Cần trình duyệt hỗ trợ giọng Việt. Nếu thiếu hỗ trợ, thao tác kết nối vẫn bình thường.

## Cài đặt

1. Sao lưu thư mục đang dùng trên Jetson và đặt bản mới vào thư mục riêng.
2. Đã tích hợp `python/.env` của bản V3.16.39 có cấu hình riêng tư. **Kiểm tra lại độ hợp lệ của khóa và URL**, không in/chia sẻ nội dung `.env`.
3. Kích hoạt môi trường Python hiện có hoặc chạy `python3 -m pip install -r python/requirements-jetson.txt` nếu cần.
4. Chạy từ thư mục `waste_robot_complete`: `python3 python/main.py`.
5. Mở https://waste-app-control.vercel.app, nhấn Kết nối Python. Kiểm thử treo bánh khỏi mặt đất và PWM thấp trước khi chạy thật.

## Kiểm thử

Chạy tại thư mục `waste_robot_complete`:

```bash
python3 -m pytest -q tests/test_v31640_network_auto.py tests/test_realtime_supervisor_v31639.py tests/test_v31626_checkpoint_continuous_search.py tests/test_v31638_connect_search.py
```

Các test sử dụng `SimTransport`, không chạy thử vật lý. Không có cam kết chống mọi lỗi 4G, va chạm hay mất điện. Khi mất toàn bộ mạng/trạng thái phần cứng, ưu tiên dừng an toàn và kiểm tra bằng mắt.
