# Waste Robot V3.16.24 – Vùng chết góc D2 10°

Đổi từ V3.16.23 chỉ đối với logic AUTO định hướng càng D2:

- Góc được đo và lưu tại SEARCH theo 3 ảnh góc hợp lệ liên tiếp (tối đa 9 ảnh), giữ nguyên các điều kiện an toàn.
- Sau khi `camera_sign` và `offset_deg` được áp dụng, nếu **abs(mapped_deg) < 10°** thì lệnh AUTO D2 = **2100 µs**; không xoay càng.
- Đúng +10° hoặc -10° (hay lớn hơn): tính lệnh D2 theo bảng xung hiện có.
- Góc dương vượt +60° vẫn giới hạn D2 = 2500 µs.
- Lệnh D2 chỉ được xác nhận ở cửa VL53 20–25 cm trước hạ tay, kể cả khi giữ vị trí trung tâm.
- Điều kiện D19 khi gắp, phản ứng mất vật 15 giây, lùi 10 nhịp, quét phải, nhận diện 1 frame ban đầu, căn bánh ×2, và firmware không đổi.
- `python/robot_params.py`: `AUTO_CONFIG['grasp_orientation']['deadband_deg']=10.0` để tùy chỉnh.
- Lệnh xoay cổ tay bằng tay (`WRIST LEFT/RIGHT`) không chịu vùng chết này.

**An toàn:** Ngưỡng chết 10° chỉ ngăn chuyển động rất nhỏ, không hiệu chuẩn góc cơ khí và không bảo đảm gắp đúng. Thử không tải, trong vùng trống, sẵn STOP trước khi vận hành thực tế.
