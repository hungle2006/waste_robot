# V3.16.3 — VL53 không hợp lệ: chẩn đoán và chờ phục hồi

Log `Mẫu VL53 không hợp lệ` không phải lỗi tuổi mẫu. Nó xảy ra nếu valid không đúng, status khác 0, mm ngoài 1–4000 hoặc seq không hợp lệ. Log cũ không chứa đủ dữ liệu để xác định nguyên nhân cảm biến.

## Thay đổi

- Log retry ghi present, valid, status và tên trạng thái theo thư viện VL53L1X đi kèm, mm, seq, age_ms. Tên trạng thái chỉ mô tả mã cảm biến, chưa chứng minh nguyên nhân vật lý.
- Log retry tối đa một lần mỗi giây trong mỗi luồng, thay vì lặp mỗi 50 ms.
- Trước nhịp tiến theo camera, số đo lỗi tạm thời được chờ trong `tof_approach_timeout_ms` (mặc định 45 giây), thay cho ngưỡng lỗi 6 giây cũ. Khi hợp lệ trở lại, AUTO tự tiếp tục; trong lúc chờ không phát lệnh tiến/gắp. `tof_fault_timeout_ms` được giữ để tương thích cấu hình, không còn là ngưỡng chờ ở bước này.
- Nếu hết thời gian mà số đo vẫn không hợp lệ, AUTO dừng chờ và ghi chi tiết lỗi cuối. Không coi số mm đi kèm cờ invalid là khoảng cách gắp.
- Giữ logic V3.16.2: một số đo hợp lệ 250–300 mm đủ chuyển gắp, không HOLD vì tuổi mẫu ToF; trình tự cuối vẫn kiểm tra D19. STOP, quyền cơ khí và kiểm tra firmware không đổi.

## Chạy và gửi chẩn đoán

1. Dừng chương trình Python cũ, giải nén ZIP mới và chạy từ thư mục mới. Dòng khởi động phải hiện V3.16.3. Không cần nạp lại Arduino cho bản sửa Python này.
2. Khi lỗi lặp lại, gửi một dòng retry mới đầy đủ. Hoặc mở PowerShell trên máy đang chạy Python và thực hiện lệnh chỉ đọc:

```powershell
(Invoke-RestMethod http://127.0.0.1:8766/operator/state).hardware.tof | ConvertTo-Json
```

Nếu đã đổi cổng giao diện local, dùng cổng thực tế chương trình in ra. Không gửi .env hoặc khóa API. Chẩn đoán từ robot thật cần thiết để phân biệt lỗi đo, chưa có mẫu, hoặc firmware/cảm biến chưa sẵn sàng; bản này không khẳng định đã sửa nguyên nhân phần cứng.

## Kiểm tra

Kết quả kiểm thử tự động trong `verification/vl53_diag_after.txt`. Bao gồm mã trạng thái, giới hạn log, phục hồi sau ngưỡng chờ cũ, hết thời gian không phát lệnh cơ khí và STOP khi đang chờ, cùng bộ kiểm tra luồng box/ToF và hồi quy V3.16.2. Đây là kiểm tra mô phỏng, chưa thử với robot thật.
