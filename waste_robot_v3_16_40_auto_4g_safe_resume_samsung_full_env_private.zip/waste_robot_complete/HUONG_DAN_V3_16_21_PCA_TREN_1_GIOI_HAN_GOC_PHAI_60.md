# Waste Robot V3.16.21 — PCA > 1 và giới hạn góc xoay càng phải +60°

Phiên bản nền: V3.16.20. Giữ nguyên các chức năng AUTO, căn ngang x2, FORWARD, phục hồi rơi chai, lùi tối đa 10 nhịp, tìm rác 30 lượt, đổi quà 120 giây.

## Sửa đổi

1. `python/grasp_orientation.py`: phép đo góc chỉ được chấp nhận khi **tỷ lệ trị riêng PCA R > 1.0**. Mã từ chối `R <= 1.0` với thông báo giá trị PCA. Đây là ngưỡng rất thấp: hình gần tròn vẫn dễ có một góc ngẫu nhiên; các kiểm tra tách foreground và độ ổn định 3 ảnh vẫn cần thiết. Tại SEARCH, cơ chế thử tối đa 9 ảnh từ V3.16.20 vẫn được giữ.
2. `python/grasp_orientation.py`: khi góc đã hiệu chỉnh của chai **lớn hơn +60° và nhỏ hơn +90°**, thay vì HOLD vì vượt góc phải, ra lệnh giới hạn **+60° (D2 = 2500 µs)**. Phía góc âm và cấu hình xung D2 khác không thay đổi.
3. `python/operator_control.py`: ghi lại cả `mapped_deg` (góc mục tiêu đã hiệu chỉnh) và `commanded_deg` (góc D2 thực tế được lệnh), cùng `angle_limited`. Ở SEARCH chỉ ghi nhớ; **không xoay D2** cho đến khi VL53 xác nhận 20–25 cm. Sau đó xoay D2, mới hạ tay và gắp khi D19 xác nhận.

## Cấu hình thực tế

- Nếu camera báo +75°, D2 chỉ được lệnh tương đương +60° = 2500 µs. Sai lệch 15° giữa góc chai và càng vẫn tồn tại; đây là giới hạn cơ khí, không phải phép đo chính xác 75°.
- Với R gần 1.0 (ví dụ 1.0001), trục dài PCA rất kém ổn định. Không xem kết quả là đã hiệu chuẩn; cần quan sát camera và thử với tải nhẹ, có người giám sát và nút STOP.
- `ratio > 1.0` là điều kiện **chấp nhận**. Trong mã, điều kiện **từ chối** tương đương là `if ratio <= 1.0`.
- Lưu `robot_params.py` và firmware Arduino nguyên trạng.

## Kiểm thử

- Đã chạy 28 bài kiểm thử liên quan và đạt.
- Một bài kiểm thử có sẵn từ V3.16.20 (`test_axis_from_actual_pixels[55]`) vẫn lệch khoảng 3.03° so với ngưỡng kiểm thử 2°, không thuộc phạm vi thay đổi này và chưa được sửa.
- Chưa kiểm chứng trên phần cứng thực tế.
