# Waste Robot V3.16.19 — lùi tìm lại vật sau khi rơi

## Luồng mới

1. D19 báo mất vật 3 lần liên tiếp (mỗi lần cách khoảng 100 ms): hủy lượt gắp, **không** mở nắp thả rác, **không** ghi nhận thành công hay cấp quyền đổi quà.
2. Robot thu tay về SEARCH theo quỹ đạo bảo vệ, đóng nắp và mở D3. Nếu D19 lại nhận vật hoặc tư thế SEARCH chưa đúng thì HOLD; không lùi.
3. Chỉ khi lần rơi này vẫn thuộc **lượt gắp lại cho phép** (mặc định một lần) robot mới đi vào pha `drop_backtrack`.
4. Camera chụp **ảnh mới ngay tại SEARCH**. Nếu đã thấy vật thì không lùi thêm.
5. Nếu chưa thấy: BACK 400 ms danh định / khoảng 560 ms chuyển động có ramp 160 ms, PWM 20; dừng 500 ms, chụp **ảnh mới**. Lặp tối đa **10 nhịp BACK**.
6. Nếu thấy vật sau bất kỳ nhịp nào: dừng BACK và bắt đầu một chu trình AUTO mới. Phải phân loại/khóa vật nhiều ảnh, đo lại góc tại SEARCH, tiếp cận VL53, xoay D2, hạ tay, D19 rồi mới đóng D3. Không dùng góc/nhãn cũ từ chai đã rơi.
7. Nếu sau 10 nhịp vẫn không thấy vật: chuyển sang chế độ quét cũ, quay phải tại chỗ khoảng 5 giây, dừng 1 giây, chụp ảnh; tổng giới hạn **30 lượt quét**, rồi tắt AUTO nếu vẫn không thấy rác.
8. Nếu rơi **lần thứ hai trong cùng lượt thử lại**, robot trở về SEARCH an toàn và vào AUTO HOLD; không lùi/gắp vô hạn.

## Cấu hình trong `python/robot_params.py`

```python
AUTO_CONFIG['drop_recovery'] = {
    'max_retries': 1,                 # thử gắp lại tối đa một lần
    'retry_wait_ms': 800,            # nghỉ trước khi tìm lại
    'reverse_max_steps': 10,         # tối đa mười nhịp BACK
    'reverse_settle_ms': STAGE_TIMING[0]['settle_ms'],  # 500 ms
}
```

Thời lượng một nhịp BACK trong pha xử lý rơi lấy **trực tiếp** từ `AUTO_CONFIG['control']['move_ms']`, tức chính thời lượng tiến FORWARD bằng camera. Không sửa `forward_ms`, `lateral_ms`, `PWM` hay bộ giới hạn quay 30 lần.

Các trạng thái mới: `auto_drop_reverse_start`, `auto_drop_reverse`, `auto_drop_target_found`, `auto_drop_reverse_exhausted`, `auto_drop_scan_start`, `auto_drop_camera_wait`.

## An toàn và giới hạn

- Các lệnh bánh đều qua `motor_step`, tiếp tục kiểm tra STOP, quyền điều khiển AUTO, kết nối Arduino và chặn D19; nếu camera/AI không trả dữ liệu mới hợp lệ 3 lần thì **HOLD, không lùi mù**.
- Trước khi lùi phải có SEARCH đúng tư thế, nắp đã đóng, D3 đã mở và D19 không thấy vật. Nếu D18 đã yêu cầu phân loại phía sau thì giữ chờ thay vì tự lùi.
- **Chưa có cảm biến chống va chạm phía sau**. Lệnh BACK không tự biết có người hoặc vật cản phía sau; bắt buộc thử trong vùng trống, có nút STOP và người quan sát. Không coi D18 là cảm biến tránh va chạm.
- Các kiểm thử đi kèm chỉ là mô phỏng và kiểm tra logic, chưa xác nhận bằng phần cứng thật.
