# V3.14.2 — Dọn nhánh điều khiển cũ

Luồng mặc định: camera nhận diện/khóa BIN → bám box → VL53L1X250–300mm/3 mẫu
mới → tư thế2310/650 → D19 ổn định300ms → đóng kẹp/nâng/thả.

Đã gỡ toàn bộ module ước lượng camera-Z và hai nhánh điều khiển phụ thuộc vào nó,
API client/probe, import, cấu hình endpoint, mốc57/19cm, nhịp1200ms,
trạng thái truyền ra giao diện, lớp hướng dẫn camera và giả lập tương ứng.
Đã bỏ kiểm thử/tài liệu riêng cho các nhánh bị gỡ và thay log cũ bằng kết quả mới.

Giữ nguyên API nhận diện `/detect`, các ảnh tham chiếu, quỹ đạo P1/P10,
khóa nhãn/BIN, VL53, D18/D19, STOP, các công cụ hiệu chuẩn tương thích,
firmware Arduino và toàn bộ thư viện Arduino. File `.env` giữ nguyên từ bản gốc.
Không có thao tác thay đổi dịch vụ Modal từ xa.

Nguồn chính: `python/robot_params.py`. Cách chạy: `README_CHAY_TRUOC.md`.
Kết quả: `KIEM_THU_V3_14_2.md` và `verification/`.
