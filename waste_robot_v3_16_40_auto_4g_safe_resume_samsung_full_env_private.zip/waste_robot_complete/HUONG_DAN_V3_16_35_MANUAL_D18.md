# Waste Robot V3.16.35 — D18 và quyền điều khiển bánh

## Mục tiêu
- Khi bật AUTO (nút xanh), AUTO sở hữu cơ khí; D18 giữ ưu tiên tự phân loại phía sau như trước.
- Khi gạt nút **Xanh · AUTO điều khiển cơ khí** sang **Đỏ · Bạn điều khiển cơ khí**, phần AUTO trả quyền cơ khí: thắng bánh, hủy writer AUTO, chuyển sang quan sát camera (nếu đã START), D18 vẫn được đọc và hiển thị nhưng **không phanh bánh trong MANUAL**. Bạn dùng các nút Tiến/Lùi/Trái/Phải theo kiểu **giữ để chạy** ngay khi giao diện báo `MANUAL ĐANG HOẠT ĐỘNG`.
- App Vercel gửi mode `manual` cũng dùng bàn giao này, **không STOP latch**. Nút `DỪNG TẤT CẢ`/`auto_stop` vẫn STOP thật.
- Không được bỏ qua STOP, watchdog liên kết, giới hạn servo, bảo vệ VL53 (khi đang bật). D18 không phải cảm biến tránh vật cản; chỉ vô hiệu sự ưu tiên tự phân loại khi MANUAL đã nhận quyền.

## Jetson Nano
1. Giải nén ZIP, mở `waste_robot_complete`, nối Arduino CH341 `/dev/ttyUSB0`.
2. Dùng `python3 python/main.py` (luồng remote app), hoặc chạy local server theo hướng dẫn riêng nếu cần `/control`.
3. Nhấn Kết nối Arduino và chờ tay hoàn tất tư thế khởi động.
4. Khởi động AUTO rồi chuyển sang **Đỏ**. D18 xuống LOW sẽ vẫn được hiển thị. Giữ các phím di chuyển để thử bánh.
5. Nếu màn hình báo `Robot đang STOP`, bấm `Cho phép điều khiển` trước khi thử; STOP tuyệt đối không được bỏ qua.

## Lưu ý
- Đây là gói mã đã kiểm tra bằng simulation/unit tests, **chưa thử trực tiếp trên robot thật**.
- Không cần nạp lại Arduino chỉ để có hành vi mới nếu firmware đã dùng giao thức DRIVE C ở bản trước: ở nhánh lệnh C, firmware không kiểm tra D18. Firmware mới được giữ nguyên.
- Đối với app Vercel: app cần thực sự gửi `mode/manual` hoặc `operator/MECHANICS OFF` tương ứng; mã Jetson không tự sửa UI deployed tại Vercel. Trạng thái `auto.manual_wheels_available` và `auto.d18_detected` được đưa vào gói trạng thái để app hiển thị.
- Thử khi nâng bánh khỏi mặt đất và vùng xung quanh trống; D18 bị bỏ qua ở MANUAL nên người điều khiển phải quan sát vật phía sau.
