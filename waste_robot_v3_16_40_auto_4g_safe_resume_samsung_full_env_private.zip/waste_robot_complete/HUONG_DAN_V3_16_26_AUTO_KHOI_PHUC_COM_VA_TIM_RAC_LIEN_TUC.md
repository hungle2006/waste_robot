# Waste Robot V3.16.26 – Lưu trạng thái khi mất COM3 và SEARCH liên tục

Bản này kế thừa V3.16.25 (nhánh S2 xuống trước nếu góc >=10°, VL53 quá gần thì lùi chỉnh 200 ms; D19 khi gắp/đang giữ vật; phục hồi rơi chai; căn ngang x2; thưởng D18 120s).

## 1. Khi COM3 bị ngắt

- Python mất heartbeat hoặc lệnh USB lỗi sẽ dừng phát lệnh điều khiển; firmware phải tự phanh bằng watchdog/STOP. **Mất đường truyền không đồng nghĩa đã phanh tức thì** nếu MCU đang thực hiện lệnh đã nhận.
- AUTO ghi *checkpoint ý định* vào `python/.auto_checkpoint.json` ở thời điểm bước chạy, gồm trạng thái, pha, BIN, số lượt, cờ đang giữ vật, các **xung servo đã ra lệnh** (KHÔNG PHẢI góc thật). Có thể đổi đường dẫn bằng `ROBOT_AUTO_CHECKPOINT`.
- Checkpoint được ghi qua tệp tạm + fsync + atomic replace. Bấm **STOP** chủ động sẽ xóa checkpoint, không cho tự phục hồi.
- Khi người vận hành bấm **Kết nối** trên app, Python đọc checkpoint và kết nối lại Arduino; nếu có checkpoint thì **không khởi tạo lại tay ngay ở kết nối**.
- Trường hợp được tự tiếp tục: trước khi mất COM3 robot đang ở SEARCH, bánh/tay nghỉ, D3 mở, nắp đóng, trước mất COM3 checkpoint báo các xung SEARCH, D18 và D19 không báo vật. Chương trình bỏ dữ liệu camera/VL53/góc cũ và bắt đầu nhận diện lại **từ SEARCH**, lưu lại số lượt đã hoàn tất; không lặp một lệnh tiến/kẹp/thả chưa được xác minh.
- Trường hợp **không thể tự tiếp tục an toàn**: đang hạ/nâng tay, đang gắp hay mang chai, nắp đang mở, servo chưa xác minh, D18/D19 đang có vật, COM vừa reset trong lúc lệnh cơ khí chưa kết thúc. Hiển thị `auto_reconnect_inspection`, **không tự phát lại lệnh**. Kiểm tra thực tế, thao tác MANUAL để đưa robot về SEARCH trống rồi bấm START AUTO mới.
- Servo không có encoder; các xung báo cáo từ Arduino chỉ là *xung ra lệnh*, không chứng minh được cánh tay hoặc chai ở vị trí nào sau khi mất điện/USB reset. Không có cách an toàn để hứa "tiếp tục chính xác giữa động tác gắp" chỉ dựa vào trạng thái Python. 

## 2. Không tìm thấy rác ở SEARCH

- Không còn lỗi "quét 30 lượt rồi tắt AUTO". 30 là số lượt mỗi nhóm để hiển thị trên app; các nhóm tiếp tục cho đến khi phát hiện rác hoặc người vận hành nhấn STOP.
- Mỗi nhịp xoay tìm kiếm dùng chuỗi lệnh TURN_RIGHT tổng xấp xỉ 5 giây, dừng 1 giây rồi lấy **ảnh camera mới**. Không dùng lại ảnh cũ.
- Khi camera/AI mất ảnh nhiều lần, robot **đứng yên thử lại** và hiển thị `auto_camera_retry`, **không quay khi không có ảnh hợp lệ**, không HOLD chỉ vì không có rác / camera tạm chập chờn.
- Nếu đang theo dõi vật đã khóa và tín hiệu mất quá lâu, hoặc VL53/D19/hành trình không an toàn, các HOLD bảo vệ vẫn còn.
- **Nguy cơ dây xoắn:** nếu dùng camera/USB có dây, quay phải liên tục có thể xoắn hoặc đứt cáp. Chỉ bật quét liên tục khi không gian và dây/nguồn cho phép hoặc đã có cơ cấu chống xoắn/safety enclosure. Dùng nút STOP nếu dây có nguy cơ quấn.

## 3. Cách cập nhật

1. Giải nén toàn bộ ZIP vào thư mục mới. Sao lưu `.env`, các thay đổi hiệu chuẩn của bạn trước khi ghi đè.
2. Không cần sửa firmware Arduino mới so với **V3.16.25**. Nếu máy vẫn chạy firmware đời cũ hơn V3.16.23, hãy nạp lại `arduino/robot_control_v3/robot_control_v3.ino` có lệnh `IG 0/1`.
3. Chạy `python/main.py` theo quy trình cũ; nhấn Kết nối trong app. Sau lần kết nối USB đầu tiên, START AUTO như trước.
4. Mô phỏng thử: tháo COM3 lúc SEARCH (không mang vật), sau đó nhấn Kết nối; kiểm tra AUTO nhận diện lại. Tiếp theo thử tháo COM khi D3 đã kẹp vật **không tải**: chương trình phải hiển thị `auto_reconnect_inspection`, tuyệt đối không tự mở kẹp/thả.
5. Không tự phục hồi nếu bạn đã nhấn STOP. Trường hợp đã có lỗi bảo vệ phải khắc phục lỗi vật lý và bắt đầu lại thủ công.

## 4. Tệp đã thay đổi

- `python/auto_checkpoint.py` (mới): lưu/phục hồi checkpoint ở đĩa.
- `python/auto_controller.py`: ghi checkpoint, không hết hạn quét tìm rác ở lượt 30, chờ camera phục hồi và xác minh nhánh tự phục hồi.
- `python/brain.py`: tùy chọn nối USB mà chưa khởi tạo lại SEARCH.
- `python/realtime_bridge.py`: nút Kết nối gọi khôi phục checkpoint sau khi USB đã kết nối.
- `python/robot_params.py`: cập nhật chú thích 30 là một nhóm quét, không phải giới hạn tổng.
- `python/main.py`: cập nhật thông báo phiên bản.
- `tests/test_v31626_checkpoint_continuous_search.py`: kiểm thử mới.

**Chưa chạy trên robot thật.** Kiểm thử Python mô phỏng, không xác nhận cảm biến thực, độ an toàn của quỹ đạo và watchdog phần cứng.
