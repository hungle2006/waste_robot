# V3.16.16 — Bật AUTO xoay càng kẹp D2 theo góc chai

## Thay đổi

- `python/robot_params.py`: `AUTO_CONFIG['grasp_orientation']` bật `enabled=True`, `calibrated=True` ở cấp phần mềm.
- `python/operator_control.py`: trước khi xoay, bắt buộc tư thế cuối `P1=2310`, `P10=650`, `P11=1250`, `D2=2100`, D3 đang mở, bánh/tay dừng, D19 nhận vật và BIN vẫn đúng vật khóa.
- Sau khi D19 được xác nhận ổn định trong `box_tof_flow.py`, `auto_controller.py` mới gọi `operator.rotate_for_grasp(obj)`; không xoay khi đang tìm rác, căn bánh, tiến VL53 hoặc đang hạ tay.
- Ở vị trí gắp cuối, lấy **ba ảnh mới liên tiếp** và dùng JPEG thật + box từ mỗi ảnh mới để tính trục dài bằng PCA/GrabCut. Không còn dùng bbox cũ trước khi xuống tay để đối chiếu IoU với ảnh cận cuối, vì góc nhìn đã thay đổi.
- Ba ảnh phải thấy đúng **một** vật cùng BIN, box không dịch chuyển bất thường, nhãn ổn định, góc trung bình không dao động quá 8°. Nếu thiếu điều kiện, `auto_hold`, không xoay mù và không đóng kẹp.
- Khi hợp lệ, tính `mapped_deg = camera_sign * angle_deg + offset_deg`, đổi sang D2 theo `pulse_for_angle()`, ra lệnh xoay D2 một lần; sau đó `auto_controller.py` kiểm tra D19 lại mới đóng D3 2300µs, nâng tay và giữ góc D2 đến lúc thả rác.
- Nếu D19 mất hiện diện khi đo hoặc xoay, xử lý LostGrip theo luồng phục hồi hiện có; không coi đó là gắp thành công.

## Quan trọng: hiệu chuẩn thực tế CHƯA xác minh

`calibrated=True` hiện **chỉ là cờ cho phép phần mềm chạy**, KHÔNG có nghĩa cảm biến và góc cơ khí đã đo kiểm. `camera_sign=1`, `offset_deg=0` là mặc định thử nghiệm. D2 có bảng xung có sẵn: -90°=500µs, 0°=2100µs, +60°=2500µs. Trước khi chạy với chai/rác thật: nâng bánh khỏi sàn, tháo vật, cho D2 xoay thử những góc nhỏ; kiểm tra chiều quay, giới hạn va chạm, góc lắp camera/càng; điều chỉnh `camera_sign`, `offset_deg` bằng quan sát vật lý.

## Hạn chế ảnh cuối

Camera ở P1=2310/P10=650 rất gần chai (tài liệu ảnh gốc mô tả khung hình bị cắt đầu và che phần dưới). Trong trường hợp không nhìn đủ chai, GrabCut/PCA **không thể xác định góc đáng tin cậy** và AUTO sẽ chuyển HOLD thay vì đóng kẹp đoán góc. Muốn hoạt động ổn định phải bảo đảm vật còn trong ảnh hoàn chỉnh ở tư thế cuối hoặc thiết kế thêm bước đo góc ở tư thế có tầm nhìn tốt, kèm hiệu chuẩn góc theo tư thế đó. Không nên ép phần mềm bỏ chặn vì nguy cơ kẹp sai và va chạm.

## Giữ nguyên các chức năng phiên bản trước

Căn ngang trái/phải ×2; FORWARD giữ thời gian cũ và không giới hạn số nhịp nhưng vẫn có chặn VL53/IR/timeout; tìm rác quay phải tối đa 30 lần; D19 mất vật thu tay an toàn; đổi quà tối đa 120 giây sau lượt nhận rác D18 hoàn tất.
