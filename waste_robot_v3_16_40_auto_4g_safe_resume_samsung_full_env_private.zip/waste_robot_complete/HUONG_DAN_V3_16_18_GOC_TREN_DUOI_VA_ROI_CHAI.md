# Waste Robot V3.16.18 – Góc chai theo đầu trên/dưới và phục hồi khi tuột chai

## 1. Góc chai tính từ đâu?

Ở SEARCH, 3 ảnh mới của cùng vật được dùng để xác nhận góc. Mỗi ảnh:
1. Bounding Box khoanh vùng chai. GrabCut lấy các pixel THỰC của chai trong Box (không lấy hai tâm cạnh trên/dưới của hình chữ nhật – vì chúng luôn cùng X).
2. Ở vùng trên và vùng dưới của phần thân chai nhìn thấy, lấy tâm theo trục X, tạo 2 điểm A (trên), B (dưới).
3. `angle = atan2(A.x - B.x, B.y - A.y)`, rồi đổi sang độ. A.x < B.x → nghiêng trái (âm), A.x > B.x → nghiêng phải (dương).
4. PCA kiểm tra hướng dài và độ thuôn của chai; nếu kết quả vùng trên/dưới lệch hơn 15° với trục dài, từ chối đo (AUTO HOLD), không xoay mò.
5. Chai gần nằm ngang (góc trục PCA lớn hơn 55°) dùng chính PCA: vùng mép trên/dưới của chai gần ngang phản ánh độ dày chứ không phản ánh chiều dài.
6. Ba ảnh phải đồng thuận trong phạm vi 8°. Góc được quy đổi theo `camera_sign`/`offset_deg` và bảng xung D2 đang cài; ghi nhớ gắn đúng lượt/nhãn/BIN.

**Thứ tự:** SEARCH đo/gọi nhớ góc → căn bánh/tiến → VL53 xác nhận 20–25 cm → xoay D2 → hạ P1/P10 → D19 xác nhận → đóng D3=2300 µs.

## 2. Khi D19 mất vật (chai rơi, tuột hoặc cảm biến mất tín hiệu)

- D19 là cảm biến hiện diện, không phải cảm biến lực: chỉ kết luận **không còn phát hiện vật**, chưa thể chứng minh chắc chắn chai rơi. Nếu bị che/chập chờn có thể báo sai; cần hiệu chuẩn thực tế.
- Sau khi D3 đóng, xác nhận D19 suốt 300 ms trước khi nâng. Trong lúc nâng và chuyển tới thùng, D19 được kiểm tra trước/sau mỗi lệnh servo hoàn tất, và trên các bước rút tay. Khi D19 báo mất, chờ/đọc STATUS mới 3 lần (cách nhau 100 ms), không dựa vào một mẫu duy nhất.
- Nếu mất liên tục: dừng bánh, không đánh dấu thành công, không mở nắp mới, không thưởng; giữ D3 đóng trong khi thu tay an toàn theo quỹ đạo ngược về SEARCH.
- Khi về SEARCH, đọc D19 một lần mới. Nếu D19 lại thấy vật, HOLD với càng vẫn đóng để người vận hành kiểm tra (có thể chai mắc trong kẹp); KHÔNG tự mở kẹp.
- Nếu D19 thực sự không thấy vật, đóng nắp, mở D3 tại SEARCH, xóa vật khóa và góc cũ; dừng chờ 800 ms rồi nhận diện lại từ đầu, tính góc mới và thử gắp lại đúng **một lần**.
- Nếu tiếp tục mất vật ở lượt thử lại (hai lần rơi liên tiếp): **AUTO HOLD**, dừng bánh/giữ tay, STOP để kiểm tra D19, càng kẹp, vị trí chai. Không tự thử vô hạn.
- Nếu robot không nhận lại được vật: áp dụng logic tìm kiếm/quét và các bảo vệ camera/VL53 có sẵn; không tự phát giả kết quả gắp.

## 3. Cấu hình

`waste_robot_complete/python/robot_params.py`:

```python
AUTO_CONFIG['drop_recovery'] = {'max_retries': 1, 'retry_wait_ms': 800}
```

- `max_retries=1` tức một lượt đầu + tối đa một lần thử lại sau rơi; có thể chỉnh 0–2 nhưng mặc định **1** để an toàn.
- D3 đóng 2300 µs; giữ xung D2 theo góc tại SEARCH.
- Không thay đổi thời gian căn ngang ×2, tiến FORWARD, VL53/IR, D18 đổi quà 120 giây, quét tìm rác 30 lượt hoặc firmware Arduino.

## 4. Những giới hạn quan trọng

- Không thể xác minh chai đã kẹp chắc chỉ bằng D19; tốt nhất bổ sung cảm biến lực/hành trình càng khi cần chính xác cao.
- Việc phát hiện mất vật trong chuyển động servo dài có thể trễ tới khi một lệnh servo hoàn tất; chưa có ngắt tức thời chuyển động tay ở firmware. STOP vẫn là biện pháp khẩn cấp.
- Các lệnh servo báo xung mục tiêu, không có phản hồi vị trí cơ khí. Cần thử không tải/đỡ tay, kiểm tra khoảng hở trước khi chạy với chai thật.
- `calibrated=True` hiện vẫn là cờ phần mềm từ V3.16.17; chiều quay D2 chưa được xác nhận bằng đo đạc trên robot thật.

## 5. Tệp thay đổi (so với V3.16.17)

- `python/grasp_orientation.py`: bổ sung góc từ tâm của các pixel thân chai ở đầu trên/dưới; kiểm tra PCA và xử lý chai gần nằm ngang.
- `python/auto_controller.py`: xác nhận sau đóng D3, theo dõi D19 ở các bước vận chuyển, phục hồi/giới hạn thử lại, an toàn mở kẹp.
- `python/robot_params.py`: tham số `drop_recovery`.
- `tests/test_v31618_drop_topbottom.py`: kiểm thử mới.

**Chưa thử nghiệm trên phần cứng thật.**
