# Xác minh V3.16

## Kết quả và phạm vi

Danh mục hiện tại có **425 trường hợp Python**. Các trường hợp đã được xác minh qua lượt chạy rộng và các lượt kiểm tra lại theo nhóm. **Không phải 425 bài cùng đạt trong một lượt chạy song song**: lượt rộng 424 bài có 421 đạt và 3 bài quá thời gian; cả 3 chạy lại riêng đã đạt. Một bài kiểm tra mới về epoch được thêm sau lượt rộng và đã đạt cùng nhóm mới. Nhật ký gốc được giữ để đối chiếu.

| Kiểm tra | Kết quả |
|---|---|
| Lượt rộng Python, 2 worker | 421 đạt / 424; 3 lỗi thời gian mô phỏng, xem `python_parallel_v316.txt` |
| Ba trường hợp quá thời gian chạy lại riêng | 3 đạt, xem `python_timing_v316.txt` |
| Nhóm chức năng mới V3.16 | 29 đạt, xem `python_operator_v316.txt` |
| Kiểm tra cuối về epoch và gắp/thả không AI | 2 đạt sau thay đổi cuối, xem `python_epoch_v316.txt` |
| Nhóm D18/thùng phía sau | 18 đạt, xem `python_rear_v316.txt` |
| Kiểm tra IR mới và mốc ảnh | 49 đạt, xem `python_fresh_ir_v316.txt` |
| React DOM | 15 đạt |
| Next.js production build, TypeScript | Đạt |
| Cú pháp JavaScript trang điều khiển cục bộ | `node --check` đạt |
| Cú pháp Python | 31 tệp nguồn parse được |
| check_system.py | Đạt |
| demo_auto.py | Auto hoàn tất 1 lượt; thả vật mô phỏng thành công |
| Arduino / .env | 81 tệp Arduino và nội dung .env giữ nguyên so với ZIP V3.15 |

Các nhóm có thể trùng trường hợp; không cộng tổng các dòng trong bảng. Bản mã giữ các điều kiện dữ liệu mới, giới hạn cơ khí và cảm biến. Một fixture hiệu chuẩn được cấp lại thời gian mẫu mô phỏng trước mỗi lần chụp; thời gian chờ ngoài của kiểm thử D18 được đặt lớn hơn giới hạn chu trình 30 giây của cấu hình thử nghiệm. Các ngưỡng cảm biến và thời hạn trong mã chạy robot không được nới ra.

## Những điều đã kiểm tra

- Ánh xạ góc D2 hai phía, bước liên tiếp 10°, không tích lũy sai số làm trôi mốc; không quay vòng ở giới hạn phải 60°.
- Lệnh bước tính từ xung đã xác nhận; chặn lệnh khi bận, Auto đang giữ quyền, epoch cũ hoặc request lặp.
- Gắp bằng cảm biến ở Manual và Auto đỏ không cần mục tiêu AI; cần mẫu VL53 mới, đúng quỹ đạo và D19 trước khi đóng.
- Đọc lại USB trước bước hạ, từ chối D19 đến sớm và không tự chạy bánh để cố gắp.
- Giữ D2 đã chọn trong lúc hạ, kẹp và nâng; thả theo ngăn đã ghi nhận và xác nhận D19 hết thấy vật.
- HOLD hủy worker/chuỗi, phanh bánh và giữ xung; LIFT giữ góc kẹp; lệnh cũ không thể nhận quyền sau khi epoch đổi giữa quá trình kiểm tra.
- Đổi nhóm giữ nguyên phiên camera/robot, dừng bánh khi rời nhóm; HOLD hủy bộ hẹn giờ làm mới bánh trong trình duyệt.
- Khả năng tương thích Python V3.15: nút cũ hoạt động, lệnh mới khóa và hướng dẫn nâng cấp.

## Triển khai và giao diện

- Production: https://waste-app-control.vercel.app/
- Kho ứng dụng: https://github.com/hungle2006/Waste_App
- Commit: `55f3e42d98840a7006746ca8937ddb0b801acee8`
- Deployment: `dpl_FBVcMV5QKXfNJHR8gqPVmpeK7kte`, `READY`, production.

Đã mở ứng dụng thật và kiểm tra các nút xoay, gắp theo cảm biến, nâng/rút, giữ vị trí trong cả màn hình Manual/Auto; camera và bảng điều khiển cùng hiện. Không gửi lệnh cơ khí thật từ trình duyệt kiểm tra. Các thao tác có phản hồi phần cứng được kiểm tra bằng transport/cảm biến mô phỏng. Chưa kiểm tra trực quan trên điện thoại thật.

## Chạy lại

Từ thư mục gốc bộ robot, sau khi cài các dependencies:

```sh
python -m pytest -q
python -m pytest tests/test_operator_v316.py -q
python -m pytest tests/test_rear.py -q
python python/check_system.py
python python/demo_auto.py
```

Các chuỗi mô phỏng dùng thời gian thực; chạy nhiều worker khi máy bị tải có thể làm hết thời hạn chờ test hoặc dữ liệu USB/ảnh trở nên cũ. Khi đó chạy riêng trường hợp lỗi để phân biệt lỗi logic với thiếu tài nguyên. Trên robot thật, dữ liệu USB quá hạn vẫn dẫn tới giữ/dừng; cần kiểm tra mức tải CPU, camera và kết nối USB tại máy robot.

Trong kho ứng dụng:

```sh
npm ci
npm test
npm run build
```

## Giới hạn thực tế

Chưa nối robot, servo, camera và cảm biến thật trong môi trường này. Góc hiển thị tính từ ba mốc xung người dùng cung cấp, không có encoder xác nhận góc vật lý. Chưa thể chứng minh gắp đúng tải hoặc nhận diện hoàn hảo. Tự xoay theo ảnh vẫn tắt mặc định tới khi hiệu chuẩn camera–D2. Xem `HUONG_DAN_V3_16.md` để vận hành và hiệu chuẩn.
