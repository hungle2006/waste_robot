> Tài liệu lịch sử trước V3.12. Với bản hiện tại, đọc README_CHAY_TRUOC.md và TINH_TOAN_V3_12.md.

# Waste Robot V3.11.1 — ảnh gắp 27 cm đã xác nhận

Người dùng đã xác nhận ảnh `WIN_20261016_00_22_10_Pro.jpg` được chụp khi chai ở mốc 27 cm từ hình chiếu trục S2 và tay P1=2310/P10=650 µs.
Ảnh gốc được giữ trong `calibration_reference`. Không cần đưa chai về SEARCH để ghi mốc này.

## Cập nhật

1. STOP AUTO, tắt Python; giải nén bản mới.
2. Bản ZIP này đã kèm `python/.env` từ bộ mã của bạn. Không cần chép thêm `.env` hoặc chạy công cụ ghi mốc SEARCH.
3. Chỉnh trực tiếp `python/robot_params.py`; bỏ biến ROBOT_CONFIG/AUTO_CONFIG cũ trong `.env` nếu chúng trỏ tới JSON cũ.
4. Chạy `python check_system.py` để xem tham số, rồi `python main.py`.
5. Không cần nạp lại Arduino nếu đang dùng firmware V3.9.

## Luồng mới

- SEARCH: tìm/khóa chai, căn ngang, bánh tiếp cận khi còn ảnh rõ.
- Đáy box tới vùng chuyển tay: bánh dừng để hạ tay theo ảnh. Mốc 54% là chuyển giai đoạn giữ tầm nhìn, không kết luận đã tới 27 cm.
- P1 hạ danh định 50 µs/lần, P10 nội suy theo đường 950→650; quan sát lại sau mỗi bước. P11/D2 giữ nguyên.
- Nếu chai lên phía trên vùng theo ảnh, tay giữ nguyên ở tư thế trung gian và bánh nhích 60 ms; chụp ảnh mới xác nhận tiến triển rồi mới hạ tiếp. Không chạy bánh đồng thời khi tay chuyển động.
- Chỉ cho nhịp bánh trung gian tới P1≤2260 µs (giới hạn thử); không nhích bánh ở tư thế gắp cuối. Hết nhịp hoặc ảnh không xác nhận tiến triển thì giữ tại chỗ.
- Ở P1=2310/P10=650: cho phép chai bị cắt mép trên như ảnh tham chiếu. Cần box còn nằm giữa ảnh theo ngang, đủ phần nhìn thấy, nhiều ảnh nhất quán và D19 ổn định mới đóng kẹp.
- D19 kích hoạt trước tư thế/ảnh gắp cuối, mất vật, ảnh không phản hồi, sai khóa hoặc bị che giữa hành trình: giữ tại chỗ; không hạ mù.
- Khi nâng: P1/P10 chạy ngược quỹ đạo, kiểm tra IR còn giữ vật. Đưa tới BIN rồi mới mở nắp/thả.
- D18: giữ luồng nhận rác sau; rút P1/P10 trước khi xoay nhìn sau.

## Phạm vi phép đo

27 cm là số đo của bố trí tham chiếu bạn đã xác nhận. Một ảnh gắp gần không tự tạo được phép đo cm liên tục ở mọi góc tay.
Chương trình không đưa ma trận giấy SEARCH vào ảnh khi tay đã hạ và không hiển thị 27 cm như khoảng cách hiện tại của một chai bất kỳ.
Các ngưỡng rộng/cao/tâm box trong `confirmed_grasp` là dung sai thử cho ảnh gần, chưa đo kiểm ngoài robot; ảnh gốc không được dùng như mẫu kích thước chung cho mọi loại rác.
Nếu hạ tới tư thế cuối mà D19 không thấy chai, robot giữ tại chỗ; không chạy bánh tại tư thế gắp cuối để đuổi theo chai. Nhịp bánh ở tư thế trung gian có giới hạn, kiểm tra D18/D19 và phản hồi ảnh sau từng nhịp.

Cấu hình và kiểm thử không chứng nhận quỹ đạo cơ khí an toàn cho mọi vị trí. Chưa chạy thử trên robot thật.
