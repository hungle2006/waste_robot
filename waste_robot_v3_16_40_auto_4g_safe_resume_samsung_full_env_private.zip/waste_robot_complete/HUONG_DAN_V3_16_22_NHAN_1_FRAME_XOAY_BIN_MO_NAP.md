# Waste Robot V3.16.22 — nhận diện BIN một ảnh, xoay thùng, mở nắp trước khi gắp

## Yêu cầu được triển khai

1. Ở SEARCH, ảnh Modal **đầu tiên hợp lệ và không mơ hồ** được dùng ngay để khóa nhãn/BIN (trước đây chờ 3 frame cùng BIN).
2. Dừng bánh/tay tại SEARCH, D3 mở, nắp P4 đóng; xoay thùng P9 theo BIN đã khóa.
3. Kiểm tra xung lệnh P9, sau đó **mở nắp P4 = 1600 µs ngay**; không đợi đến lúc tay đưa rác tới PLACE mới mở.
4. Vẫn ở SEARCH, tính góc chai theo vùng vật từ camera; **kiểm tra độc lập 3 góc hợp lệ liên tiếp**, cho phép tối đa 9 ảnh thử khi ảnh lỗi, giữ quy ước `ratio > 1.0` và giới hạn góc phải +60°. Đây là kiểm tra **góc**, KHÔNG phải bỏ qua nhận diện ban đầu một ảnh.
5. Chỉ tiếp tục căn ngang/tiến/hạ tay nếu góc tin cậy. Khi VL53 xác nhận 200–250 mm, D2 mới quay đến góc đã nhớ, sau đó hạ tay và dùng D19 để cho phép đóng kẹp D3 = 2300 µs.
6. Sau khi nâng và đến vị trí PLACE, vì nắp đã mở sẵn nên **không mở nắp lần thứ hai**; xác nhận lệnh mở P4 vẫn hợp lệ trước khi thả. Rút tay rồi mới đóng nắp, kết thúc chu trình.
7. Nếu việc đo góc lỗi khi tay còn ở SEARCH thì đóng nắp lại rồi HOLD. D18 (đường nhận rác phía sau) vẫn có luồng riêng, không bị chuyển sang cơ chế mở sớm này.

## Tập tin được thay đổi

- `python/robot_params.py`: mặc định `target_lock.classify_frames = 1`, `confirm_frames = 2` vẫn giữ cho lúc tìm lại vật đã khóa.
- `python/auto_config.json`: áp dụng chính xác `target_lock.classify_frames = 1` tại runtime.
- `python/target_lock.py`: cho phép cấu hình `classify_frames = 1` (giới hạn 1–7).
- `python/box_tof_flow.py`: thay thứ tự thành detect → xoay BIN + mở nắp → tính góc tại SEARCH → tiếp cận/gắp; tự đóng nắp nếu góc không hợp lệ ở SEARCH.
- `python/auto_controller.py`: bổ sung mở nắp sớm có kiểm tra tư thế SEARCH / D19 / D18, không lặp lệnh mở ở PLACE nếu đã mở trước.
- `tests/test_v31622_first_frame_bin_lid.py`: kiểm thử thay đổi mới.

## Giữ nguyên

- Lateral LEFT/RIGHT x2 và các nhịp FORWARD; giới hạn 30 lần quay tìm rác.
- Ghi nhớ góc tại SEARCH và chỉ xoay D2 sau khi VL53 nhận 20–25 cm.
- Xung gắp S1/P10=650 µs, S2/P1=2310 µs; đóng kẹp D3=2300 µs.
- Bảo vệ mất chai D19, tự lùi tối đa 10 nhịp khi rơi lần đầu, thử gắp lại một lần; rơi tiếp HOLD.
- D18, đổi quà 120 giây sau hoàn tất lượt nhận rác phía sau.
- Arduino firmware không thay đổi.

## Cảnh báo và giới hạn thử nghiệm

- **Chưa kiểm thử trên phần cứng**. Một ảnh đơn có nguy cơ nhận nhầm BIN; nếu nhiều vật cùng ở tâm thì mô-đun lựa chọn mục tiêu vẫn chờ, không tự đoán.
- **Nắp sẽ mở trong lúc robot tiếp cận và gắp**, không chỉ ở PLACE. Cần xác nhận vùng mở nắp không va tay gắp, bánh, người hoặc đồ vật khi robot di chuyển.
- Xung mà firmware xác nhận không đồng nghĩa có cảm biến đo góc thực của P9/P4. Quan sát chuyển động cơ khí khi chạy thử.
- Nếu AUTO bị STOP khẩn cấp, firmware có thể giữ nắp ở trạng thái đang mở. Chỉ xử lý MANUAL sau khi bảo đảm tay/bánh đã dừng an toàn.
- Kiểm tra D19 và VL53 trước khi gắp vẫn bắt buộc. Không gắp chỉ vì đã nhìn thấy một ảnh.

## Kiểm thử

Chạy trong thư mục `waste_robot_complete`:

```bash
PYTHONPATH=python:tests python -m pytest -q tests/test_v31622_first_frame_bin_lid.py tests/test_v31621_pca1_clamp60.py tests/test_v31620_orientation_retry.py tests/test_auto_orientation_v31617.py tests/test_v31619_drop_reverse.py tests/test_v31618_drop_topbottom.py
```

Kiểm thử mô phỏng không thay thế việc chạy thật có người giám sát và STOP.
