# Waste Robot V3.16.28 — Jetson Nano + VS Code (tự cài khi chạy main)

## Cách khởi chạy

1. Giải nén tệp ZIP; mở thư mục **`waste_robot_complete`** trong VS Code trên Jetson Nano.
2. Đảm bảo Jetson đã kết nối Internet cho lần chạy đầu; cắm Arduino và USB camera.
3. Mở `python/main.py`, chọn **Run Python File** trong VS Code, hoặc dùng Terminal:

   ```bash
   python3 python/main.py
   ```

   Hoặc trong VS Code dùng **Terminal → Run Build Task** để chạy tác vụ mặc định.

4. Lần đầu `main.py` tự tải **Miniforge ARM64 chính thức** vào `~/.local/share/waste-robot/miniforge3` và tạo **Python 3.10**, OpenCV, NumPy, Pillow từ conda-forge, rồi tự cài các gói Supabase, HTTPX, FastAPI, Uvicorn, pyserial và python-dotenv bằng pip trong môi trường riêng. Không yêu cầu thay Python hệ thống hoặc `sudo pip`.
5. Các lần sau **tự tái sử dụng môi trường đã cài**; chỉ chạy pip lại nếu requirements thay đổi hoặc thiếu thư viện. Chương trình tự chạy tiếp sau khi thiết lập xong.
6. Bấm **Kết nối** Arduino trong app theo quy trình cũ. Giao diện camera có thể mở tại `http://127.0.0.1:8766/control` trên Jetson (nếu có giao diện đồ họa).

### Kiểm tra trước khi cho robot di chuyển

```bash
python3 python/main.py --diagnose
```

Đây là bước kiểm tra phiên bản Python, cv2, đường dẫn COM/USB và camera **không phát lệnh chuyển động**. Lần đầu vẫn tự thiết lập môi trường.

## Lý do camera chạy khác trên Jetson Nano

Jetson Nano chính thức sử dụng JetPack 4/Ubuntu 18.04/Python 3.6; bản Python LiveKit RTC hiện tại cần **glibc ≥ 2.28**, nhưng Ubuntu 18.04 cung cấp **glibc 2.27**. Do đó **không thể tự động cài LiveKit RTC mới chỉ bằng pip hoặc cập nhật Python**.

Để vẫn có thể nhận diện, bản này dùng:

**USB camera trên Jetson → OpenCV → ảnh JPEG không vẽ đè → API Modal AI được cấu hình trong app Vercel**.

Kết quả dùng nguyên pipeline AUTO/D18/D19/VL53 và local dashboard. **Truyền video LiveKit lên Vercel không chạy trên Jetson Nano JetPack 4**; người dùng xem camera qua trang nội bộ hoặc cần một giải pháp relay riêng tương thích nếu muốn xem từ xa. Nếu app chưa cấu hình `modalAiUrl`, camera vẫn có thể hiển thị nhưng AUTO không thể phân loại.

* Camera mặc định index 0, 640×360, FPS 15 theo `python/robot_params.py`. USB webcam phải hỗ trợ 16:9. Không tự kéo giãn ảnh làm sai hiệu chuẩn.
* Nếu dùng camera CSI thay USB, cần sửa đường dẫn GStreamer và kiểm tra hiệu chuẩn camera. Bản này mặc định **USB camera**.

## COM và quyền Linux

Jetson thường có thiết bị Arduino tại `/dev/ttyACM0` hoặc `/dev/ttyUSB0` thay vì `COM3`. Đặt `ARDUINO_PORT` trong `python/.env` nếu cần. Ví dụ:

```bash
cp python/.env.example python/.env
# sửa ARDUINO_PORT trong python/.env theo tên thiết bị thực tế
ls /dev/ttyACM* /dev/ttyUSB* 2>/dev/null
```

Nếu Linux báo permission denied với thiết bị serial, chạy **một lần** `sudo usermod -aG dialout "$USER"` và **đăng xuất/đăng nhập lại**. Không tự động thay đổi quyền thiết bị khi chạy chương trình.

## Nếu đã có .env ở bản cũ

Sao chép **riêng file `.env` của bạn** từ bản cũ vào `python/.env` (không chia sẻ file này). ZIP mới chỉ chứa `.env.example` để tránh phát tán API key. Nếu dùng chế độ Jetson và muốn ép camera local: đặt `JETSON_LOCAL_CAMERA=1`, `LIVEKIT_VIEWER=0`, `LIVEKIT_PUBLISHER=0`.

## Trường hợp lỗi

* **Miniforge tải không được:** Internet GitHub/conda-forge bị chặn, hết dung lượng thẻ SD hoặc chứng chỉ HTTPS lỗi. Xem log trên Terminal; chương trình thoát, không chạy robot khi chưa cài xong.
* **Camera chưa có ảnh:** kiểm tra `/dev/video0`, chỉ số `CAMERA_INDEX`, cổng USB và tỷ lệ 16:9. Task camera tự thử kết nối lại sau 5 giây; không tự di chuyển khi mất ảnh.
* **Không bấm được Kết nối Arduino:** cắm cáp USB dữ liệu, kiểm tra `ARDUINO_PORT` và quyền nhóm `dialout`.
* **Không mở được local dashboard:** mở URL thủ công; nếu chạy SSH từ máy khác, forward cổng 8766 trong VS Code.
* **Supabase / Modal chưa cấu hình:** ứng dụng cần Internet và cấu hình dịch vụ đã triển khai; tự cài thư viện không thay thế các khóa/dịch vụ.

## Ghi chú an toàn

Toàn bộ AUTO V3.16.27 được giữ nguyên. Phần đổi ở V3.16.28 là khởi chạy, môi trường Python và nguồn camera local; không sửa firmware, chân servo hay các thông số thời gian gắp. Dù bộ cài và kiểm thử mã hoạt động, **chưa thể xác nhận trên Jetson Nano thật**. Lần đầu hãy chạy `--diagnose`, thử khi bánh không chạm sàn, xác nhận STOP và cảm biến D18/D19/VL53 trước khi gắp tự động.
