# Kiểm thử và triển khai V3.15

## Kết quả

| Kiểm tra | Kết quả |
|---|---|
| Toàn bộ bộ kiểm thử Python | 396 đạt, 4 cảnh báo deprecation của Starlette/httpx |
| Kiểm tra riêng operator sau sửa cuối | 34 đạt |
| Giao diện React DOM | 4 đạt |
| Next.js production build và TypeScript | Đạt |
| check_system.py | Đạt |
| demo_auto.py | Hoàn tất 1 chu trình Auto mô phỏng, xác nhận thả vật |
| Cú pháp Python | 31 tệp nguồn đọc/parse thành công |
| Arduino | 81 tệp giữ nguyên so với bản trước |
| .env | Giữ nguyên nội dung bản trước |
| Các module Depth đã loại bỏ | Không được đưa trở lại |
| Trang production và cấu hình realtime | HTTP 200; Supabase và LiveKit đã cấu hình |

Nhật ký nằm trong thư mục `verification/`. 34 bài kiểm tra riêng là kiểm tra lại một phần bộ 396, không cộng thành tổng mới.

Các trường hợp được kiểm tra gồm: chuyển đỏ khi Auto đang chạy, hủy chuyển động cũ, chế độ đỏ không tự gửi lệnh cơ khí, điều khiển tay hoạt động, XM chỉ dừng bánh ở chế độ đỏ, từ chối lệnh cũ/trùng, mẫu VL53 mới độc lập, mục tiêu hết hạn, S1 trước S2, giữ góc D2 khi nâng, chu trình gắp/thả mô phỏng, không xoay ngăn/đóng nắp dưới tay khi đã ở PLACE, và không tự xoay theo ảnh khi chưa hiệu chuẩn.

## Ứng dụng đã triển khai

- Địa chỉ: https://waste-app-control.vercel.app
- Mã nguồn ứng dụng: https://github.com/hungle2006/Waste_App
- Commit: `6f0174efd07c4aceb06269e7c6764c2e81c6bad4`
- Deployment Vercel: `dpl_3exHdh3LP9W3VBhNwPVvHr3ZEUzx`, trạng thái `READY`, production.

Ứng dụng web dùng giao thức operator phiên bản 1; cần chạy Python mới trong ZIP này để các nút mới hoạt động. Mã nguồn web đã lưu trong kho GitHub; ZIP chứa đầy đủ bộ robot và trang điều khiển cục bộ `web/operator.html`.

## Chạy lại

Trong thư mục gốc đã giải nén, sau khi cài các dependencies trong `python/` và pytest:

```sh
python -m pytest tests -q
python python/check_system.py
python python/demo_auto.py
```

Trong kho Waste_App, sau `npm ci`:

```sh
npm test -- --run
npm run build
```

## Phạm vi đã xác minh

Chưa nối Arduino, camera, cảm biến hoặc cơ khí thật trong môi trường kiểm thử. Chưa xác minh giao diện bằng ảnh chụp trình duyệt: Chromium bị môi trường chặn tạo socket, nên kiểm tra giao diện dựa trên React DOM và production build. HTTP 200 không thay thế việc kiểm tra luồng robot thật.

Xoay D2 tự động theo ảnh mặc định tắt vì cần hiệu chuẩn camera với càng tại tư thế gắp. Nhận diện và ước lượng hướng có thể thất bại khi vật bị che, nền khó tách hoặc ảnh bị cắt. Xem `HUONG_DAN_V3_15.md` để biết điều kiện và cách hiệu chuẩn. Không có cam kết nhận diện hoàn hảo từ các kết quả phần mềm/mô phỏng này.
