# V3.16.10 — D4 Arduino, đóng kẹp 2000 us, VL53L1X ROI 10×10

Bản này được sửa từ đúng tệp `waste_robot_v3_16_4_auto_continue_full_env (1).zip` bạn gửi. Tệp cấu hình tài khoản `.env`, thư viện Arduino và các tệp gốc được giữ đầy đủ. Ưu tiên hướng dẫn này khi tài liệu lịch sử bên dưới có thông tin khác.

## 1. Bảng chân và hoạt động

| Bộ phận | Chân/kênh | Hoạt động |
|---|---|---|
| Servo Đổi quà | **Digital D4 trên Arduino Mega** | Ban đầu 2500 us; nhấn Đổi quà → 600 us → giữ 800 ms → về 2500 us |
| Càng kẹp | Digital D3 trên Arduino Mega | Mở 600 us; đóng 2000 us |
| Xoay càng | Digital D2 trên Arduino Mega | Giữ cấu hình của tệp gốc |
| Xoay thùng rác | PCA9685 kênh 9, P9 | Các ngăn giữ theo cấu hình gốc |
| Nắp thùng | PCA9685 kênh 4, P4 | Độc lập với digital D4 trên Arduino |
| VL53L1X | SDA20, SCL21 trên Mega; địa chỉ 0x29 | Short, ROI10×10, tâm SPAD199, budget50 ms, period60 ms |
| PCA9685 | SDA20, SCL21 trên Mega; địa chỉ 0x40 | Dùng chung bus I2C với VL53L1X |

Dây tín hiệu servo quà nối vào **D4 của Arduino**, không cắm vào P4 của PCA9685. Servo dùng nguồn ngoài phù hợp và chung GND với Arduino.

## 2. Hai biến xung quà có thể sửa

Mở `python/gift_params.py`:

```python
GIFT_OPEN_US = 600
GIFT_CLOSE_US = 2500
GIFT_OPEN_HOLD_MS = 800
GIFT_CLOSE_SETTLE_MS = 500
```

- `GIFT_OPEN_US`: vị trí mở/nhả quà.
- `GIFT_CLOSE_US`: vị trí ban đầu và vị trí trả về.
- `GIFT_OPEN_HOLD_MS`: thời gian giữ mở, đơn vị ms.
- `GIFT_CLOSE_SETTLE_MS`: thời gian chờ đóng trước khi nhận lượt tiếp theo.

Xung phải là số nguyên trong 500–2500 us, hai vị trí phải khác nhau. Lưu tệp: lần bấm tiếp theo đọc tham số mới, không cần khởi động lại Python chỉ để đổi xung quà. Lượt đang chạy giữ bộ tham số đã nhận khi bắt đầu.

D4 được khởi tạo về xung đóng sau khi kết nối Arduino/cho phép điều khiển. Arduino vừa bật vẫn STOP và chưa tự phát quà. **Bản gốc V3.16.4 tự chạy tư thế SEARCH khi kết nối hoặc RESUME; bản này giữ hành vi đó.** D4 khởi tạo đóng trước khi chạy SEARCH.

## 3. Đóng càng kẹp ở 2000 us

Trong `python/robot_params.py`:

```python
'grip': {'open': 600, 'close': 2000}
```

`python/robot_config.json` cũng đã cập nhật cùng giá trị cho cách chạy cấu hình JSON. Nút Đóng kẹp và chu trình AUTO dùng mục tiêu 2000 us. Để thay đổi cấu hình tay/kẹp, STOP rồi chạy lại Python. Xung là lệnh điều khiển, không phải góc hoặc lực đo được.

## 4. Cảm biến khoảng cách 10×10

Firmware chính `arduino/robot_control_v3/robot_control_v3.ino`:

```cpp
const uint8_t TOF_ROI_SIZE=10, TOF_ROI_CENTER=199;
// ...
tofSensor.setROISize(TOF_ROI_SIZE, TOF_ROI_SIZE);
tofSensor.setROICenter(TOF_ROI_CENTER);
```

Mã thử riêng `arduino/vl53l1x_test/vl53l1x_test.ino` cũng dùng `setROISize(10,10)`.

10×10 là kích thước vùng cảm nhận SPAD; mỗi lần đo vẫn trả về một khoảng cách mm, không phải một mảng 100 khoảng cách độc lập. Tài liệu thư viện: https://github.com/pololu/vl53l1x-arduino#library-reference

**Ngưỡng gắp được giữ ở 25–30 cm (250–300 mm) như ZIP gốc bạn gửi**, không tự đổi thành 20–25 cm. Trong `python/robot_params.py`:

```python
TOF_MIN_MM = 250
TOF_MAX_MM = 300
```

AUTO của V3.16.4 giữ chính sách tiến theo nhịp khi chưa có số đo/lỗi ToF; một số đo hợp lệ trong cửa sổ chuyển sang bước gắp, D19 vẫn xác nhận tiếp xúc. Giới hạn số nhịp/thời gian và STOP vẫn áp dụng. Xác nhận gắp bằng tay giữ cơ chế riêng của bản gốc.

Trạng thái Arduino bổ sung `tof.roi_size_configured=10`. Nếu vẫn nhận firmware cũ thiếu trường này hoặc ROI khác 10, Python từ chối bật nhịp AUTO và yêu cầu nạp firmware mới. Trường này báo cấu hình firmware, không phải phép đo chất lượng tín hiệu quang.

## 5. Nạp và chạy

1. Tắt nguồn khi chuyển dây servo quà sang digital D4 trên Arduino Mega.
2. Trong Arduino IDE chọn Mega 2560; nạp `arduino/robot_control_v3/robot_control_v3.ino` của ZIP này. Thư viện đi kèm nằm ở `arduino/libraries/`.
3. Đóng Serial Monitor và chạy Python trong ZIP mới theo `README_CHAY_TRUOC.md`. Không chạy lại Python của thư mục ZIP cũ.
4. Kiểm tra cấu hình offline, từ thư mục gốc: `python python/check_system.py`.
5. Mở waste-app hiện tại, kết nối Python; nút Đổi quà ở camera gửi `GIFT DISPENSE`. Không cần đổi giao thức nút của app.
6. Trang local `/control` cũng có nút Đổi quà, Dừng và mở rộng camera. Khi mở rộng, nút quà và Dừng nằm cùng khung camera.

## 6. Dừng, lỗi và kiểm thử

- Mỗi lần chỉ một lượt phát quà. Kênh realtime có cơ chế khử yêu cầu trùng ID; không tự phát lại sau khi kết nối lại.
- D4 độc lập với quyền điều khiển cánh tay, nên có thể phát quà trong khi AUTO vẫn chạy nếu kết nối còn hợp lệ và chưa STOP.
- STOP, mất USB hoặc reset hủy lượt quà. Không có lệnh đóng trễ tự chạy sau STOP. Kết nối/RESUME chỉ khởi tạo lại vị trí đóng D4; không phát lại lượt quà bị hủy. Các khớp tay vẫn theo cơ chế SEARCH của bản gốc.
- Thông báo hoàn tất là hoàn tất chu trình lệnh; chưa có cảm biến quà rơi, vị trí hay lực servo.
- Kết quả kiểm thử ở `verification/v31610_*`. Kiểm tra gồm Python, API nút quà, ROI10, xung D3/D4, hủy/STOP, AUTO và biên dịch sketch trên máy tính với phần cứng giả lập.
- Chưa kiểm tra robot thật, độ chính xác quang học của ROI10 hay biên dịch cho bo AVR. Cần thử thực tế cơ cấu đã lắp để xác nhận quà rơi và xung phù hợp.
