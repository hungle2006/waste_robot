# Waste Robot V3.16.23 — D19 chỉ dùng khi gắp / đang giữ vật; xử lý rơi trong 15 giây

## Luồng mới

1. SEARCH: Camera nhận diện vật ngay ảnh hợp lệ đầu; thùng xoay BIN, mở nắp; đo và lưu góc vật tại SEARCH (vẫn xác nhận 3 ảnh góc hợp lệ). Trong các nhịp quay tìm, căn trái/phải, tiến camera, tiếp cận VL53, **không dùng D19 để dừng bánh/hạ tay**. D18, VL53, STOP và giới hạn thời gian vẫn hoạt động.
2. VL53 xác nhận khoảng 200–250 mm: D2 xoay theo góc SEARCH; hạ tay P1=2310 µs, P10=650 µs.
3. Chỉ khi đã ở tư thế gắp cuối, kích hoạt điều kiện IR D19; D19 nhận ổn định 300 ms thì mới đóng D3=2300 µs. Khi D19 chưa thấy vật ở tư thế cuối, robot tiến từng nhịp 160 ms có kiểm soát.
4. Sau khi đã đóng kẹp và mang chai, D19 lại là cảm biến giữ vật. Khi D19 mất tín hiệu, robot phanh bánh; nếu tay đang di chuyển, Python hủy an toàn tác vụ servo hiện tại (giữ xung hiện tại). Robot kiểm tra D19 **đến 15 giây**.
   - D19 xuất hiện trở lại ổn định 300 ms trong 15 giây: tiếp tục chuyển động đang dở, không coi là rơi.
   - D19 không thấy liên tục trong hết 15 giây: xác nhận mất tín hiệu, hủy lượt đưa vào thùng (không tính hoàn tất/không cấp quyền đổi quà); thu tay về SEARCH nếu tư thế cho phép, đóng nắp, mở kẹp và bắt đầu lùi tìm vật.
5. Tại SEARCH, dùng camera kiểm tra trước khi lùi. Nếu chưa thấy, **BACK tối đa 10 nhịp**. Mỗi nhịp BACK **400 ms danh định** (khoảng 560 ms thực thi nếu ramp160), dừng **2 giây**, chụp camera ảnh mới. Thấy vật là ngừng lùi, khóa vật và tính lại góc từ đầu.
6. Hết 10 nhịp lùi mà chưa thấy vật: chuyển sang chu trình quay tại chỗ sang phải (~5 giây quay, 1 giây dừng), quét tối đa 30 lượt; nếu vẫn không thấy thì AUTO tắt.
7. Nếu rơi lần thứ hai trong lượt gắp lại, HOLD và yêu cầu người vận hành kiểm tra thay vì thử lại vô hạn.

## Firmware mới — BẮT BUỘC NẠP CÙNG PYTHON

Mở `arduino/robot_control_v3/robot_control_v3.ino`, biên dịch/nạp lên Arduino Mega 2560. Firmware hỗ trợ thêm lệnh `IG 0` (D19 không chặn bánh khi tìm/căn/tiến) và `IG 1` (D19 chặn bánh khi gắp cuối). Python xác nhận trạng thái `ir_drive_guard` trong STATUS; bản firmware cũ sẽ không cho khởi chạy AUTO, tránh tình trạng chỉ sửa Python nhưng Arduino vẫn chặn lệnh bánh.

- D18 vẫn chặn chuyển động; VL53 vẫn bảo vệ khoảng cách; STOP, hết phiên USB và watchdog vẫn ưu tiên dừng.
- Firmware mặc định `IG 1` sau khởi động, STOP và RESUME; Python tự đổi trạng thái theo giai đoạn AUTO. Khi AUTO kết thúc/HOLD, chương trình trả lại `IG 1`.
- Phần mô phỏng Python (`transport.py`) được cập nhật cùng ngữ nghĩa firmware.

## Lưu ý cơ khí

**Chưa thử robot thật.** D19 là cảm biến hiện diện, không đo lực kẹp; tín hiệu mất 15 giây chỉ chứng minh D19 không còn thấy vật, không chứng minh chai đã rơi xuống đâu. Khi tay ở tư thế cơ khí không nhận dạng an toàn, phần mềm giữ/dừng, không cố tự thu hoặc tự lùi.

Robot hiện không có cảm biến chướng ngại phía sau: lùi 10 nhịp là nguy cơ va chạm nếu phía sau có người hoặc đồ. Thử trong vùng có kiểm soát, không để người đứng sau robot, có STOP vật lý và kiểm tra giới hạn servo/khoảng hở nắp. Nhịp quay phải 5 giây không đảm bảo đúng 360° vì thiếu cảm biến góc.

## Tệp chính đã chỉnh

- `python/robot_params.py`: 15 giây kiểm tra D19, BACK nghỉ 2000 ms.
- `python/auto_controller.py`: trạng thái D19 theo giai đoạn, gián đoạn servo có kiểm soát, xử lý tín hiệu trở lại/mất liên tục, lùi 400ms×10 + dừng 2s.
- `python/box_tof_flow.py`: bỏ rẽ nhánh D19 sớm trong tìm/căn/tiến; chỉ bật D19 ở bước gắp cuối.
- `python/brain.py`: đổi gate IG với xác nhận firmware và hủy mềm tác vụ servo khi mất vật.
- `python/transport.py`: mô phỏng IG để kiểm thử.
- `arduino/robot_control_v3/robot_control_v3.ino`: firmware hỗ trợ IG và STATUS.
- `tests/test_v31623_ir_transport_backtrack.py`: kiểm thử riêng các hành vi mới.

Cú pháp Python và các kiểm thử ngắn đã được kiểm tra. Bài mô phỏng đầu-cuối dài chưa hoàn thành trong phiên kiểm tra. Chưa biên dịch trực tiếp trên Arduino IDE/Arduino CLI hoặc thử với phần cứng thật.
