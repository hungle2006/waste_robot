# Waste Robot V3.16.29 — Cài thử thư viện LiveKit trên NVIDIA Jetson Nano

## Chạy một lệnh kiểm tra, KHÔNG điều khiển robot

Mở dự án trong VS Code trên Jetson, chạy Terminal:

```bash
python3 python/main.py --try-livekit
```

Hoặc chọn **Terminal → Run Task → Thử cài LiveKit RTC (không chạy robot)**.

- `main.py` vẫn tự dựng Python 3.10 và phụ thuộc robot cơ bản (nếu chưa có), sau đó mở **môi trường thử nghiệm riêng** tại `~/.local/share/waste-robot/livekit-test`.
- Thử cài `livekit==1.1.21` và `livekit-api==1.2.2` bằng pip với `--only-binary=:all:`. Không build Rust/C++, không dùng sudo pip và không nâng cấp JetPack.
- Nếu cài được, thử `from livekit import rtc, api` và kiểm tra API căn bản; nếu không được, hiển thị lỗi và thoát. Kết quả không chứa API key ở `~/.local/share/waste-robot/livekit-test-result.json`.
- **Không chạy camera, Arduino, động cơ, LiveKit room hoặc thay đổi cấu hình AUTO** trong lệnh thử này.

## Giới hạn cần hiểu

Bản wheel LiveKit RTC ARM64 1.1.21 phát hành trên PyPI sử dụng `manylinux_2_28_aarch64` (cần glibc >= 2.28). JetPack 4/Ubuntu 18.04 thường có glibc 2.27, nên rất có thể **không cài được trên Jetson Nano gốc**, cho dù đã nâng Python lên 3.10.

Đừng chạy `sudo pip install livekit`, đừng cố thay glibc hệ thống. Nếu pip báo `No matching distribution found for livekit==1.1.21`, đây có thể là vấn đề tương thích, không phải lỗi chương trình gắp rác.

**Lưu ý**: Cài/import LiveKit thành công trong *venv thử nghiệm* không tự chuyển robot sang phát LiveKit. Muốn phát video cần tích hợp SDK vào luồng camera, LiveKit URL, quyền truy cập và kiểm thử kết nối riêng; không bật cờ `LIVEKIT_PUBLISHER=1` cho Jetson Nano cũ trước khi xác minh đủ điều kiện.

## Sử dụng robot như hiện tại

```bash
python3 python/main.py
```

Chương trình tiếp tục dùng OpenCV đọc camera và Modal AI như V3.16.28. Logic D18, D19, AUTO/MANUAL, checkpoint, xung servo và firmware không thay đổi. Máy thử không có Jetson Nano thật, nên chưa thể xác nhận cài đặt trên thiết bị của bạn.
