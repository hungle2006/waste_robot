# Waste Robot V3.16 · Xoay 10° và gắp theo cảm biến

Chạy Python **trong ZIP mới này**, rồi tải lại https://waste-app-control.vercel.app/ và bấm **Kết nối Python**. Khởi động bằng trình chạy có sẵn hoặc `python main.py` trong thư mục `python`. Trang cục bộ: http://127.0.0.1:8766/control khi giao diện hiệu chuẩn được bật. Bộ Arduino và `.env` giữ nguyên từ V3.15.

## Xoay càng kẹp

Trong **Cánh tay**, phần **Xoay càng D2** hiển thị hướng và góc, có **Trái 10°**, **Phải 10°**, **0° Oy**. Dùng được ở Manual và Auto đỏ. Khi Auto xanh đang sở hữu cơ khí, hãy chuyển đỏ trước. Đổi màn hình Manual/Auto chỉ đổi cách xem; không tự tước quyền một chu trình đang chạy.

| Mốc | Xung D2 |
|---|---:|
| Trái 90° | 500 µs |
| Thẳng Oy, 0° | 2100 µs |
| Phải 60° | 2500 µs |

Góc hiển thị là **ước tính theo xung Arduino đã nhận**, chưa có encoder đo góc thật. Nội suy riêng hai phía. Mỗi nhấn đổi 10°, lần cuối nếu gần giới hạn sẽ dừng tại giới hạn; không quay vòng từ phải 60° về trái. Nút 0° đưa về 2100 µs. Python tính bước từ xung vừa xác nhận, không lấy bản nháp trên thanh kéo. Khi đang chuyển động hoặc chờ ACK, không xếp thêm bước.

Thanh D2 và ô nhập µs vẫn dùng để chỉnh nhỏ. Nút 10° hủy bản nháp D2 để bảng nhập tiếp tục theo xung đã nhận. Các ngưỡng servo của cấu hình vẫn được Arduino/Python kiểm tra.

## Gắp theo cảm biến: đủ điều kiện thì bấm một lần

Nút **Gắp theo cảm biến** có ở cả Manual và Auto đỏ; **không cần nhãn/box AI**.

1. Chọn ngăn thả trong **Thùng & nắp**. Mặc định sau SEARCH, thùng đang ở một ngăn cấu hình; chương trình hiển thị đúng ngăn hiện tại.
2. Đưa tay về SEARCH hoặc một điểm đúng trên quỹ đạo P1/P10/P11 đã đo; mở kẹp. Bạn căn bánh bằng tay, dừng bánh rồi chỉnh góc D2 nếu cần.
3. Chờ ba mẫu VL53 mới, hợp lệ, khác số thứ tự, trong khoảng cấu hình (mặc định **250–300 mm / 25–30 cm**). Không lấy nhiều lần cùng một mẫu để tính đủ ba. Đổi tư thế, đang chạy bánh/tay, mất USB hoặc dữ liệu cũ sẽ xóa xác nhận.
4. Khi hiện **Sẵn sàng · bấm Gắp theo cảm biến**, bấm một lần. Tay đi **S1 rồi S2** theo quỹ đạo tới vị trí cuối. Tín hiệu D19 đến trước vị trí cuối thì giữ tại chỗ, không hạ tiếp. Tại vị trí cuối, D19 phải ổn định mới đóng kẹp, sau đó nâng về SEARCH và giữ nguyên D2.
5. Sau khi nâng, bấm **Thả vật vào thùng**. Chuỗi dùng ngăn đã ghi nhận lúc gắp: đưa vật tới thùng, mở nắp, mở kẹp, xác nhận D19 hết thấy vật, rút tay, đóng nắp.

Nếu tay đã ở vị trí cuối và D19 thấy vật, có thể bấm gắp tại đó dù VL53 không còn nhìn đúng vùng đo. Chuỗi vẫn xác nhận D19 ổn định trước khi đóng. Nút gắp **không tự chạy bánh**, không bỏ qua tư thế hoặc cảm biến để cố hoàn tất. Tắt tự phân loại phía sau D18 trước khi gắp/nâng/thả bằng tay.

Gắp theo cảm biến giữ góc D2 bạn đã chọn, kể cả trong lúc hạ tay. Trong Auto đỏ còn có **Gắp và nâng vật** theo mục tiêu AI, giữ yêu cầu khóa vật của V3.15. Tự xoay theo hướng ảnh vẫn cần hiệu chuẩn camera–càng và mặc định tắt.

## Các nút hoàn tất thao tác

| Nút / nhóm | Công dụng |
|---|---|
| Mở / đóng càng kẹp | Điều khiển D3 trực tiếp bằng tay |
| Nâng / rút tay · giữ góc kẹp | Rút theo quỹ đạo đã đo; giữ D2. Đang kẹp thì phải có D19 xác nhận giữ vật |
| Giữ vị trí | Hủy phần chuyển động còn lại, phanh bánh, giữ xung servo; chuyển quyền cơ khí về người dùng. Camera Auto đang chạy thì tiếp tục quan sát |
| Dừng khẩn / Dừng cơ khí | STOP toàn bộ và khóa xung theo firmware; cần **Cho phép điều khiển** để chạy lại |
| Tư thế có sẵn & lưu tư thế | SETUP, SEARCH, PLACE, REAR; nhập/lưu các khớp theo cơ chế cấu hình hiện có |
| Bánh xe | Tám hướng, quay tại chỗ, cua cung, PWM, dừng bánh; giữ chạy/thả dừng |
| Thùng & nắp | Bốn ngăn, mở/đóng nắp, D18/D19, bật/tắt tự phân loại phía sau |
| Auto & lệnh | Trạng thái nhận diện, khoảng cách, lệnh dự kiến và lệnh Arduino đã ACK |

**Giữ vị trí khác STOP:** giữ vị trí để giữ vật, STOP theo firmware cắt xung/khóa cơ khí. Không có nút tự chạy tiếp đoạn cũ sau khi hủy; bạn chọn thao tác mới từ trạng thái hiện tại.

## Thay đổi logic

- Giao thức operator phiên bản 2; web nhận diện Python cũ và khóa các nút mới kèm hướng dẫn nâng cấp.
- Theo dõi khoảng cách ngay cả khi không bật Auto/camera. Quá trình này chỉ đọc cảm biến, không tự di chuyển.
- Trước bước hạ tay, đọc STATUS USB mới để tránh bỏ lỡ D19 vừa đến giữa hai lần thăm dò nền. Đọc lại tại vị trí cuối trước khi xác nhận kẹp.
- Từ chối lệnh cũ, lệnh lặp, thao tác khi bận, mất kết nối, Auto đang nắm quyền hoặc tư thế ngoài quỹ đạo.
- Chuyển nhóm điều khiển vẫn giữ nguyên luồng camera; đang giữ bánh mà chuyển nhóm thì phanh bánh.

Các thử nghiệm trong `KIEM_THU_V3_16.md` là phần mềm/mô phỏng. Chưa nối robot thực trong môi trường này. Kiểm tra góc D2, hành trình S1/S2, chiều bánh, VL53 và D19 trên robot của bạn trước khi dùng với tải. Không cam kết nhận diện hay cơ khí hoàn hảo từ kiểm thử mô phỏng.
