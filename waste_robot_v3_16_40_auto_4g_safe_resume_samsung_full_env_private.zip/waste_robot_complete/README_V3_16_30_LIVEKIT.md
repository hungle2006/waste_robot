# Waste Robot V3.16.30 — LiveKit tùy chọn trên Jetson Nano

Chạy `python3 python/main.py` để dùng OpenCV như trước. Để bật phát LiveKit, đặt `LIVEKIT_PUBLISHER=1` trong `python/.env` và cấu hình LiveKit trên ứng dụng Vercel. Chương trình dùng LiveKit SDK trong **môi trường Python chạy main.py**, không nhất thiết là `.venv` bạn vừa cài.

Kiểm tra đúng Python đang chạy: `python -c "from livekit import rtc; print('RTC OK')"`. Nếu bootstrap tạo môi trường riêng tại `~/.local/share/waste-robot/python310`, cài LiveKit vào môi trường đó bằng `~/.local/share/waste-robot/python310/bin/python -m pip install livekit==1.1.21`, sau đó thử import bằng chính đường dẫn Python này. Nếu hệ thống không tương thích glibc thì không ép cài.

Nếu chưa bật hoặc không import được SDK, camera OpenCV nội bộ vẫn hoạt động. Cài thành công không đảm bảo truyền hình ảnh: cần token endpoint và cấu hình LiveKit hợp lệ, camera hoạt động, kết nối mạng. Trường hợp publisher lỗi sau khi khởi chạy phải kiểm tra log; không khẳng định tự phục hồi trong mọi trường hợp.

LƯU Ý: Chưa thử trên Jetson Nano thật. Trước khi chạy AUTO, dùng `python3 python/main.py --diagnose` và thử khi bánh xe được nâng khỏi mặt đất.
