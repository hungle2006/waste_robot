# Waste Robot V3.16.31 — Jetson Nano + LiveKit + VS Code

## Mục tiêu

Đây là bản nâng cấp từ **V3.16.27** (D18 ưu tiên trong AUTO/MANUAL), thông qua các bản hỗ trợ Jetson V3.16.28–30. Logic điều khiển servo, IR D19, VL53, khôi phục AUTO khi ngắt COM và nhận diện liên tục vẫn giữ nguyên. **Chỉ thay nguồn camera, LiveKit, kiểm tra môi trường và khởi chạy**.

Luồng camera mới luôn là:

```
Jetson USB camera (mở 1 lần)
   ├── OpenCV → JPEG → Modal AI → SEARCH/AUTO/D18  (không phụ thuộc LiveKit)
   └── LiveKit RTC (nếu cài/nhập SDK được và đã có token) → Vercel
```

Khi LiveKit disconnect, phần camera OpenCV và điều khiển robot vẫn tiếp tục; sender phát LiveKit tự kết nối lại, không mở camera USB lần thứ hai. Không gửi ảnh đã vẽ nhãn/khung lên Modal AI.

## 1. Khởi động từ VS Code Jetson

1. Giải nén ZIP, mở thư mục `waste_robot_complete` trong VS Code. Không mở riêng thư mục `python` nếu bạn muốn dùng tác vụ VS Code.
2. Kiểm tra Jetson Nano thực tế bằng Terminal, không phải Terminal của máy ASUS nếu bạn đang Remote SSH:

   ```bash
   uname -m
   python3 --version
   ldd --version | head -n 1
   ```

3. Chạy kiểm tra KHÔNG làm robot chuyển động:

   ```bash
   python3 python/main.py --diagnose
   python3 python/main.py --livekit-check
   ```

   `--livekit-check` kiểm tra thư viện RTC/API trong Python đang được gọi và trong Python conda do robot quản lý (nếu đã có). Lệnh không sử dụng camera, COM3 hay servo.

4. Tạo cấu hình riêng **một lần**:

   ```bash
   cp python/.env.example python/.env
   ```

   Nếu bạn đã có `python/.env` của bản cũ, **giữ lại** và chỉ thêm các biến LiveKit bên dưới. Tuyệt đối không đưa file `.env` vào Git hoặc chia sẻ.

5. Với Jetson mặc định:

   ```dotenv
   JETSON_LOCAL_CAMERA=1
   LIVEKIT_PUBLISHER=auto
   LIVEKIT_VIEWER=0
   LIVEKIT_FPS=8
   ARDUINO_PORT=/dev/ttyACM0
   LIVEKIT_URL=wss://YOUR-PROJECT.livekit.cloud
   LIVEKIT_API_KEY=YOUR_KEY
   LIVEKIT_API_SECRET=YOUR_SECRET
   ```

   URL và API key/secret phải lấy từ LiveKit Cloud của **dự án đang cấu hình trên Vercel**, không điền giá trị ví dụ. `LIVEKIT_ROOM` có thể bỏ trống: hệ thống dùng `robotId` do ứng dụng cung cấp. Track mặc định là `front_camera` (hoặc theo cấu hình app).

6. Nhấn **Run Python File** trên `python/main.py`, bấm Ctrl+Shift+B để chạy tác vụ mặc định của dự án, hoặc:

   ```bash
   python3 python/main.py
   ```

   Lần đầu tự thiết lập thư viện Python trong môi trường cô lập nếu cần. Nếu `.venv` đã đủ phụ thuộc, chương trình ưu tiên dùng lại `.venv` **và LiveKit đã cài**; nếu `.venv` thiếu OpenCV/native runtime, chương trình có thể dùng Miniforge riêng và thử cài LiveKit trong đúng runtime khi hệ điều hành tương thích.

## 2. Khi nào LiveKit thực sự hoạt động?

| Kiểm tra | Ý nghĩa |
| --- | --- |
| `pip show livekit` | Chỉ xác nhận package hiện diện trong Python của `pip` |
| `from livekit import rtc, api` | SDK nạp được trong Python đã kiểm tra |
| `LIVEKIT_URL` + key/secret + Vercel LiveKit configured | Đủ cấu hình để thử kết nối room |
| Log `Đang phát camera lên phòng...` | Publisher đã kết nối và publish track |
| Video hiện trên app | Kết nối end-to-end được xác nhận bằng thực tế |

**Lưu ý phần cứng:** Jetson Nano với JetPack 4/Ubuntu 18.04 thường có glibc 2.27. LiveKit 1.1.21 ARM64 phân phối wheel yêu cầu glibc >=2.28, nên dù `pip install livekit` có thể thành công trên laptop/máy khác, không thể suy ra Jetson Nano nhập được `livekit.rtc`. Nếu import thất bại, chương trình KHÔNG phá hệ điều hành để nâng glibc; camera nội bộ vẫn chạy và AUTO vẫn nhận diện được. Cần một nền tảng ARM64/glibc phù hợp hoặc relay tương thích để phát LiveKit RTC.

## 3. Log thường gặp

- `[Jetson Setup] Dùng môi trường .venv hiện có` — thư viện Python được tái sử dụng, bao gồm LiveKit nếu nó ở đây.
- `[LiveKit] LiveKit RTC và API import thành công` — SDK sẵn sàng, nhưng chưa xác nhận kết nối phòng.
- `[LiveKit] ... chưa cấu hình ...` — vẫn có camera OpenCV; cần bổ sung `.env`/Vercel.
- `[LiveKit] Đang phát camera lên phòng ...` — phát camera bằng SDK.
- `[LiveKit] Mất kết nối hoặc lỗi phát camera ... thử lại` — tự kết nối lại; không làm gián đoạn nhận diện AUTO.
- `JETSON: camera index 0 hoạt động` — camera OpenCV cấp ảnh.

Giao diện nội bộ (nếu bật) tại **http://127.0.0.1:8766/control**. Máy khác cùng mạng dùng địa chỉ IP LAN của Jetson hoặc chuyển tiếp cổng VS Code; không tự công khai cổng này ra Internet.

## 4. Cảnh báo vận hành

- **Không được coi pip install thành công là đã test LiveKit trên Jetson**. Hãy chạy `--livekit-check` ngay trong Terminal Jetson.
- Bản ZIP **không** chứa `.env`, API secret, token, checkpoint cá nhân.
- Chưa kiểm thử trên phần cứng Jetson Nano, Arduino và LiveKit Cloud thực tế. Các kiểm thử Python chỉ mô phỏng luồng/tình huống; trước khi chạy robot trên sàn, thử khi bánh được nâng, kiểm tra STOP, D18, D19, VL53 và vật cản phía sau.
- Không chỉnh servo, chân điều khiển, firmware Arduino và không thay đổi thuật toán AUTO trong bản nâng cấp này.

## 5. Thư viện

- Mặc định: OpenCV/NumPy/Pillow, Supabase, HTTPX, FastAPI, Uvicorn, pyserial, dotenv.
- Tùy chọn để phát trực tiếp: `livekit==1.1.21`, `livekit-api==1.2.2` khi nền tảng hỗ trợ; kiểm tra `livekit.rtc` chứ không chỉ `livekit`.
- LiveKit vẫn cần kết nối Internet và khóa LiveKit của chính dự án đã triển khai.
