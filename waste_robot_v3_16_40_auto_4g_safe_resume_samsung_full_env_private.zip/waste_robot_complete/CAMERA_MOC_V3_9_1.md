> Tài liệu lịch sử trước V3.12. Với bản hiện tại, đọc README_CHAY_TRUOC.md và TINH_TOAN_V3_12.md.

# V3.9.1 — mốc kích hoạt trên video camera

## Bản này thay đổi gì?

- Vẽ mốc căn ngang bánh, vùng tâm mục tiêu của tay, đường chuyển bánh → tay và biên vùng mờ kẹp trên video USB phát qua LiveKit. App hiện tại nhận cùng track `front_camera`, không cần triển khai lại app.
- Trang hiệu chuẩn tại http://127.0.0.1:8766 cũng có mốc, kèm nút bật/tắt riêng cho ảnh xem tại trang này. Nút đó không tắt mốc trên LiveKit.
- Không vẽ box nhận diện. Hình chữ nhật xanh lá là vùng mục tiêu cố định theo cấu hình, không bám theo vật.
- Ảnh gốc được đưa vào cache nhận diện trước; mốc chỉ vẽ trên bản sao hiển thị. Modal, mô tả màu để khóa vật và ảnh chụp ghi mốc hiệu chuẩn vẫn dùng ảnh gốc.
- Không thay đổi logic gắp, tốc độ, giới hạn servo, cảm biến hoặc firmware V3.9.

## Cách cập nhật

1. STOP robot, tắt Python đang chạy.
2. Thay thư mục Python bằng bản này; giữ `.env`, `robot_config.json` và `auto_config.json` đã hiệu chỉnh trên máy nếu có. Không ghi đè hiệu chuẩn cá nhân chỉ để bật mốc.
3. Nếu đã dùng firmware V3.9 hỗ trợ `smooth_protocol=1`, không cần nạp lại Arduino vì bản này chỉ thay phần hiển thị Python.
4. Chạy lại `python main.py`, mở app và camera LiveKit như cũ. Cần `LIVEKIT_PUBLISHER=1` để chính Python này phát luồng USB đã vẽ mốc. Camera vẫn index 0 trong `camera_publisher.py`.
5. Mở trang hiệu chuẩn trên cùng máy chạy Python để xem chú giải tiếng Việt. Tắt “Hiện mốc kích hoạt” để xem ảnh nguyên bản tại trang này.

## Các mốc mặc định, theo auto_config.json

| Mốc trên video | Ý nghĩa | Cấu hình |
| --- | --- | --- |
| Hai đường đứt xanh lam | Dải ngang để bánh đưa tâm vật vào: x=47–53% | approach.target_x_norm và x_tolerance_norm |
| BASE → ARM, xanh lam ngang | Đáy box y2 tới 54%: có thể chuyển sang tay khi căn ngang ổn định; rw/rh cũng có thể chuyển sớm hơn | visibility.trigger_bottom_norm |
| ARM TARGET, xanh lá | Tâm mục tiêu 50%,50%; dung sai ngang ±3%, dọc ±8% | calibration.relative_target_norm / relative_tolerance_norm |
| BLUR EDGE, vàng | Biên che thử 60%; vùng dưới tô vàng nhẹ để dễ thấy | visibility.blur_bottom_norm |
| TOP GUARD y1 | Không tiếp tục hạ khi đỉnh box quá gần mép trên, mặc định 3% | visibility.min_top_norm |
| BOTTOM GUARD y2 | Không tiếp tục hạ khi đáy box quá cao trên ảnh, mặc định 15% | visibility.min_bottom_norm |
| Khung xám đứt sát mép | Vùng biên bảo vệ 1% | near.edge_margin_norm |

Các nhãn video dùng ASCII để OpenCV không lỗi dấu tiếng Việt. Tọa độ theo toàn bộ ảnh camera, không theo viền đen hoặc kích thước màn hình app. `rw` và `rh` là tỷ lệ kích thước vật, không phải tọa độ, nên không có đường ngang tương ứng.

Trong AUTO, đường vẽ theo bản cấu hình đã nạp tại START. Khi không chạy AUTO, ảnh xem đọc lại file khoảng mỗi 0,5 giây. Sửa cấu hình trong lúc robot chạy không làm AUTO đổi mốc: STOP, chỉnh/lưu rồi START lại. Không thực hiện chuyển động nào từ chức năng vẽ mốc.

Đang xử lý D18 thì ẩn mốc gắp phía trước, hiện `REAR / D18`. Chế độ ghi mốc `calibrated` không dùng các đường tương đối này, hiện thông báo thay vì vẽ mốc sai.

Luồng ảnh được kiểm thử ở chế độ USB tại máy Python (`LIVEKIT_PUBLISHER=1`, vision ưu tiên ảnh local). Nếu dùng một publisher bên ngoài với `LIVEKIT_PUBLISHER=0`, bản cập nhật không thể sửa video mà publisher ngoài phát; không dùng luồng đã vẽ mốc của máy khác làm nguồn nhận diện.

## Kiểm tra an toàn

Mở camera trước khi START: xác nhận mốc hiển thị đúng và không bị app cắt/lật ảnh. Mốc vàng là giá trị cấu hình, không tự đo được vị trí kẹp thật. Thử MANUAL, đặt robot đứng yên và đo lại vùng che nếu cần; không coi đường 54%/60% là khoảng cách cm hoặc lệnh tự đóng kẹp. Gắp vẫn cần điều kiện căn ảnh và D19 như V3.9.

Đây là cập nhật hiển thị đã kiểm thử bằng ảnh và mô phỏng; chưa kiểm tra trên camera, Arduino, mạng LiveKit hoặc cơ khí thật của bạn.
