> Tài liệu lịch sử trước V3.12. Với bản hiện tại, đọc README_CHAY_TRUOC.md và TINH_TOAN_V3_12.md.

# Kiểm thử V3.11

- Bộ hồi quy ban đầu: **242 passed**, 354.41 giây.
- Sau những thay đổi cuối, chạy lại các nhóm V3.11/V3.9/D18/khoảng cách/mốc camera: **75 passed**, 108.34 giây.
- 9 bài mới kiểm tra: nguồn tham số `.py` và đọc lại không dùng cache cũ; nạp cấu hình đầy đủ;
  21 bước xung và đích 2310/650; ánh xạ các góc giấy 17 cm; từ chối khung ảnh sai tỉ lệ;
  mốc USB 27 cm và trường hợp đáy box 59.4% còn xa; 3 ảnh nguyên bản nhất quán;
  chu trình gắp/nâng ngược P1/P10/thả đúng thứ tự; bảo vệ file tham số khi app lưu pose;
  box rộng 4% không được chuyển tay chỉ vì qua 54%; D18 rút cả hai khớp trước khi nhìn sau.
- Kết quả không cộng 242 + 75: các nhóm sau có kiểm thử hồi quy trùng nhau. Tổng tập hiện tại gồm 251 trường hợp.
- Mã firmware Arduino được so byte với bộ V3.10, không thay đổi. Bộ hồi quy có biên dịch harness C++ trên máy thử.
- Python compile/AST và check_system.py hợp lệ; kiểm tra ZIP không có `.env` thật hoặc thư mục cache.
- Một cảnh báo deprecation của Starlette testclient trong môi trường thử; không có bài kiểm thử thất bại.

Đây là kiểm thử ngoại tuyến và mô phỏng. Chưa điều khiển robot thật, chưa đo sai số khoảng cách ngoài thực tế,
chưa chứng nhận quỹ đạo đầu kẹp hoặc tầm nhìn ở vị trí 27 cm.
