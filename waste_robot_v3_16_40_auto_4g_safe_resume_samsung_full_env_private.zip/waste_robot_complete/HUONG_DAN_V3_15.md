# Waste Robot V3.15

## Bắt đầu

Giải nén toàn bộ. Giữ Arduino theo `arduino/robot_control_v3/robot_control_v3.ino`. Chạy bộ Python mới bằng trình khởi động có sẵn hoặc `python main.py` trong thư mục `python`. Cài `requirements.txt` và `requirements-camera.txt` nếu máy chưa đủ thư viện.

Mở https://waste-app-control.vercel.app, **Kết nối Python**, chọn AUTO. Trang điều khiển tại máy robot cũng có tại http://127.0.0.1:8766/control khi main.py bật giao diện hiệu chuẩn.

## Nút xanh/đỏ

- Xanh: Auto sở hữu cơ khí và gửi lệnh thật. Tay thao tác S1/P10 rồi S2/P1, sau đó xoay D2 nếu đã bật/hiệu chuẩn hướng, đóng D3 và nâng vật.
- Đỏ: phanh bánh, hủy phần còn lại của chuyển động Auto, giữ xung tay và kẹp. Camera/nhận diện vẫn chạy; lệnh dự kiến không được gửi ra Arduino. Bạn dùng bảng tay/bánh/ngăn/nắp để điều khiển. Không có popup thành công khi đổi màu; màu chỉ đổi sau khi Python xác nhận.
- Đỏ là chuyển quyền điều khiển, không rút dây USB hay ngắt điện servo. STOP vẫn hủy mọi chuỗi và tắt xung servo như firmware trước.
- Bật xanh trở lại khởi động lại quan sát/SEARCH, không chạy tiếp hàng lệnh cũ. Khi kẹp đang giữ vật, hệ thống yêu cầu thả vật trước.

## Gắp và thả theo yêu cầu

Nút **Gắp và nâng vật** dùng ở chế độ đỏ. Cần mục tiêu mới đã được xác nhận qua ba ảnh, tư thế S1/S2/P11 đúng quỹ đạo. Nếu chưa ở tư thế gắp cuối thì phải có ba mẫu VL53 mới trong cửa sổ 250–300 mm. Tay tới mốc cuối rồi D19 phải xác nhận ổn định mới được xoay/đóng kẹp/nâng. Nút này không tự chạy bánh khi D19 chưa nhận; bạn căn bánh bằng điều khiển tay rồi nhấn lại.

Nút **Thả vật vào thùng** dùng ngăn đã xác nhận lúc gắp, rút tay nếu cần, đóng nắp và xoay ngăn trước khi đưa vật tới PLACE, mở nắp, mở kẹp, xác nhận D19 hết thấy vật, rút tay rồi đóng nắp. Nếu đã chuyển sang đỏ lúc Auto đang giữ vật, ngăn hiện tại được giữ để tiếp tục thả. Khi tay đã ở PLACE, không tự đóng nắp/xoay ngăn bên dưới tay; chỉ thả nếu ngăn đúng.

Thông báo **Đã đạt khoảng cách 25–30 cm** dựa trên mẫu VL53 mới và hợp lệ; không dùng kích thước box để khẳng định số cm. D19 là cảm biến hiện diện, không đo lực kẹp.

## Xoay càng theo hướng vật

Đã có `grasp_orientation.py`: crop ảnh JPEG đúng frame detector sử dụng, tách foreground bằng GrabCut, tìm trục dài bằng PCA và lấy trung bình trục của ba ảnh. Quy ước góc ảnh: trùng chiều dọc = 0°, nghiêng phải dương, trái âm; đầu/đuôi vật tương đương nhau. Không dùng đường chéo của box thường để tính góc.

Ánh xạ D2 theo các mốc bạn cung cấp:

| Góc | Xung |
|---|---:|
| Trái 90° | 500 µs |
| Trùng Oy | 2100 µs |
| Phải 60° | 2500 µs |

Nội suy riêng từng phía; hướng ngang dùng -90°. Góc phải 60–90° không có vị trí cơ khí khả dụng, không âm thầm ép về 60°.

**Xoay theo ảnh chưa bật mặc định** vì chưa có phép đo camera → hướng càng ở tư thế gắp. Trong `python/robot_params.py`, `AUTO_CONFIG['grasp_orientation']` có `enabled=False`, `calibrated=False`, `camera_sign=1`, `offset_deg=0`, `calibration_pose` là 2310/650/1250/2100.

Để bật: tại đúng tư thế cuối và camera cố định, đo với vật thẳng Oy, nghiêng trái và nghiêng phải; xác nhận dấu và góc lệch tương ứng với cơ khí. Chỉ sau khi kiểm tra thực tế mới điền `camera_sign`/`offset_deg`, đặt `calibrated=True`, `enabled=True` rồi khởi động lại Python. Phép đổi dấu/cộng góc chỉ phù hợp khi góc ảnh và mặt phẳng quay của càng đã tương ứng; camera nhìn xiên gây biến dạng cần hiệu chuẩn hình học thêm, không thể sửa chỉ bằng một góc bù. Nếu vật bị cắt khỏi ảnh tại tư thế cuối, cần chỉnh bố trí camera để thấy đủ thân; bản này sẽ giữ chờ thay vì đoán hướng.

Chưa hiệu chuẩn: vẫn có thanh D2 và góc ảnh tham khảo ở chế độ đỏ. Đặt D2 ở tư thế cuối rồi nhấn gắp; góc được giữ khi nâng. Auto xanh chưa bật hướng sẽ dùng D2 của tư thế SEARCH, không tự xoay theo box.

## Các sửa logic

- Hủy coroutine Auto trước khi chuyển quyền để tránh nhầm thao tác ngắt cơ khí thành lỗi phần cứng.
- Hủy worker servo, vô hiệu token/epoch cũ và chờ worker dừng trước khi nhận lệnh tay.
- Kiểm tra session/TTL/thứ tự trước khi lệnh STOP/XM qua Realtime tác động tới Auto.
- XM ở chế độ đỏ chỉ dừng bánh; STOP vẫn dừng cả Auto.
- Mặc định mới `require_visible_target=True`: ba ảnh mới mất/sai vật dẫn tới giữ chờ, không lặp bước tiến/hạ từ box cũ. Cờ False chỉ giữ tương thích các thử nghiệm hành vi cũ.
- Tách lệnh dự kiến khỏi lệnh Arduino đã ACK; không giả lập cảm biến thật để cho Auto chạy tiếp.
- Nâng giữ D2 đã xoay, không kéo cổ tay về 2100 µs trong lúc giữ vật.
- Từ chối xoay theo ảnh khi chưa hiệu chuẩn, ảnh cũ, hướng không rõ, vật gần tròn hoặc góc vượt cơ khí.
- Bỏ số pin 92% giả định và các nút ngăn dùng giao thức cũ trên ứng dụng.

## Giới hạn đã biết

Kiểm thử phần mềm/mô phỏng không chứng minh robot thật nhận diện hoàn hảo. Máy kiểm tra không nối camera, Arduino hoặc vật thực của bạn. Cần kiểm tra chiều motor, hành trình S1/S2 khi đổi thứ tự, D19/VL53, góc D2 và tải kẹp trên robot. Chuỗi dự kiến ở chế độ đỏ là gợi ý theo ảnh/tư thế hiện tại, không phải mô phỏng chuyển động đã hoàn thành.

Nguồn kỹ thuật: https://docs.opencv.org/4.x/d1/dee/tutorial_introduction_to_pca.html và https://docs.opencv.org/4.x/d8/d83/tutorial_py_grabcut.html. Các phương pháp này không đảm bảo tách đúng mọi nền/vật; bản mã từ chối khi không đủ điều kiện.
