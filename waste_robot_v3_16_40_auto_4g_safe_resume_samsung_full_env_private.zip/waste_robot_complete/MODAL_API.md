# Modal API — bbox nội bộ, không vẽ lên camera

Python POST multipart trường image (JPEG camera gốc) tới MODAL_URL/detect như trước.

```json
{"found":true,"objects":[
  {"label":"plastic bottle","bin":1,"bbox":[280,180,350,310]},
  {"label":"can","bin":4,"bbox":[410,190,460,280]}
]}
```

Một vật dạng cũ found=true và object={...} vẫn được đọc. Không thấy vật: found=false, objects=[]. Có objects thì AUTO phía trước xét cả danh sách, không chọn theo thứ tự. Nhận phía sau vẫn dùng hợp đồng object đầu như cũ, chưa có hiệu chuẩn vị trí D18 trên ảnh để chọn trong nhiều vật.

bbox là xyxy pixel theo JPEG đầu vào, không phải xywh hoặc tỷ lệ 0..1. Detector resize/letterbox phải đổi box về ảnh đầu vào trước khi trả. BIN: 1 RECYCLE, 2 ORGANIC, 3 HAZARD, 4 OTHER. Gói không chứa mã/deployment detector Modal; client không tạo được box thứ hai nếu server chỉ trả một vật.

AUTO khóa một vật bằng hình học/đặc điểm màu trên đúng ảnh gửi Modal. Không bảo đảm danh tính khi vật giống nhau hoặc che khuất; mơ hồ thì chờ. Log có IoU, dịch tâm, diện tích, màu để kiểm tra vì sao không khớp. Không tự bỏ khóa để chọn vật khác khi tham chiếu hết tuổi.

V3.9 bỏ renderer box, ô SNAPSHOT và endpoint ảnh snapshot. /api/preview trả nguyên JPEG camera, không vẽ lại; /api/boxes chỉ là dữ liệu chẩn đoán tùy chọn. Điều khiển vẫn cần bbox để biết đáy vật tới vùng chuyển tay hoặc sắp bị càng che.
