# Waste Robot V3.16.33 — Cấu hình phát camera Jetson lên Vercel bằng LiveKit

## Vì sao bản V3.16.32 không hiển thị video?

Mã đã có LiveKit publisher, nhưng `.env` chưa điền **LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET**, và app Vercel cần bật LiveKit/đăng ký viewer phòng tương ứng. Cài pip không tự cấu hình dịch vụ LiveKit hoặc Vercel.

## Bước 1: Điền cấu hình Jetson tại `python/.env`

```
JETSON_LOCAL_CAMERA=1
LIVEKIT_PUBLISHER=1
LIVEKIT_VIEWER=0
LIVEKIT_FPS=8
APP_URL=https://waste-app-control.vercel.app
LIVEKIT_URL=wss://YOUR-PROJECT.livekit.cloud
LIVEKIT_API_KEY=YOUR_LIVEKIT_API_KEY
LIVEKIT_API_SECRET=YOUR_LIVEKIT_API_SECRET
# LIVEKIT_ROOM=... (không cần nếu room chính là robotId do app trả về)
```

**Không đưa API secret vào trình duyệt hoặc NEXT_PUBLIC_* trên Vercel.** Cấu hình LiveKit phía Vercel bằng environment variables server-side theo mã app, ví dụ `LIVEKIT_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`. App phải cung cấp token cho viewer và `livekit.configured=true` trong `/api/robot/configuration`.

## Bước 2: Kiểm tra chỉ phần camera/stream (không chạy robot)

```
python3 python/main.py --livekit-check
python3 python/main.py --stream-check
```

Các phép thử kiểm tra môi trường và cấu hình; chưa chứng minh video thực tế. Khi đạt, chạy `python3 python/main.py` và tìm log `[LiveKit] Đang phát camera lên phòng ...`; vào app xem track `front_camera` của cùng room `robotId`.

## Bước 3: Nếu không thấy video

- `App LiveKit: CHƯA BẬT`: phải cấu hình/deploy **ứng dụng Vercel**; ZIP Jetson không thể tự cập nhật ứng dụng web trên Vercel.
- `LIVEKIT_URL/API_KEY/API_SECRET: THIẾU`: điền `.env` trên Jetson.
- `RTC/API thiếu`: kiểm tra môi trường Python chạy main (không chỉ `.venv` đã pip install).
- Có log phát nhưng app trắng: kiểm tra viewer token, room name và track, chính sách mạng và LiveKit Cloud.
- Camera local vẫn có hình: OpenCV hoạt động độc lập; không cần ngắt AUTO để sửa mạng, nhưng luôn giữ STOP có thể sử dụng.

**Ghi chú:** Phần cơ khí AUTO/D18/D19, CH341 và firmware được giữ nguyên. Chưa kiểm thử LiveKit Cloud hoặc Jetson thực tế.
