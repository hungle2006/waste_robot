> Tài liệu lịch sử trước V3.12. Với bản hiện tại, đọc README_CHAY_TRUOC.md và TINH_TOAN_V3_12.md.

# Kiểm thử V3.11.1

- Ảnh mới đã được người dùng xác nhận: P1=2310/P10=650, chai ở mốc 27 cm.
- Bộ kiểm thử hồi quy liên quan sau thay đổi ảnh gắp: 73 passed, 111.84 giây.
- Sau bổ sung điều khiển bánh–tay luân phiên và mốc hiển thị: 32 passed, 45.41 giây (ảnh gắp, camera, khoảng cách).
- Sau chỉnh sửa cuối: 20 passed, 49.17 giây (ảnh gắp + cấu hình Python/quỹ đạo P1/P10/D18 của V3.11).
- Các số trên có bài trùng nhau, không cộng làm tổng số kiểm thử riêng biệt.

Các nhánh được kiểm tra: đúng tư thế và ảnh cắt mép trên + D19 được gắp; thiếu D19 không gắp;
D19 kích hoạt sớm không gắp; ảnh gần không ổn định không gắp; ảnh cắt ngang/dưới bị từ chối;
không nhích bánh khi tới tư thế cuối; nhịp bánh trung gian chỉ sau khi tay dừng;
đủ phản hồi ảnh mới tiếp tục, 4 nhịp không có tiến triển thì giữ tại chỗ;
giới hạn xung cho nhịp bánh được tôn trọng; giữ ảnh camera gốc, không vẽ box gửi Modal;
mốc camera cuối không hiển thị 27 cm như khoảng cách hiện tại;
nguồn tham số `.py`, đích 2310/650, nâng ngược hai khớp và D18 vẫn đúng.

Python đã kiểm tra cú pháp. Firmware và ảnh nguồn được so byte, không đổi.
Bản ZIP _env đã bổ sung `.env` có sẵn theo yêu cầu người dùng; giữ nguyên mã chạy đã kiểm thử. ZIP không có cache.

Chưa thử trên robot thật; chưa đo độ dịch bánh/cm, độ chính xác quỹ đạo đầu kẹp hoặc khoảng cách liên tục theo từng tư thế.
Các ngưỡng ảnh và nhịp bánh là tham số thử có giới hạn, không phải hiệu chuẩn cơ khí đã được xác nhận.
