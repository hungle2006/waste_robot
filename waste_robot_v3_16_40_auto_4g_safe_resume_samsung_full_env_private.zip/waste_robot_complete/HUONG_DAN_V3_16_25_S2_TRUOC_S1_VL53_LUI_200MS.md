# Waste Robot V3.16.25 – S2 xuống trước, S1 theo VL53, tự lùi khi quá gần

## Thay đổi từ V3.16.24

- Chỉ nhánh **góc xoay D2 từ 10° trở lên theo độ lớn**: camera nhận diện/khóa BIN bằng 1 ảnh, đo góc SEARCH từ 3 ảnh ổn định như cũ.
- Bánh/camera **căn ngang khi tay còn ở SEARCH**. Tiếp đó, tay hạ **riêng S2/P1 từ 1300 đến 2310 µs** theo các bước 50 µs. Trong lúc này **S1/P10 giữ 950 µs**; D2 giữ 2100 µs, D3 vẫn mở.
- Ngừng dùng camera để tính hướng sau khi S2 xuống; dùng **VL53** để tiến từng nhịp 160 ms thực tế (bảo vệ trong firmware). Khi VL53 đo **200–250 mm**, bánh dừng; D2 xoay theo góc đã nhớ. Sau đó **chỉ S1/P10 hạ từ 950 xuống 650 µs** (S2 đã là 2310 µs), mới bật D19 để kiểm tra trước khi D3 kẹp 2300 µs.
- Nếu **góc nhỏ hơn 10°**, không dùng nhánh hạ S2 trước: giữ quỹ đạo cũ P1/P10 cùng hạ; D2 giữ 2100 µs.
- Bất kể nhánh nào, nếu **VL53 đo được dưới 200 mm**, bánh lùi **200 ms thực tế/nhịp**, chờ sau nhịp 250 ms rồi đo lại. Giới hạn 10 nhịp lùi cho mỗi lần hiệu chỉnh. Nếu sau nhịp lùi lại vượt 250 mm, chuyển về tiến VL53 (không HOLD chỉ vì lùi hơi xa). Nếu VL53 mất dữ liệu, không tăng khoảng cách sau 2 nhịp, hết hạn 45 s hoặc hết 10 nhịp thì HOLD an toàn.

## Thông số

- SEARCH: S2/P1 1300 µs; S1/P10 950 µs.
- GẮP: S2/P1 2310 µs; S1/P10 650 µs.
- D2 trung tâm 2100 µs; xoay theo góc chỉ khi VL53 xác nhận 20–25 cm.
- `box_tof_flow.split_s2_first_on_rotation=True` trong `python/robot_params.py`: bật nhánh S2 trước cho trường hợp cần xoay. Chuyển thành `False` để trở về toàn bộ quỹ đạo tay cũ nhưng vẫn giữ lùi chỉnh khoảng cách.
- `box_tof_flow.overshoot_back_actual_ms=200`: 200 ms thời gian chuyển động thực tế với ramp 100+0+100 ms; lệnh danh định là 100 ms, **không phải** 200 ms danh định.
- `box_tof_flow.overshoot_back_max_steps=10`; `overshoot_min_progress_mm=3`.
- FORWARD camera 400 ms danh định / ~560 ms thực tế, LEFT/RIGHT ×2, phục hồi chai rơi, quét 30 lượt, đổi quà 120 giây: **không đổi**.

## Thử nghiệm an toàn BẮT BUỘC

**Cảnh báo cơ khí:** nhánh mới cho bánh di chuyển với **S2/P1=2310 µs và S1/P10=950 µs**. Đây là tư thế CHƯA được hiệu chuẩn khoảng hở gầm, có thể làm đầu kẹp/camera quệt nền hoặc đâm vật. Trước khi đặt robot xuống sàn, phải kiểm tra đường đi của S2, D2, D3 và khoảng hở ở tư thế này, bánh nâng khỏi nền, tốc độ thấp và nút STOP trong tầm tay. Không có cảm biến phát hiện vật cản phía sau; chỉ dùng tính năng BACK trong không gian đảm bảo thông thoáng.

**Firmware:** giữ nguyên Arduino V3.16.23+ (IG 0/1, VL53 chặn tiến, STOP); không cần thay mã Arduino cho logic này. STOP luôn có ưu tiên. Trạng thái HOLD vẫn giữ với lỗi thực sự hoặc không thể phục hồi, không được bỏ qua bảo vệ.

Kiểm thử Python chỉ xác minh mã và mô phỏng, **không** chứng minh an toàn hoặc độ chính xác servo trên robot thật.
