# V3.14.1 — Phục hồi box và bàn giao VL53 sớm

## Ba nhánh theo yêu cầu

| Điều kiện | Xử lý đang thực hiện |
|---|---|
| Box đúng khóa chạm cả mép trái và phải | Giữ tay tại cặp xung hiện tại; ngừng nhận diện; tiếp cận bằng VL53 từng nhịp160ms thực thi. |
| Hành động trước là tiến, kể cả khi đang mất/sai box | VL53 mới hợp lệ tới≤300mm được ưu tiên chuyển sang xác nhận khoảng cách, không bắt buộc tìm lại box hoặc chờ đủ3 frame mất vật. |
| Tay đạt2050/727 nhưng khoảng cách vẫn trên30cm | Giữ2050/727; tiếp tục tiến160ms/nhịp, dừng250ms để đọc lại, đến khi đủ mẫu hoặc hết giới hạn. |

**Không đóng kẹp ngay từ số đo VL53.** Cả ba đường đều dùng cùng chuỗi:

```mermaid
flowchart TD
    A["Bàn giao VL53; giữ tư thế tay hiện tại"] --> B{"Mẫu mới hợp lệ?"}
    B -- Không --> C["Dừng bánh; thử đọc lại; quá6s thì giữ chờ"]
    C --> B
    B -- Có --> D{"Khoảng cách?"}
    D -- "Trên30cm" --> E["Tiến160ms; dừng250ms"]
    E --> B
    D -- "Dưới25cm" --> F["Dừng giữ; không tự lùi hoặc hạ gắp"]
    D -- "25–30cm" --> G{"Đủ3 mẫu mới liên tiếp?"}
    G -- Chưa --> B
    G -- Đủ --> H["Dừng bánh; đi theo quỹ đạo tới2310/650"]
    H --> I["D19 ổn định300ms mới đóng kẹp"]
```

Giới hạn tiến VL53:40 nhịp hoặc45s. Hết giới hạn thì dừng, không tiến vô hạn.
Nếu đã ở25–30cm lúc bàn giao thì xác nhận mẫu luôn, không bắt buộc tiến thêm một nhịp.

## Các điều chỉnh để nhánh mới không vượt khoảng cách

- Mỗi FORWARD trong luồng box/VL53 bật chặn bánh bằng firmware trước khi chạy;
  phanh khi số đo≤300mm, lỗi hoặc cũ. Python kiểm tra lại trước/sau nhịp bánh.
- Bánh dừng rồi mới xác nhận3 số thứ tự mẫu khác nhau trong250..300mm; dùng thêm
  bộ đếm mẫu liên tiếp của firmware. Không coi cùng một mẫu đọc3 lần là3 mẫu.
- Khi lặp FORWARD do mất vật sau3 frame, dùng160ms thực thi thay vì nhịp thường560ms.
  Nếu chưa tới ngưỡng thì vẫn dừng và kiểm tra ảnh mới sau mỗi nhịp phục hồi.
- Nếu đang chờ HTTP nhận diện mà VL53 tới ngưỡng, hủy và thu hồi tác vụ nhận diện
  trước khi bàn giao. Kết quả đến muộn không được phát lệnh hoặc đổi BIN.
- Box chạm một mép ngang: căn lại một nhịp cùng quy ước hướng với nhánh cũ.
  Box quá nhỏ nhưng đúng khóa: căn ngang trước, sau đó tiến có chặn VL53.

## Phần giữ từ V3.14

- Đúng vật khóa:1 frame mới là đủ; box cập nhật theo từng ảnh.
- Chưa tới ngưỡng VL53, mất/sai vật:3 frame rồi lặp một hành động, có giới hạn.
- Đáy trên dải hoặc sát mép trên/dưới ảnh: tiến. Đáy trong/dưới dải: hạ tay.
- P1 tăng tối đa50µs; P10 theo quỹ đạo; bộ điều khiển servo vẫn chạy tuần tự từng khớp.
- FORWARD_MS=400 danh định, tổng560ms khi đủ ramp, được phép phanh sớm bởi cảm biến.
- Sau VL53:2310/650, D19 xác nhận300ms; chưa nhận thì nhích160ms, tối đa12 nhịp/15s.
- BIN/loại rác đã khóa, nâng/thả, D18, STOP và các chế độ cũ được giữ.
- Không chạy bánh lùi trong luồng trước. Firmware và thư viện Arduino
  không đổi từ V3.14; nếu đã nạp đúng firmware V3.14 thì không cần nạp lại vì bản sửa này.

VL53 chỉ đo vật trong vùng nhìn, không nhận dạng đó là lon/chai nào. Cảm biến gắn
cố định, hướng đúng mục tiêu đã căn và không bị tay che. Khoảng25–30cm tính từ cảm
biến. Kết quả mô phỏng không thay cho kiểm tra cơ khí và cảm biến trên robot thật.
Các xung trong STATUS là lệnh đã gửi, không xác nhận góc thực của servo.

Mở README_CHAY_TRUOC.md để chạy; xem KIEM_THU_V3_14_2.md để biết kết quả kiểm tra bản đóng gói hiện tại.
