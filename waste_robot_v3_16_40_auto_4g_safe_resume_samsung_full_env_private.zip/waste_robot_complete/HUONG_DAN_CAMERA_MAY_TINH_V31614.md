# V3.16.14 — Camera và điều khiển trên máy tính

## Cách mở

1. Dừng chương trìnhPython cũ. Giải nén toàn bộZIP vào thư mục mới, không chỉ chép `main.py`.
2. Trong thư mục `python`, chạy `start_windows.bat`. Nếu chạyPowerShell tại thư mục đó: `python main.py`.
3. Sau khi kết nối dịch vụ hiện có và máy chủ cục bộ sẵn sàng, trình duyệt tự mở **http://127.0.0.1:8766/control**. Nếu trình duyệt không tự mở, nhập địa chỉ này khiPython còn đang chạy.
4. Camera hiển thị khi có ảnh mới; nútKết nốiArduino vàAUTO là thao tác riêng. Chỉ mở trang không tự phát lệnh cơ khí.
5. Mởcạnhcamera và bảng điều khiển cùng màn hình. Bảng bên phải cuộn riêng trên màn hình rộng; trên màn hình nhỏ các phần xếp thành một cột.

Đây là giao diện chạy từPython trên máy tính, xem bằngChrome/Edge/trình duyệt mặc định, không phải cửa sổOpenCV. Không thay đổi hoặc triển khai lạiVercel.

## Trên giao diện

- Camera lớn, trạng tháiTRỰC TIẾP/CHỜ CAMERA; mất ảnh thì che ảnh cũ và báo chờ thay vì coi ảnh cũ là đang phát.
- Bật/tắt mốcAUTO bằng ô **Hiện mốcAUTO**; ảnh gốc cho model vẫn như trước.
- Nút **⛶** mở toàn màn hình; có nútđổi quà vàDỪNG ngay dưới camera. Nếu trình duyệt không hỗ trợFullscreenAPI, có chế độ phóng trong trang; nhấnEscape để thoát chế độ này.
- AUTO xanh/đỏ, tayS1/S2, xoay±10°, mở/đóng kẹp, gắp theo cảm biến, nâng/rút, bánh, thùng/nắp giữ các điều kiện điều khiển hiện có.
- Phần **Nhật ký & lệnh điều khiển** thu gọn để dành chỗ cho camera.
- Nút **Đổi quà** dùng chung lệnh `GIFT DISPENSE`, digitalD4 ArduinoMega, xung2500→600→2500us.

## Đổi thông số

Trong `python/robot_params.py`:

```python
LOCAL_OPERATOR_UI = True
LOCAL_OPERATOR_OPEN_BROWSER = True
LOCAL_OPERATOR_PORT = 8766
```

Đặt `LOCAL_OPERATOR_OPEN_BROWSER=False` nếu chỉ muốn in địa chỉ mà không tự mở trình duyệt. Đặt `LOCAL_OPERATOR_UI=False` để tắt máy chủ giao diện cục bộ. Cờhiệu chuẩn cũ `AUTO_CALIBRATION_UI=False` không còn tắt bảngcamera này.

Nếu môi trường có `LOCAL_OPERATOR_UI`, `LOCAL_OPERATOR_OPEN_BROWSER` thì dùnggiá trị1/0 của môi trường. `AUTO_CALIBRATION_PORT`, nếu có, được ưu tiên hơn `LOCAL_OPERATOR_PORT`. Chỉ mở máy chủ trên127.0.0.1, không mở ra mạngLAN.

Xung kẹp cũng ở `python/robot_params.py`:

```python
ROBOT_CONFIG['grip']['open']   # 600 us
ROBOT_CONFIG['grip']['close']  # 2300 us
```

Đổi trực tiếp giá trị trong dictionary `ROBOT_CONFIG` ở tệp đó. JSONdự phòng `python/robot_config.json` đã được đồng bộ2300us. Nếu tự dùng `ROBOT_CONFIG` trỏ một tệp khác, cập nhật giá trịclose trong tệp đó để tránh ghi đè bằng2000us cũ.

## Camera chưa lên hình

- Camera vẫn dùng luồngUSB/LiveKit đã cấu hình. Không mở thiết bịcamera lần hai chỉ để xem trangPython.
- `.env` giữ nguyên. Bản đi kèm đang dùng `LIVEKIT_VIEWER=1`, `LIVEKIT_PUBLISHER=1`; cần cài thư viện trong `requirements-camera.txt` như trước.
- `CAMERA_INDEX=0` hiện đặt ở `python/robot_params.py`. Nếu sai thiết bị thì đổi chỉ số, dừng và chạy lạiPython.
- Đóng ứng dụng khác đang giữ webcam; kiểm tra dòng thông báo publisher/camera trongPowerShell. Nếu không có ảnh mới, giao diện vẫn hiển thị thông báo chờ và các trạng thái robot.
- Nếu cổng8766 đã bịPython khác giữ, chương trình không tự mở trình duyệt vào nhầm phiên cũ. Dừng phiên cũ hoặc đổi cổng rồi chạy lại.

## Logic giữ nguyên

IRsớm sau khi đã khóa vật/BIN: dừng bánh, hạ hết2310/650, đọc lạiIR tại vị trícuối; IRhiện tại ổn định300ms mới cho đóngkẹp2300us. Chưa nhận thì nhích160ms có giới hạn. VL53luồngthường20–25cm, ROI10×10, D4quà, STOP vàD18 đượcgiữ.

Kết quả kiểm tra nằm ở `verification/v31614_KET_QUA.md`. Chưa thử trên robotthật hoặc xác nhận hình ảnhwebcam trên máyWindows của bạn.
