> Tài liệu lịch sử trước V3.12. Với bản hiện tại, đọc README_CHAY_TRUOC.md và TINH_TOAN_V3_12.md.

# AUTO V3.9 — thông số và giới hạn

motion.enabled=true, visibility.enabled=true, approach.enabled=true và calibration.mode=relative bật luồng mới. File cũ thiếu motion/visibility mặc định tắt để tương thích. Phải dùng auto_config.json mới và nạp firmware hỗ trợ smooth_protocol=1.

| Tham số | Mặc định | Ý nghĩa |
|---|---:|---|
| control.speed | 20 | PWM đỉnh, không phải % hoặc cm/s |
| motion.ramp_ms | 160 | Trần thời gian một nhánh tăng/giảm tốc |
| approach.forward_ms | 120 | Thời gian tương đương đủ PWM, không phải tổng profile |
| visibility.near_forward_ms | 60 | Nhịp tương đương gần vùng chuyển tay |
| visibility.trigger_bottom_norm | 0.54 | Đáy vật tới đây thì chuyển tay khi căn ngang ổn định |
| visibility.blur_bottom_norm | 0.60 | Giới hạn nhìn thấy thử phía càng che |
| motion.arm_step_us | 8 | Bước hạ S2 tối đa |
| motion.arm_step_ms | 50 | Nhịp giữa các xung ramp nhỏ của servo |
| visibility.min_step_us | 5 | Bước chậm gần vùng che/mép, gần một tick PCA9685 |
| visibility.min_top_norm | 0.03 | Không để đỉnh vật ra mép trên |
| visibility.min_bottom_norm | 0.15 | Không hạ khi vật đã đi quá cao trong ảnh |
| visibility.prediction_margin_norm | 0.01 | Dự phòng mép cho bước tiếp theo |
| visibility.min_response_norm | 0.002 | Thay đổi tối thiểu để thấy tay có phản hồi ảnh |
| visibility.max_no_response | 4 | Số bước thiếu phản hồi trước khi giữ |

Với thời gian tương đương T và cap R: ramp=min(T,R), hold=T-ramp, tổng thời gian=T+ramp. PWM đi smoothstep 0→đỉnh→0, không đổi hướng khi chưa về 0. Phần mềm không có encoder/đo lực; chuyển động còn phụ thuộc nguồn, ma sát và tải.

## Theo ảnh khi hạ

1. Ở SEARCH: P1=1300, P10=950, P11=1250, D2=2100, D3 mở=600 µs. Bánh căn ngang rồi tiến mềm. Khi gần vùng chuyển tay thì nhịp tiến ngắn hơn.
2. Đáy vật đạt 54% và căn ngang qua đủ ảnh: dừng bánh, chuyển tay trước vùng che 60%. Mốc rộng/cao bbox vẫn có thể cho chuyển sớm hơn. Không coi đây là đo khoảng cách gắp.
3. Bánh đứng yên trong toàn bộ phần hạ. Kiểm tra P10/P11/D2 cố định, giới hạn P1, lệch ngang tối đa 6% và IR. Giới hạn hạ cuối vẫn lấy grasp_final_s2_us (gói hiện tại 2900), không tự thay đổi.
4. Ảnh căn đúng ổn định và D19 phát hiện liên tục thì gắp. Nếu chưa có IR: tính bước S2 tối đa 8 µs, giảm bước gần mép và xét phản hồi dịch ảnh đã quan sát. Bước nhỏ hơn min_step_us để tránh vượt mép thì giữ, trừ phần dư cuối tới chính giới hạn cấu hình vẫn an toàn theo dự đoán.
5. Mỗi bước hoàn tất mới chụp ảnh tiếp. Vật gần ra mép hoặc đáy vượt vùng che: nếu có bước ngay trước đã quan sát và chưa có IR, rút đúng một bước đó rồi giữ. Không lặp quét dò mù.
6. Mất dấu: giữ nguyên tay và tìm lại cùng vật. Không di chuyển tay để tìm theo tọa độ ảnh cũ.

Hạ S2 được kỳ vọng làm đáy vật đi lên theo log trước. Nếu đáy đi xuống sai chiều hoặc không phản hồi qua các bước, giữ chờ. Đây là bảo vệ dựa trên bbox, không bảo đảm luôn thấy vật che khuất hoàn toàn. Mốc 54%/60% cần thử/hiệu chỉnh theo bố trí camera và càng thực tế. Trigger phải nhỏ hơn blur ít nhất 2% ảnh.

PCA9685 trong firmware dùng prescale hiện tại khoảng 121: một tick ≈4.88 µs. Vì vậy không dùng các bước theo ảnh 1–2 µs làm mặc định; lệnh quá nhỏ có thể chưa thay đổi PWM thực tế. Các xung vẫn là giá trị lệnh, không phải phản hồi vị trí servo.

## Bánh và dừng

Ở SEARCH cố định, xét trung vị hai đầu nhóm 5 nhịp để biết bbox có lớn lên/đáy đi xuống. Không dùng chuyển động camera do hạ tay làm bằng chứng xe tiến. Không có tiến triển thì giữ, không tự tăng PWM hoặc ép tay. Tối đa 40 nhịp tiến/25 ngang như cũ.

G mới chỉ do AUTO sở hữu gửi. Firmware chạy profile hữu hạn tối đa 1000 ms, tự kết thúc không cần Python gửi thêm PWM. XM/STOP/watchdog hoặc D18/D19 phát hiện sẽ bỏ ramp và ngắt ngay. Giữ Arduino heartbeat và liên động như trước. MANUAL vẫn C/D, không bật ramp tự động cho lệnh thủ công.

AUTO vẫn đứng yên chờ mỗi ảnh Modal. Không có local tracker tốc độ cao để tiếp tục di chuyển khi model đang xử lý. Bản này làm mềm nhịp PWM, không hứa robot chạy liên tục trong lúc thiếu thông tin. PWM20 có thể chưa thắng ma sát; cần thử MANUAL và hiệu chỉnh mức quay đều, không dùng kick mạnh.

## Gắp và phía sau

Phân loại ổn định rồi xoay ngăn khi nắp đóng; gắp/nâng/PLACE xong mới mở nắp/thả. Một IR D19 xác nhận hiện diện chứ không đo lực nắm. D18 vẫn là luồng phía sau riêng, chờ vật rời ổn định mới đóng nắp.

STOP/mất kết nối/lỗi cứng vẫn dừng an toàn. Chưa có mốc khoảng sáng cơ khí để cho bánh chạy khi tay đã hạ; bản này không tự cho phép phối hợp bánh chạy với tay thấp. Độ mượt và tầm gắp phải thử trên robot thật; không suy ra cm từ ảnh hoặc PWM.
