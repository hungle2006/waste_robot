# Waste Robot V3.16.20 — tránh HOLD sớm khi ảnh góc SEARCH lỗi

## Triệu chứng
`AUTO · auto_hold · Không đo được góc vật tại SEARCH: Vật gần tròn hoặc hướng không rõ`.

Nguyên nhân: `grasp_orientation.py` tách vật trong bounding box bằng GrabCut rồi tính hướng trục dài qua PCA. Khi tỷ số hai trị riêng < 2, hình/vùng tách bị xem là gần tròn; không đủ căn cứ để xác định hướng càng D2. Đây là lỗi đo góc, không phải lỗi phân loại BIN.

## Thay đổi V3.16.20
- Vẫn giữ góc tại tư thế SEARCH, *chưa xoay D2*.
- Lấy tối đa **9 ảnh SEARCH mới**, không điều khiển tay/bánh trong lúc lấy ảnh.
- Khi tách vật/góc lỗi ở một ảnh: báo sự kiện `auto_orientation_retry`, nêu số ảnh và nguyên nhân, thử lại.
- Chỉ dùng **3 góc hợp lệ liên tiếp** cùng vật/BIN, ổn định trong giới hạn cũ (8 độ), để tính lệnh D2.
- Nếu 9 ảnh vẫn không đủ: chuyển `auto_hold` như cũ. **Không tự gán góc 0°/2100 µs** cho vật chưa đo được.
- Thông báo `Vật gần tròn...` bổ sung trị `PCA=...` để chẩn đoán.
- Các lỗi thay đổi mục tiêu, sai pose, mất vật hay ảnh AI/camera lỗi vẫn giữ bảo vệ HOLD riêng.

## Điều kiện vận hành giữ nguyên
- VL53 phải xác nhận 200–250 mm trước khi xoay D2.
- D2 xoay trước khi tay xuống tư thế cuối; D19 xác nhận trước khi đóng D3 2300 µs.
- Căn ngang ×2, các nhịp tiến, lùi 10 nhịp khi rơi, quét phải 30 lượt và đổi quà 120 giây giữ nguyên.
- Firmware Arduino không đổi.

## Khi vẫn HOLD sau 9 ảnh
1. Dừng AUTO bằng STOP và đảm bảo robot không chuyển động.
2. Kiểm tra camera tại SEARCH có thấy **toàn bộ thân chai** (không bị cắt ở mép ảnh, không che bởi tay/càng).
3. Đặt nền tương phản với chai, ánh sáng đều, tránh lóa và vật khác trong bounding box.
4. Chụp ảnh khung hình SEARCH và ảnh có bounding box để kiểm tra thuật toán tách nền.
5. Không chỉnh `calibrated=True` như một lời đảm bảo đã đo đúng phần cứng. Kiểm tra chiều xoay D2 không tải.

## Giới hạn
Đây là cải thiện độ chịu lỗi trước *ảnh phân đoạn kém nhất thời*. Nếu mọi ảnh chỉ thấy đầu chai / chai gần tròn / GrabCut luôn tách sai, hệ thống sẽ HOLD có chủ đích. Chưa thử nghiệm trên robot thực.
