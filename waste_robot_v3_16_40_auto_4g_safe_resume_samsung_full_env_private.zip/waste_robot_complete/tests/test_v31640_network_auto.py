"""4G interruption/resume regression without radio, real camera or robot motion."""
import asyncio
import time
from unittest.mock import AsyncMock

import pytest

from test_box_tof_flow import prepared
from test_control import robot


async def sleeping():
    await asyncio.sleep(100)


@pytest.mark.asyncio
async def test_network_pause_keeps_gripper_and_journal(robot, tmp_path):
    b, hw, a, _ = prepared(robot, tmp_path)
    a.state['state'] = 'auto_search'
    a.task = asyncio.create_task(sleeping())
    try:
        before = hw.state['joints'].copy()
        assert await a.pause_for_network()
        assert a.network_hold
        assert a.checkpoint.load()['status'] == 'waiting_network'
        assert b.snapshot()['stopped'] is False
        assert b.snapshot()['auto_running'] is False
        assert hw.state['motors'] == [0, 0, 0, 0]
        assert hw.state['joints'] == before
        assert a.state['state'] == 'auto_network_hold'
        assert a.task.cancelled()
    finally:
        a.network_hold = None


@pytest.mark.asyncio
async def test_network_resume_reobserves_search_not_old_commands(robot, tmp_path):
    b, hw, a, _ = prepared(robot, tmp_path)
    a.state['state'] = 'auto_search'
    a.task = asyncio.create_task(sleeping())
    assert await a.pause_for_network()
    a.vision.frame_at = time.monotonic()
    a.vision.jpeg = b'fresh'
    before = len(hw.commands)
    async def start_new(*, resuming=False, rear_only=False):
        assert resuming and not rear_only
        b.claim_auto('new-cycle')
        a.token = 'new-cycle'
        a.task = asyncio.create_task(sleeping())
    a.start = AsyncMock(side_effect=start_new)
    try:
        assert await a.resume_after_network()
        a.start.assert_awaited_once()
        assert a.state['state'] == 'auto_network_resumed'
        # No old movement, gripper opening, or servo replay by the resume path.
        assert not any(cmd.startswith(('P ', 'S ', 'MOVE ')) for cmd in hw.commands[before:])
        assert b.auto_owner == 'new-cycle'
    finally:
        a.task.cancel()
        await asyncio.gather(a.task, return_exceptions=True)


@pytest.mark.asyncio
async def test_network_holding_object_requires_inspection_never_releases(robot, tmp_path):
    b, hw, a, _ = prepared(robot, tmp_path)
    a.holding_object = True
    a.state['state'] = 'auto_place'
    a.task = asyncio.create_task(sleeping())
    assert await a.pause_for_network()
    before = len(hw.commands)
    a.start = AsyncMock()
    try:
        assert not await a.resume_after_network()
        a.start.assert_not_called()
        assert a.state['resume_requires_inspection'] is True
        assert not any(cmd.startswith('P 3 ') for cmd in hw.commands[before:])
    finally:
        a.network_hold = None


@pytest.mark.asyncio
async def test_network_interrupted_wheel_motion_needs_inspection(robot, tmp_path):
    b, hw, a, _ = prepared(robot, tmp_path)
    a.state['state'] = 'auto_search'
    a.task = asyncio.create_task(sleeping())
    b.drive_until = time.monotonic()+.4
    assert await a.pause_for_network()
    a.start = AsyncMock()
    assert not await a.resume_after_network()
    a.start.assert_not_called()
    assert a.state['resume_requires_inspection'] is True


@pytest.mark.asyncio
async def test_no_automatic_resume_after_manual_stop(robot, tmp_path):
    b, hw, a, _ = prepared(robot, tmp_path)
    a.state['state'] = 'auto_search'
    a.task = asyncio.create_task(sleeping())
    assert await a.pause_for_network()
    await a.stop(emergency=True)
    a.start = AsyncMock()
    assert a.network_hold is None
    assert not await a.resume_after_network()
    a.start.assert_not_called()

@pytest.mark.asyncio
async def test_paused_auto_rejects_stale_web_actuator_commands(robot, tmp_path):
    from realtime_bridge import RealtimeService
    from test_realtime import packet
    b, hw, a, _ = prepared(robot, tmp_path)
    a.state['state'] = 'auto_search'
    a.task = asyncio.create_task(sleeping())
    assert await a.pause_for_network()
    channel = type('Channel', (), {'send_broadcast': AsyncMock()})()
    service = RealtimeService(b, 'robot_01', channel)
    service.auto = a
    service.online = True
    before = len(hw.commands)
    cmd = packet(service.dispatcher, 1, body={'command':'GRIP OPEN', 'epoch':b.epoch})
    await service.command(cmd)
    event, response = channel.send_broadcast.call_args.args
    assert event == 'mechanical_ack'
    assert response['ok'] is False
    assert 'chờ' in response['error'] or 'giữ' in response['error']
    assert not any(c.startswith('P 3 ') for c in hw.commands[before:])
    assert a.network_hold is not None
