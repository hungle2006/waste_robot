"""Safe SEARCH homing from repeated Vercel Connect actions."""
import copy
import pytest
from test_control import robot, ready, wait_for
from realtime_bridge import MechanicsDispatcher
from test_realtime import packet


def test_first_connect_initializes_search(robot):
    b, hw = robot
    wait_for(lambda: not b.busy)
    assert all(hw.state['joints'].get(k) == p for k,p in b.config['poses']['SEARCH'].items())


def test_second_connect_returns_arm_to_search(robot):
    b, hw = robot
    epoch = ready(b)
    b.command('POSE PLACE', epoch)
    wait_for(lambda: not b.busy)
    assert hw.state['joints']['p10'] != b.config['poses']['SEARCH']['p10']
    d = MechanicsDispatcher(b, 'robot_01')
    assert d.handle(packet(d, 1, 'connect'))['ok']
    wait_for(lambda: not b.busy)
    assert all(hw.state['joints'].get(k)==p for k,p in b.config['poses']['SEARCH'].items())
    assert hw.state['motors'] == [0,0,0,0]


def test_repeated_connect_does_not_move_while_stop(robot):
    b, hw = robot
    ready(b)
    b.stop()
    prev=list(hw.commands)
    b.connect()
    assert b.stopped and hw.commands==prev


def test_repeated_connect_refuses_held_object(robot):
    b, hw = robot
    epoch = ready(b)
    b.command('POSE PLACE', epoch)
    wait_for(lambda: not b.busy)
    hw.state['sensors']['D19'] = 0
    old=copy.deepcopy(hw.state['joints'])
    with pytest.raises(ValueError, match='D19'):
        b.connect()
    assert hw.state['joints']==old


def test_repeated_connect_refuses_closed_gripper(robot):
    b, hw = robot
    epoch = ready(b)
    b.command('GRIP CLOSE', epoch)
    wait_for(lambda: not b.busy)
    old=copy.deepcopy(hw.state['joints'])
    with pytest.raises(ValueError, match='Kẹp'):
        b.connect()
    assert hw.state['joints']==old


def test_repeated_connect_refuses_active_auto(robot):
    b,hw=robot
    ready(b)
    token=object()
    b.claim_auto(token)
    with pytest.raises(ValueError, match='AUTO'):
        b.connect()
    b.release_auto(token)


def test_repeated_connect_refuses_moving_wheels(robot):
    b,hw=robot
    ep=ready(b)
    b.command('DRIVE FORWARD',ep,speed=20)
    with pytest.raises(ValueError, match='Bánh đang chạy'):
        b.connect()


def test_first_connect_d19_occupied_stays_stopped(tmp_path):
    from pathlib import Path
    import json
    from brain import Brain
    from transport import SimTransport
    path=tmp_path/'robot.json'
    root=Path(__file__).resolve().parents[1]/'python'/'robot_config.json'
    path.write_text(root.read_text())
    hw=SimTransport()
    hw.state['sensors']['D19']=0
    b=Brain(hw,path,True)
    try:
        snap=b.connect()
        assert snap['stopped'] and not snap['busy']
        assert not hw.state['joints']
    finally:
        b.close()


def test_resume_with_held_object_does_not_open_gripper(robot):
    b, hw = robot
    ready(b)
    b.stop()
    hw.state['sensors']['D19'] = 0
    snap = b.resume(b.epoch)
    assert snap['connected'] and not snap['stopped'] and not snap['busy']
    assert not (set(hw.state['joints']) & set(b.config['poses']['SEARCH']))
    assert 'D19' in snap['job']
