"""Network-fault simulation; never opens USB, camera, or the real Supabase API."""
import asyncio
import sys
import time
import types
from unittest.mock import AsyncMock

import pytest

from realtime_supervisor import RealtimeSupervisor


class Status:
    SUBSCRIBED = 'SUBSCRIBED'
    CLOSED = 'CLOSED'
    TIMED_OUT = 'TIMED_OUT'
    CHANNEL_ERROR = 'CHANNEL_ERROR'


class FakeChannel:
    def __init__(self, kind='normal'):
        self.kind = kind
        self.cb = None
        self.command_cb = None
        self.messages = []
        self.cleaned = False

    def on_broadcast(self, event, callback):
        assert event == 'command'
        self.command_cb = callback
        return self

    async def subscribe(self, callback):
        self.cb = callback
        callback(Status.SUBSCRIBED, None)

    async def send_broadcast(self, event, data):
        if self.kind == 'freeze':
            await asyncio.Event().wait()
        self.messages.append((event, data))
        return 'ok'


class FakeClient:
    def __init__(self, kind='normal'):
        self.ch = FakeChannel(kind)
        self.removed = []
        self.realtime = types.SimpleNamespace(close=AsyncMock())

    def channel(self, name, config):
        assert name == 'robot:robot_01'
        assert config['config']['broadcast']['ack'] is True
        return self.ch

    async def remove_channel(self, channel):
        self.removed.append(channel)
        channel.cleaned = True


class FakeRobotService:
    def __init__(self):
        self.online = False
        self.channel = None
        self.on_transport_failure = None
        self.stops = 0
        self.last_broadcast_ok = 0.0
        self.commands = []

    def on_command(self, message):
        self.commands.append(message)

    async def publish_state(self):
        if self.online:
            await self.channel.send_broadcast('mechanical_state', {'robot_id': 'robot_01'})
            self.last_broadcast_ok = time.monotonic()

    async def disconnected(self):
        if self.online:
            self.stops += 1
            self.online = False


@pytest.fixture
def fake_realtime(monkeypatch):
    monkeypatch.setitem(sys.modules, 'realtime', types.SimpleNamespace(RealtimeSubscribeStates=Status))


async def until(fn, timeout=2.0):
    end = time.monotonic()+timeout
    while time.monotonic() < end:
        if fn():
            return
        await asyncio.sleep(.015)
    raise AssertionError('Condition not reached within test deadline')


def start_test(factories, **kwargs):
    created = []
    service = FakeRobotService()

    async def new_client(_url, _key):
        client = FakeClient(factories[len(created)] if len(created) < len(factories) else 'normal')
        created.append(client)
        return client

    supervisor = RealtimeSupervisor(service,'https://supabase.test','publishable-test','robot_01',
                                     create_client=new_client,min_retry=.015,max_retry=.03,
                                     subscribe_timeout=.15,silence_timeout=.40,**kwargs)
    return service,supervisor,created


@pytest.mark.asyncio
async def test_subscribe_then_channel_closed_recreates_client_and_ignores_old_callbacks(fake_realtime):
    service,supervisor,created = start_test(['normal', 'normal'])
    job=asyncio.create_task(supervisor.run())
    try:
        await until(lambda: len(created)==1 and service.online)
        old=created[0].ch
        old.command_cb({'payload':{'id':1}})
        assert len(service.commands)==1
        old.cb(Status.CLOSED,None)
        await until(lambda: len(created)>=2 and service.online)
        assert service.stops==1
        assert created[0].removed==[old]
        old.cb(Status.SUBSCRIBED,None)  # event from retired generation is inert
        old.command_cb({'payload':{'id':2}})
        assert len(service.commands)==1
        new=created[1].ch
        new.command_cb({'payload':{'id':3}})
        assert len(service.commands)==2
    finally:
        await supervisor.stop()
        await asyncio.wait_for(job,1)


@pytest.mark.asyncio
async def test_timeout_and_channel_error_both_trigger_recovery(fake_realtime):
    service,supervisor,created = start_test(['normal']*4)
    job=asyncio.create_task(supervisor.run())
    try:
        await until(lambda: service.online and len(created)==1)
        created[0].ch.cb(Status.TIMED_OUT,None)
        await until(lambda: service.online and len(created)==2)
        created[1].ch.cb(Status.CHANNEL_ERROR,ValueError('network'))
        await until(lambda: service.online and len(created)==3)
        assert service.stops==2
    finally:
        await supervisor.stop()
        await asyncio.wait_for(job,1)


@pytest.mark.asyncio
async def test_asyncio_empty_rejoins_recreates_session(fake_realtime):
    service,supervisor,created = start_test(['normal']*3)
    job=asyncio.create_task(supervisor.run())
    try:
        await until(lambda: service.online and len(created)==1)
        try:
            async def _reconnect():
                raise ValueError('Set of Tasks/Futures is empty.')
            await _reconnect()
        except Exception as exc:
            supervisor._handle_background_exception(asyncio.get_running_loop(), {'exception':exc})
        await until(lambda: service.online and len(created)>=2)
        assert service.stops==1
    finally:
        await supervisor.stop()
        await asyncio.wait_for(job,1)


@pytest.mark.asyncio
async def test_disconnected_halts_without_auto_rearming(fake_realtime):
    service,supervisor,created = start_test(['normal']*3)
    job=asyncio.create_task(supervisor.run())
    try:
        await until(lambda: service.online and len(created)==1)
        supervisor.transport_failed('4G drop')
        await until(lambda: service.online and len(created)>=2)
        assert service.stops==1
        # Supervisor only restores transport. It sends no RESUME or AUTO START.
        assert service.commands==[]
    finally:
        await supervisor.stop()
        await asyncio.wait_for(job,1)


@pytest.mark.asyncio
async def test_all_clients_unreachable_retry_until_restored(fake_realtime):
    created=[]
    service=FakeRobotService()
    async def factory(_url,_key):
        created.append(True)
        if len(created)<3:
            raise OSError('Mobile network unavailable')
        return FakeClient()
    s=RealtimeSupervisor(service,'https://s.test','k','robot_01',create_client=factory,
                         min_retry=.015,max_retry=.03,subscribe_timeout=.15,silence_timeout=.4)
    job=asyncio.create_task(s.run())
    try:
        await until(lambda:service.online and len(created)>=3)
        assert service.stops==0
    finally:
        await s.stop()
        await asyncio.wait_for(job,1)
