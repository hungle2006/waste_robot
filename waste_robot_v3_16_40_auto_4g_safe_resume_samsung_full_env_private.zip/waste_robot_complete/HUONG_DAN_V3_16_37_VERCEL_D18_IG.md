# Waste Robot V3.16.37 – D18, MANUAL, lỗi IG và app Vercel

**Thông báo:** `auto_not_ready – Cần nạp firmware V3.16.23 hỗ trợ IG`

Không phải lỗi camera hay D19. Đây là **lỗi tương thích Arduino firmware**: STATUS của Arduino chưa xác nhận `ir_drive_guard = true`. ZIP Python mới không thể nạp firmware từ xa.

## Nạp firmware Arduino Mega 2560 (chỉ làm khi robot được cố định an toàn)

1. Tắt `python/main.py`; trong Arduino IDE 1.8.x, mở `arduino/robot_control_v3/robot_control_v3.ino` từ bản ZIP mới.
2. Chọn Tools → Board → Arduino Mega or Mega 2560, Processor ATmega2560 và Tools → Port đúng `/dev/ttyUSB0` (CH340/CH341) hoặc port hiện hữu. Đóng Serial Monitor khi Upload.
3. Nhấn **Upload**, đợi `Done uploading`. Không cấp nguồn cho bánh lúc nạp nếu có thể.
4. Đóng Serial Monitor, chạy trong thư mục `waste_robot_complete`:
   `python3 python/main.py --firmware-check`
5. Kỳ vọng `Drive protocol: 4`, `Smooth protocol: 1`, `IG D19 guard: True`, `VL53 protocol: 1`, `AUTO continue: True`.
6. Chạy `python3 python/main.py`, vào app Vercel, **Kết nối Python** rồi thử AUTO.

Nếu đã nạp đúng mà vẫn báo thiếu `IG`, kiểm tra có chạy nhầm `.ino` hoặc còn chương trình Python khác đang chiếm cổng Serial hay không.

## Cơ khí thủ công và D18

- Khi AUTO bật xanh, D18 vẫn ưu tiên nhận rác phía sau.
- Chuyển nút **Đỏ – Bạn điều khiển** để Auto nhường bánh, camera vẫn quan sát.
- App Vercel chỉ bật nút bánh khi Jetson gửi `auto.manual_wheels_available=true`. D18=0 vẫn có thể lái tay.
- STOP khẩn cấp, watchdog Arduino, và bảo vệ VL53 không bị tắt; phải kiểm tra hướng và nâng bánh trước khi thử.

## LiveKit

Giữ nguyên thông số `LIVEKIT_*` từ bản V3.16.36; **file `.env` chứa API Secret**, chỉ giữ cục bộ trên Jetson, không đẩy GitHub hoặc công khai ZIP.
