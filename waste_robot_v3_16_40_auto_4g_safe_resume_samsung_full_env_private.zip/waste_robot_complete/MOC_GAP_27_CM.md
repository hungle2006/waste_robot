> Tài liệu lịch sử trước V3.12. Với bản hiện tại, đọc README_CHAY_TRUOC.md và TINH_TOAN_V3_12.md.

# Mốc gắp được xác nhận

- Ảnh: WIN_20261016_00_22_10_Pro.jpg; 1920 × 1080, chụp bằng camera robot.
- Khoảng cách được người dùng đo: hình chiếu trục S2 trên sàn → tâm chai: 27 cm.
- Xung khi chụp: P1=2310 µs, P10=650 µs, đã được người dùng xác nhận trong hội thoại.
- P11=1250 và D2=2100 tiếp tục dùng giá trị SEARCH/quỹ đạo đã có, không tự suy xung từ ảnh.
- Chai bị cắt mép trên ảnh; không có điểm tiếp xúc sàn đủ rõ để ghép vào homography giấy SEARCH.
- File robot_params.py lưu mốc và tham số; không cần chạy record_grasp_reference.py cho bố trí này.
- Thay đổi cặp xung đích làm mốc ảnh không còn khớp; bộ kiểm tra cấu hình từ chối thay vì tự coi ảnh cũ là mốc mới.

Điều kiện gắp: đúng cặp xung, khóa cùng vật/ngăn, ảnh USB mới, tỉ lệ 16:9, nhiều box nhất quán, phần thân chai còn thấy ở giữa hai bên ảnh, D19 ổn định.
Không dùng tâm dọc của box bị cắt để chạy bánh. Không bỏ điều kiện D19 và không tự đóng kẹp chỉ vì ảnh trông giống chai.

## Tham số bánh–tay luân phiên

`confirmed_grasp.base_follow` điều khiển các nhịp tiến khi tay đã đứng yên ở tư thế trung gian:
- trigger_bottom_norm=0.48: nếu đáy box lên trên mức này thì nhích bánh thay vì hạ thêm ngay.
- pulse_ms=60, tối đa 40 nhịp; 4 nhịp liên tiếp không thấy box tăng/đáy dịch xuống thì giữ tại chỗ.
- max_p1_us=2260: không có nhịp bánh mới tại xung lớn hơn mức này; tuyệt đối không chạy bánh ở 2310/650.
- Cần căn ngang, box chưa sát mép, không vào vùng che, D19 chưa kích hoạt; tay giữ nguyên cả P1/P10 trong nhịp bánh.

Các giá trị trên là giới hạn vận hành thử bằng phản hồi ảnh, không phải vùng làm việc cơ khí đã được đo kiểm.
Ảnh tham chiếu cuối không cung cấp bản đồ khoảng cách ở các tư thế trung gian.
