# V3.16.14 — Kẹp2300us và giao diện camera máy tính

**Đọc [HUONG_DAN_CAMERA_MAY_TINH_V31614.md](HUONG_DAN_CAMERA_MAY_TINH_V31614.md) trước.**

- KẹpD3: mở600us, **đóng2300us** trong cả điều khiển tay vàAUTO.
- Chạy `python/start_windows.bat` hoặc `python main.py`: Python tự mở **http://127.0.0.1:8766/control** khi máy chủ đã sẵn sàng.
- Camera lớn bên trái, điều khiển bên phải; có đổi quà, mốcAUTO, phóng toàn màn hình vàDỪNG. Bảng điều khiển này dùng chung camera/Arduino/AUTO với app.
- GiữIR nhận sớm vẫn hạ hết rồi đọc lạiIR, nhích160ms khi chưa nhận, VL53 20–25cm, ROI10×10, quàD4 2500→600→2500us.
- Chỉ cần chạy lạiPython mới nếu đang có firmwareV3.16.11 đúngROI/D4. Không bấmKết nối hoặcAUTO tự động khi chỉ mở giao diện.
- Các tài liệu phía dưới là lịch sử; thông số đóng2000us trong tài liệu cũ đã được thay bằng2300us.

---

# V3.16.13 — IR nhận sớm vẫn hạ hết tay

**Đọc [HUONG_DAN_IR_NHAN_SOM_V31613.md](HUONG_DAN_IR_NHAN_SOM_V31613.md) trước.**

- Đã bỏ các nhánh AUTO giữ tay chỉ vì D19 nhận trước vị trí gắp.
- Khi đã khóa vật/BIN mà IR nhận sớm: **dừng bánh → hạ hết tới P1=2310/P10=650 → đọc lại IR tại vị trí cuối**. IR nhận sớm cũng cho phép chuyển sang hạ cuối khi VL53 chưa vào20–25cm; không ghi giả trạng thái đủ khoảng cách.
- Lúc xuống hết: IR vẫn nhận ổn định300ms mới đóng kẹp; không nhận thì nhích160ms rồi kiểm tra lại, có giới hạn.
- Giữ ROI10×10, quàD4, kẹp2000us, STOP và D18. Firmware không đổi so vớiV3.16.11; chỉ cần chạy lạiPython mới nếu đã nạp đúng firmware đó.
- Các hướng dẫn cũ bên dưới là lịch sử. Nội dung giữ tay khiIR nhận sớm của các bản trước đã được thay thế trong luồngAUTO box/VL53.

---

# V3.16.12 — Hạ hết tay rồi mới xét IR D19

**Đọc [HUONG_DAN_IR_SAU_HA_V31612.md](HUONG_DAN_IR_SAU_HA_V31612.md) trước.**

Sau khi VL53 đủ20–25 cm, AUTO hạ hết tay tới **P1=2310/P10=650** rồi mới kiểm tra D19 để gắp. D19 báo trong lúc hạ cuối không làm dừng tay giữa đường. Chưa nhận IR: nhích160ms mỗi nhịp, dừng kiểm tra lại; có giới hạn.

Giữ ROI10×10, quàD4 và kẹp đóng2000us. Chạy lại Python trong ZIP mới; nếu đang dùng firmware V3.16.11 đúng ROI/D4 thì không cần nạp lại Arduino cho thay đổi này. Các tài liệu bên dưới là lịch sử, hướng dẫn mới được ưu tiên.

---

# V3.16.11 — Khoảng cách gắp 20–25 cm

**Đọc [HUONG_DAN_20_25CM_V31611.md](HUONG_DAN_20_25CM_V31611.md) trước.**

- Ngưỡng hiện tại: **200–250 mm**, tính cả hai đầu; đồng bộ Python, Arduino và thông báo giao diện.
- Giữ ROI **10×10**, quà **digital D4: 2500 → 600 → 2500 us**, đóng kẹp **D3: 2000 us**.
- Giải nén vào thư mục mới, nạp lại firmware Arduino và chạy Python trong ZIP này. Không dùng cấu hình cũ ghi đè ngưỡng.
- Các tài liệu phía dưới là lịch sử; ngưỡng 25–30 cm trong đó đã được thay bằng 20–25 cm.

---

# V3.16.10 — Bản gốc V3.16.4 + D4 Arduino + ROI10×10

**Đọc [HUONG_DAN_D4_ROI10_V31610.md](HUONG_DAN_D4_ROI10_V31610.md) trước.**

- Quà: digital D4 Arduino Mega, 2500 → 600 → 2500 us; sửa `python/gift_params.py`.
- Đóng kẹp D3: 2000 us; sửa `python/robot_params.py`.
- VL53L1X: ROI10×10; ngưỡng gắp giữ 25–30 cm như ZIP được gửi.
- Nạp lại firmware Arduino và chạy Python trong ZIP mới. Bản gốc tự SEARCH khi kết nối/RESUME, hành vi này được giữ.
- Các hướng dẫn phía dưới là lịch sử.

---

# V3.16.4 — AUTO tiếp tục khi VL53 chưa có số đo

Đọc `HUONG_DAN_V3_16_4.md` trước. **Phải nạp lại `arduino/robot_control_v3/robot_control_v3.ino` và chạy Python trong ZIP mới.** Chưa đọc được VL53/đang báo lỗi: AUTO vẫn tiến theo nhịp; số đo hợp lệ 250–300 mm: chuyển gắp. Không dùng hướng dẫn “không cần nạp Arduino” của các bản cũ bên dưới cho V3.16.4.

# V3.16.3 — Chẩn đoán VL53 và tự phục hồi trong thời gian chờ

Đọc `HUONG_DAN_V3_16_3.md` trước. Chạy lại Python từ ZIP mới; không cần nạp lại Arduino. Bản này giữ logic V3.16.2: một số đo hợp lệ 25–30 cm cho chuyển gắp, không chặn AUTO theo tuổi mẫu.

# V3.16.2 — Auto VL53 đủ khoảng cách thì gắp

Đọc `HUONG_DAN_V3_16_2.md` trước. Auto bỏ HOLD theo tuổi mẫu VL53; một số đo hợp lệ 25–30 cm cho chuyển sang chu trình gắp. Phải chạy lại Python V3.16.2 từ bản ZIP này; không cần nạp lại Arduino. Hướng dẫn mới này ưu tiên cho logic VL53 so với tài liệu lịch sử bên dưới.

# Bản sửa logic V3.16.1

Đọc `KIEM_TRA_LOGIC_V3_16_1.md` trước. Đã sửa 5 lỗi chuyển quyền/gắp/giữ vị trí; cần khởi động lại Python bản mới. Hướng dẫn V3.16 bên dưới tiếp tục áp dụng. Phần web đã triển khai production thành công tại https://waste-app-control.vercel.app/ (commit 1d235f5). Chạy lại Python bản này rồi tải lại trang web để nhận đầy đủ sửa lỗi.

# Bản hiện tại V3.16

Đọc **HUONG_DAN_V3_16.md** và **KIEM_THU_V3_16.md** trước. Nút 10°, gắp theo cảm biến, nâng/rút và giữ vị trí cần Python V3.16; hướng dẫn này ưu tiên hơn các tài liệu lịch sử bên dưới.

# Bản cập nhật V3.15

Đọc **HUONG_DAN_V3_15.md** và **KIEM_THU_V3_15.md** trước. Hướng dẫn V3.15 có ưu tiên khi khác tài liệu phiên bản cũ bên dưới.

# Waste Robot V3.14.2 — Box phục hồi + VL53L1X + D19

Bản đầy đủ V3.14.2, giữ nguyên luồng điều khiển camera + VL53L1X + D19 của V3.14.1. Giữ tài khoản, camera USB, LocateAnything,
BIN đã chốt, quỹ đạo tay, gắp/nâng/thả, D18 và STOP. Luồng đang bật là
`AUTO_CONFIG['box_tof_flow']` trong `python/robot_params.py`.

**Cần firmware V3.14 cho Mega2560; nếu đã nạp đúng V3.14 thì không cần nạp lại.** Code VL53 độc lập chỉ đo thử;
không chạy song song với firmware robot. Python cũ hoặc firmware cũ không đủ giao thức.

## Khởi động

1. STOP chương trình cũ; giải nén ZIP này vào một thư mục mới, không chép đè lẫn bản cũ.
2. Đấu VL53L1X: SDA→Mega20, SCL→Mega21, GND chung. Bus này dùng chung với PCA9685.
   PCA địa chỉ0x40, VL53 địa chỉ0x29. Nguồn/logic phải đúng thông số module đang có;
   không mặc định mọi bo VL53 đều chịu5V. Không đổi chân D18/D19 hoặc chân servo/motor.
3. Trong Arduino IDE chọn **Arduino Mega or Mega2560 / ATmega2560**. Cài thư viện
   Pololu VL53L1X1.3.1, Servo1.3.0, Adafruit PWM Servo Driver Library3.0.3,
   Adafruit BusIO1.17.4; mã các thư viện đã kèm trong `arduino/libraries`.
   Có thể chép các thư mục con đó vào thư mục `libraries` của Arduino sketchbook.
4. Mở `arduino/robot_control_v3/robot_control_v3.ino`, biên dịch và nạp.
5. Đóng Serial Monitor; chỉ một chương trình được giữ cổng COM. Sửa ARDUINO_PORT
   trong `.env` nếu cần. Tài khoản và các thông số kết nối khác giữ từ bản gốc.
6. Nếu chưa cài Python: chạy `python/INSTALL_WINDOWS_AUTO.bat`.
7. Chạy `python check_system.py` trong thư mục python; phải hiện V3.14.2 / BOX CẬP NHẬT + VL53L1X + D19.
8. Chạy `start_windows.bat`, mở app và Kết nối Python, START AUTO. Dòng đầu
   phải hiện **Waste Robot V3.14.2**. Không dùng AUTO_CONFIG/ROBOT_CONFIG trỏ JSON cũ;
   nguồn chính là robot_params.py. Không cần bật trang hiệu chuẩn.

## Logic chính xác đang dùng

### A. Tìm vật và căn theo ảnh, trước2050/727

- SEARCH1300/950. Xác nhận phân loại ban đầu qua nhiều ảnh, chốt nhãn/BIN và xoay đúng ngăn.
- Sau đó **một frame mới khớp vật khóa là đủ**. Box khóa cập nhật ngay theo ảnh đó;
  không giữ nguyên tọa độ/kích thước ban đầu, không lấy box ảnh mẫu làm box vật.
- Căn trái/phải trước. Bánh chỉ FORWARD/LEFT/RIGHT trong luồng trước, không BACK.
- Đáy box **trên mép trên dải cho phép**: giữ tay, tiến một nhịp.
- Đáy box **trong dải hoặc dưới dải**: giữ bánh, hạ một bước tay.
- Box sát mép trên/dưới ảnh: ưu tiên tiến một nhịp rồi quan sát lại, dù đáy đang
  nằm dưới dải. Dùng biên8/360 chiều cao ảnh (~8px ở640×360).
- Đây chỉ là **nghi cắt bởi khung ảnh**; không có model suy luận phần bị che.
  Box phình to khi tiến là bình thường, không tự bị coi là mất vật/che khuất.
- Box chạm mép trái: căn LEFT một nhịp; chạm mép phải: căn RIGHT một nhịp theo
  cấu hình hướng đang lưu. Dừng và nhận ảnh mới sau mỗi nhịp. Nếu đổi hướng camera,
  vẫn dùng positive_error_x_move như nhánh căn ngang cũ.
- Box quá nhỏ nhưng đúng khóa: căn ngang trước; đã căn thì tiến một nhịp có chặn VL53.
  Không suy khoảng cách từ kích thước box nhỏ.
- Box chạm **cả hai mép trái/phải**: không dùng tâm box để căn và không hạ tay theo
  box. Chuyển sang VL53 ngay ở tư thế hiện tại, ngừng nhận diện; tiến từng nhịp160ms,
  dừng250ms đọc lại. Nếu đã đủ25–30cm thì xác nhận mẫu ngay, không bắt buộc tiến thêm.
- Mọi nhịp FORWARD trong luồng trước bật chặn firmware VL53 trước khi chạy.
  VL53≤300mm hoặc lỗi/cũ thì phanh. Mẫu hợp lệ≤300mm cho vào nhánh xác nhận VL53;
  dưới250mm giữ chờ, không hạ gắp từ số đo ngoài cửa sổ.
- Dải ngang thay đổi theo tư thế tay từ các mốc đã lưu. Không suy khoảng cách từ
  kích thước chai mẫu. Camera chỉ vẽ dải trên ảnh hiển thị; ảnh gửi model sạch.

### B. Mất vật / sai mục tiêu khóa

- Tay và bánh đứng yên để kiểm tra tối đa3 **frame mới**.
- Bất kỳ frame nào khớp đúng vật: cập nhật box ngay và quyết định lại từ1 frame đó.
- Cả3 frame không khớp: lặp đúng một loại hành động trước đó. Đang tiến thì tiến;
  đang hạ thì hạ; đang căn ngang thì lặp một nhịp cùng hướng. Sau đó lại dừng kiểm tra.
- Không dùng box cũ như quan sát mới, không tự chọn lại một vật khác hoặc đổi BIN.
- **Ngoại lệ mới khi hành động trước là FORWARD:** nếu VL53 mới hợp lệ tới≤300mm,
  dừng chờ ảnh và chuyển sang xác nhận VL53 ở tư thế tay hiện tại. Đủ3 mẫu mới liên
  tiếp250..300mm thì đưa tay tới2310/650, dù chưa tìm lại box và chưa tới2050/727.
  Áp dụng cả khi HTTP nhận diện còn đang chờ; hủy yêu cầu đó trước khi bàn giao,
  kết quả trả muộn không được phát lệnh. Không cần chờ đủ3 frame mất vật để xét VL53.
- Nếu vẫn xa hơn300mm, sau3 frame mất/sai thì lặp **một nhịp tiến chậm160ms thực thi**,
  dừng rồi kiểm tra ảnh/VL53 tiếp. Nhánh mất vật lúc LOWER/LEFT/RIGHT giữ cách cũ.
- Chưa có hành động trước thì giữ chờ. Mất/sai tối đa6 hành động thử tiếp liên tục;
  thấy lại vật thì reset bộ đếm này. Giới hạn tổng:60 nhịp tiến,25 nhịp căn ngang,
  20 bước tay, và thời gian chu trình. Hết giới hạn thì giữ tay/bánh, STOP để kiểm tra.
- HTTP lỗi, ảnh cũ hoặc camera mất ảnh không được tính thành3 frame mất vật để chạy
  tiếp. Thử lại ở trạng thái dừng; lỗi nhiều lần thì giữ chờ.
- Ghép khóa dựa box gần nhất, liên tục hình học/màu và dự đoán tư thế tay; cho box
  thay đổi kích thước. Nhiều box giống nhau chưa phân biệt được thì tính là chưa khớp.
  Đây không phải định danh vật lý tuyệt đối của mọi lon giống hệt nhau.

### C. Bước tay

P1/S2 tăng tối đa50µs mỗi bước. **P10/S1 đi theo quỹ đạo đã lưu**, khoảng giảm15µs
mỗi bước P1+50. Không ép P10 cũng thay50 vì sẽ sai các cặp2050/727 và2310/650.
Ví dụ:2000/742→2050/727. Tay và bánh không chạy đồng thời.
P1 và P10 vẫn được gửi tuần tự theo bộ điều khiển cũ, có chờ từng servo;
bản này chưa đổi sang điều khiển hai servo đồng thời. STATUS là xung đã ra lệnh,
không phải phản hồi góc thực của servo.

Tới đúng **2050/727** thì **không lấy thêm frame nhận diện**. Nếu vừa hạ tới mốc,
chuyển sang giai đoạn VL53 ngay, không bắt buộc thấy lại box ở2050.
LiveKit/camera xem trực tiếp vẫn hoạt động; khóa nhãn/BIN của lượt được giữ.

### D. Tiếp cận bằng VL53L1X

- Có3 đường vào: đạt2050/727; box đúng khóa chạm cả hai mép ngang; hoặc VL53 tới
  ngưỡng khi hành động trước là FORWARD. Hai đường sau được phép trước2050/727.
- Giữ đúng tư thế tay lúc bàn giao; bánh tiến chậm từng nhịp160ms thực thi, nghỉ250ms.
  Tại2050/727 mà VL53 vẫn xa hơn30cm thì **tiếp tục tiến từng nhịp**, không hạ tay
  tới2310/650 cho đến khi đủ mẫu. Giới hạn40 nhịp/45s vẫn có hiệu lực.
- Cấu hình đúng code cảm biến đã gửi: Short, ROI8×8, center199, budget50000µs,
  period60ms. Firmware đọc dataReady/read(false), không delay100ms trong vòng robot.
- Đạt **250..300mm**, qua3 mẫu mới hợp lệ được Python quan sát và bộ đếm liên tiếp
  của firmware xác nhận: dừng bánh, đưa tay từng bước tới2310/650.
  Khi chuyển sớm, đi từ tư thế hiện tại qua quỹ đạo đã lưu, P1 tăng tối đa50µs/bước;
  không nhảy thẳng từ SEARCH tới2310. BIN và vật khóa vẫn là của lượt ban đầu.
- Không đếm nhiều lần cùng số thứ tự mẫu; cộng cả tuổi mẫu và tuổi STATUS.
  Mẫu lỗi/cũ: bánh dừng, thử đọc lại; quá6s không có dữ liệu dùng được thì giữ chờ.
- Nếu số đo đã **dưới250mm**: dừng và giữ chờ; không tiếp tục tiến, không lùi,
  không tự chuyển tư thế cuối từ số đo nằm ngoài cửa sổ xác nhận.
- Tiếp cận VL53 tối đa40 nhịp hoặc45s. Cảm biến phải nhìn đúng thân vật ở vị trí lắp.
  25–30cm tính từ cảm biến, không phải camera/S2. ROI8×8 vẫn có bề rộng, không phải tia đơn.
- Firmware chặn/phanh bánh ngay khi VL53≤300mm hoặc lỗi/quá cũ trong chặng này;
  Python sau đó xác nhận đủ mẫu mới quyết định tay. Khi chuyển gắp cuối thì bỏ
  chặn VL53 để còn nhích160ms bằng D19.

### E. Gắp cuối và thả

- Đã tới2310/650: không dùng ảnh hoặc khoảng cách5cm.
- D19 đã nhận: xác nhận ổn định300ms, không bắt buộc tiến thêm.
- D19 chưa nhận: tiến160ms/nhịp, nghỉ250ms; tối đa12 nhịp hoặc15s.
- D19 nhận thì phanh; ổn định mới đóng kẹp. Hết giới hạn không nhận thì không kẹp.
- D19 nhận sớm trước tư thế cuối: giữ chờ. Sau gắp: nâng ngược quỹ đạo, xác nhận
  còn vật, đưa PLACE tới BIN đã chốt, mở nắp/thả, xác nhận hết vật, rút tay/đóng nắp.
- D18 vẫn ưu tiên nhánh nhận rác sau; STOP hủy quyền AUTO và kết quả nhận diện về muộn.

## Thời gian và tham số

| Nhịp | Ramp/giữ/ramp | Tổng bánh chạy |
|---|---|---:|
| Tiến thường400ms danh định |160/240/160ms|560ms|
| Tiến lại do mất box sau3 frame |80/0/80ms|160ms|
| Chậm theo VL53 |80/0/80ms|160ms|
| Cuối theo D19 |80/0/80ms|160ms|

PWM vẫn BASE_SPEED=20; thời gian nghỉ/serial ở ngoài bảng. Chưa quy đổi nhịp thành cm.
Các biến hay chỉnh ở cuối robot_params.py: TOF_MIN_MM, TOF_MAX_MM,
TOF_CONFIRM_SAMPLES, TOF_SLOW_ACTUAL_MS, TOF_SLOW_SETTLE_MS; FORWARD_MS vẫn400.
Chi tiết giới hạn nằm trong AUTO_CONFIG['box_tof_flow']. STOP và chạy lại Python sau chỉnh.

Bản này chỉ giữ nhánh camera + VL53L1X + D19 cho cấu hình mặc định.
LocateAnything vẫn nhận diện qua endpoint cũ đến lúc bàn giao VL53. Bàn giao có thể
trước2050/727 trong hai nhánh mới; từ lúc đó không gọi nhận diện nữa.

## Kiểm tra

- `python check_system.py`: kiểm tra tham số, không mở USB/camera/mạng.
- `python demo_auto.py`: một lượt giả lập đầy đủ, không gọi model hoặc robot thật.
- `python -m pytest -q` từ thư mục gốc: bộ kiểm thử phần mềm. Có thể thêm `-n 4`
  để chạy song song sau khi cài requirements-test.txt.
- Đo cảm biến độc lập: `arduino/vl53l1x_test/vl53l1x_test.ino`; nạp lại firmware robot
  sau khi thử, không để sketch thử thay firmware khi chạy AUTO. Chỉ thử sketch riêng
  khi đã ngắt nguồn động cơ/servo hoặc dùng một bo thử riêng.

Kết quả kiểm tra bản hiện tại: `KIEM_THU_V3_14_2.md` và thư mục `verification`.
Firmware và thư viện Arduino giữ nguyên byte so với ZIP V3.14.1.
Chưa chạy kiểm tra trên robot thật trong lần dọn mã này. Kiểm tra mốc25–30cm và
quỹ đạo tay trên cơ khí thực tế trước khi vận hành.

## Những điểm cần biết

- Nguồn cấu hình chạy chính là `python/robot_params.py`. Các JSON và hướng dẫn
  trước V3.12 chỉ phục vụ công cụ cũ/kiểm thử tương thích; không trỏ AUTO_CONFIG
  về JSON cũ nếu muốn chạy đúng luồng VL53.
- `continuous_auto=True`: hoàn tất một lượt sẽ tiếp tục lượt mới dù `repeat=False`.
- Không thấy rác lúc bắt đầu: đứng yên chờ nhận diện; không tự quét phòng.
- Giữ chờ `auto_hold`: bánh dừng, duy trì xung tay; STOP để chỉnh lại.
- STOP: dừng bánh và tắt xung servo, không bảo đảm giữ tay bằng lực servo.
- Các nhịp cuối ở2310/650 dùng D19, chặn VL53 đã tắt; tối đa12 nhịp/15s.
- Gói giữ file `.env` gốc. Sửa cổng COM nếu cần và không công khai nội dung file.
