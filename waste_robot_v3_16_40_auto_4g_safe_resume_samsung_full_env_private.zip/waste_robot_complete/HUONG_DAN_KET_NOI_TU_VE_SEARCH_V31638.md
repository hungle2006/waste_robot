# Waste Robot V3.16.38 — Kết nối Vercel và tự về SEARCH

## Khi bấm **Kết nối Python** trên Vercel

- **Arduino chưa kết nối:** Jetson mở USB CH341, xác nhận đúng firmware, RESUME và **tự đưa tay về SEARCH**, đặt D3 mở, nắp đóng, ngăn về SETUP khi không có vật ở D19.
- **Arduino đang kết nối, tay đang ở tư thế khác:** Jetson dừng bánh (XM) và đưa riêng các servo thuộc tư thế `SEARCH` về xung được lưu trong `robot_params.py` — chỉ khi đã xác nhận trạng thái an toàn. Không tự chạy bánh hoặc khởi động AUTO.
- **Tay đã ở SEARCH:** chỉ báo thành công, không phát lệnh servo thừa.
- **STOP đang bật:** không tự RESUME/động tay chỉ vì nhấn Kết nối; cần người điều khiển xác nhận.
- **AUTO đang dùng cơ khí, đang gắp/giữ vật, D19 báo vật, kẹp chưa mở, D18 đang xử lý, bánh/tay chưa dừng:** từ chối hành động về SEARCH và báo lý do; không mở kẹp làm rơi rác.
- **AUTO checkpoint sau mất USB:** không vượt qua các bước kiểm tra phục hồi; ưu tiên checkpoint an toàn.

## Dây chuyền

`Vercel → Supabase Broadcast robot:robot_01 / command(connect) → Jetson realtime_bridge → Brain.connect → Serial USB → Arduino → servo về SEARCH → mechanical_ack → Vercel`.

## Cài đặt

1. Giải nén, cài phụ thuộc như README hiện có.
2. **Bảo mật:** ZIP này không chứa tệp `python/.env` vì nó có API Secret riêng. Sao chép `.env` từ dự án Jetson đang dùng sang thư mục `python/` của bản mới. **Không đưa `.env` lên GitHub**. Nếu chưa có `.env`, sao chép `.env.example` thành `.env`, điền thông tin từ môi trường của bạn.
3. Chạy `python3 python/main.py` từ thư mục `waste_robot_complete`.
4. Mở https://waste-app-control.vercel.app, bấm Kết nối Python và xem `job`, `busy`, `stopped` trên app.
5. Thử đầu tiên khi nâng bánh xe khỏi mặt đất, vùng di chuyển của cánh tay thông thoáng và không có vật trong kẹp.

## Xung SEARCH theo cấu hình hiện tại

S2/P1=1300 µs · S1/P10=950 µs · P11=1250 µs · D2=2100 µs · D3 mở=600 µs. Lần kết nối **đầu tiên** còn khởi tạo cấu hình SETUP (P4 nắp và P9 ngăn).

## Xác minh

```bash
PYTHONPATH=python python -m pytest -q tests/test_v31638_connect_search.py tests/test_control.py tests/test_realtime.py
```

**Lưu ý:** Đây là thay đổi trong phần mềm Jetson, **không cần nạp lại firmware Arduino nếu phiên bản hiện tại đã tương thích**. Ứng dụng Vercel nhận kết quả qua Supabase Realtime. Không có cơ chế tự trả về SEARCH chỉ nhờ LiveKit.
