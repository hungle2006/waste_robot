"""Self-healing Supabase Realtime session for high-jitter mobile networks.

The supervisor owns ONLY the cloud WebSocket. Arduino, camera, AI and robot
state live outside it, so reconnecting never resets hardware or resumes AUTO.
Each replacement gets a NEW client + channel; callbacks from retired sessions
are ignored. No modification to global asyncio.wait or site-packages required.
"""
import asyncio
import random
import time
import traceback


class RealtimeSupervisor:
    def __init__(self, service, supabase_url, publishable_key, robot_id,
                 create_client=None, subscribe_timeout=18.0, silence_timeout=12.0,
                 min_retry=1.0, max_retry=30.0):
        self.service = service
        self.url = supabase_url
        self.key = publishable_key
        self.robot_id = robot_id
        self.create_client = create_client
        self.subscribe_timeout = subscribe_timeout
        self.silence_timeout = silence_timeout
        self.min_retry = min_retry
        self.max_retry = max_retry
        self.stopping = asyncio.Event()
        self._broken = asyncio.Event()
        self._subscribed = asyncio.Event()
        self._generation = 0
        self._client = None
        self._channel = None
        self._last_ok = 0.0
        self._last_reason = ''
        self._loop = None
        self._old_exception_handler = None
        self._online_since = 0.0
        self._resume_task = None
        self.attempts = 0
        self.service.on_transport_failure = self.transport_failed

    def transport_failed(self, reason='WebSocket không phản hồi'):
        """Called by the gateway only after an actual transport failure."""
        self._last_reason = str(reason)
        self._broken.set()

    def _handle_background_exception(self, loop, context):
        """Catch the exact upstream empty-rejoins coroutine crash and rebuild.

        This is NOT a global asyncio.wait patch. Other errors keep their normal
        tracebacks, so library or application failures are never hidden.
        """
        exc = context.get('exception')
        origin = ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__)) if exc else ''
        if (isinstance(exc, ValueError) and 'Set of Tasks/Futures is empty' in str(exc)
                and ('_reconnect' in origin or 'realtime' in origin.lower())):
            print('[Realtime] Lỗi thư viện reconnect (danh sách tác vụ rỗng); tái tạo phiên an toàn.', flush=True)
            self.transport_failed('Thư viện Realtime gặp lỗi reconnect')
            return
        if self._old_exception_handler:
            self._old_exception_handler(loop, context)
        else:
            loop.default_exception_handler(context)

    async def _new_client(self):
        if self.create_client is not None:
            return await self.create_client(self.url, self.key)
        from supabase import acreate_client
        return await acreate_client(self.url, self.key)

    async def _offline(self, reason):
        self._last_reason = str(reason)
        if self.service.online:
            try:
                await self.service.disconnected()
            except Exception as exc:
                print('[Realtime] Không hoàn tất được STOP khi offline: {}: {}'.format(type(exc).__name__, exc), flush=True)
        self.service.online = False
        self.service.channel = None
        self._broken.set()

    async def _dispose(self):
        if self._resume_task is not None:
            self._resume_task.cancel()
            await asyncio.gather(self._resume_task, return_exceptions=True)
            self._resume_task = None
        client, channel = self._client, self._channel
        self._client = None
        self._channel = None
        # No late subscriber may re-enable the retired channel.
        self._generation += 1
        self.service.online = False
        self.service.channel = None
        if client is None:
            return
        if channel is not None:
            try:
                await asyncio.wait_for(client.remove_channel(channel), timeout=4.0)
            except Exception as exc:
                print('[Realtime] Bỏ qua lỗi dọn channel cũ: {}'.format(type(exc).__name__), flush=True)
        try:
            await asyncio.wait_for(client.realtime.close(), timeout=4.0)
        except Exception as exc:
            print('[Realtime] Bỏ qua lỗi đóng WebSocket cũ: {}'.format(type(exc).__name__), flush=True)

    async def _subscribe_once(self):
        from realtime import RealtimeSubscribeStates
        self._broken.clear()
        self._subscribed.clear()
        self._generation += 1
        generation = self._generation
        client = await asyncio.wait_for(self._new_client(), timeout=15.0)
        self._client = client
        channel = client.channel('robot:' + self.robot_id, {'config': {'broadcast': {'ack': True}}})
        self._channel = channel
        self.service.channel = channel

        def receive(payload):
            if generation == self._generation and not self.stopping.is_set():
                self.service.on_command(payload)

        def on_subscribe(status, error):
            if generation != self._generation or self.stopping.is_set():
                return
            async def process():
                if generation != self._generation or self.stopping.is_set():
                    return
                if status == RealtimeSubscribeStates.SUBSCRIBED:
                    self.service.online = True
                    self._last_ok = time.monotonic()
                    self._online_since = self._last_ok
                    self._subscribed.set()
                    print('[Realtime] ONLINE · {} · sẵn sàng nhận lệnh từ Vercel'.format(self.robot_id), flush=True)
                    try:
                        await asyncio.wait_for(self.service.publish_state(), timeout=6.0)
                    except Exception as exc:
                        await self._offline('Không gửi được trạng thái đầu tiên: ' + str(exc))
                        return
                    if hasattr(self.service, 'transport_restored'):
                        async def resume_if_stable():
                            await asyncio.sleep(3.0)
                            if (generation == self._generation and self.service.online
                                    and not self._broken.is_set() and not self.stopping.is_set()):
                                await self.service.transport_restored()
                        self._resume_task = asyncio.create_task(resume_if_stable())
                else:
                    label = getattr(status, 'name', str(status))
                    print('[Realtime] {} · {} · chuẩn bị kết nối lại'.format(label, type(error).__name__ if error else '-'), flush=True)
                    await self._offline('Kênh Supabase ' + label)
            asyncio.create_task(process())

        await asyncio.wait_for(channel.on_broadcast(event='command', callback=receive).subscribe(on_subscribe),
                               timeout=self.subscribe_timeout)
        await asyncio.wait_for(self._subscribed.wait(), timeout=self.subscribe_timeout)
        if not self.service.online or self._broken.is_set():
            raise ConnectionError('Kênh mất kết nối ngay sau khi SUBSCRIBED')

    async def _monitor(self):
        while not self.stopping.is_set():
            if self._broken.is_set():
                return
            if not self.service.online:
                raise ConnectionError('Không còn kết nối tới robot channel')
            last = getattr(self.service, 'last_broadcast_ok', 0.0)
            latest = max(last, self._last_ok)
            if time.monotonic() - latest > self.silence_timeout:
                raise TimeoutError('Không xác minh được phát trạng thái trong {:.0f}s'.format(self.silence_timeout))
            try:
                await asyncio.wait_for(self._broken.wait(), timeout=1.0)
            except asyncio.TimeoutError:
                continue

    async def run(self):
        self._loop = asyncio.get_running_loop()
        self._old_exception_handler = self._loop.get_exception_handler()
        self._loop.set_exception_handler(self._handle_background_exception)
        try:
            while not self.stopping.is_set():
                self.attempts += 1
                started = time.monotonic()
                try:
                    await self._subscribe_once()
                    self.attempts = 0
                    await self._monitor()
                    if not self.stopping.is_set():
                        raise ConnectionError(self._last_reason or 'Phiên cũ không còn hoạt động')
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    print('[Realtime] Offline: {}: {}'.format(type(exc).__name__, exc), flush=True)
                finally:
                    if not self.stopping.is_set():
                        await self._offline('Tái tạo kết nối Supabase')
                    await self._dispose()
                if self.stopping.is_set():
                    break
                # Exponential backoff with jitter avoids flooding reconnects on 4G.
                if time.monotonic() - started > 30:
                    self.attempts = 1
                delay = min(self.max_retry, self.min_retry * 2**min(self.attempts-1, 8))
                delay *= 0.85 + random.random()*0.3
                print('[Realtime] Thử lại sau {:.1f}s (lần {})'.format(delay, self.attempts), flush=True)
                try:
                    await asyncio.wait_for(self.stopping.wait(), timeout=delay)
                except asyncio.TimeoutError:
                    pass
        finally:
            self.stopping.set()
            await self._offline('Chương trình đang tắt')
            await self._dispose()
            if self._loop.get_exception_handler() == self._handle_background_exception:
                self._loop.set_exception_handler(self._old_exception_handler)

    async def stop(self):
        self.stopping.set()
        self._broken.set()
        await self._offline('Chương trình đang tắt')
        await self._dispose()
