# Kiểm tra Waste Robot V3.14.2

Đã chạy trên chính mã nguồn đóng trong ZIP:

- `python -m pytest -q -n 4`: 362 ca đạt. Bao gồm bám box, bàn giao sớm,
  phục hồi mất vật, mẫu VL53 mới/cũ/lỗi, xác nhận D19, khóa BIN, D18, STOP,
  nhận diện ảnh sạch, tương thích công cụ cũ và mô phỏng firmware C++ trên máy chủ.
- `python python/check_system.py`: cấu hình hợp lệ.
- `python python/demo_auto.py`: một lượt giả lập hoàn chỉnh, kết thúc `auto_done`,
  xác nhận đã mở kẹp thả vật trong mô phỏng.
- 47 file Python được kiểm tra cú pháp.
- 81 file firmware/thư viện Arduino giống hệt bản gốc; `.env` giữ nguyên byte.
- Cấu hình cơ khí và toàn bộ tham số Auto còn hoạt động giống bản gốc.
- Quét mã, cấu hình, giao diện và tài liệu: không còn module/cấu hình/API của
  nhánh ước lượng camera-Z đã bỏ.

Bộ kiểm thử ít hơn bản trước vì đã bỏ các ca riêng cho hai nhánh điều khiển
bị xóa. Các ca cho luồng VL53 và các tính năng giữ lại tiếp tục được kiểm tra.

Log chi tiết và phiên bản thư viện chạy kiểm tra nằm trong `verification/`.
Lượt kiểm tra đầu cần bổ sung thư viện SOCKS; sau khi cài đúng requirements-test.txt,
bộ kiểm thử được chạy lại đầy đủ. Các cảnh báo FastAPI/Starlette là cảnh báo
tương thích thư viện, không phải lỗi kiểm thử.

Không kết nối robot, camera hoặc API thật trong các kiểm tra này. Không biên dịch
lại bằng Arduino IDE/Mega toolchain trong lần sửa này; firmware không thay đổi.
Kết quả phần mềm không xác nhận độ chính xác cơ khí/cảm biến trên robot thật.
