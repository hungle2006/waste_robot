# Waste Robot V3.16.36 — Phát camera Jetson Nano lên Vercel qua LiveKit

## Đã khôi phục
- Giữ toàn bộ firmware/mã AUTO + MANUAL + D18 từ V3.16.35 (không thay đổi logic bánh).
- `python/.env` đã khôi phục **LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET** từ `V3.16.22` người dùng cung cấp. Đây là CẤU HÌNH RIÊNG, không được đưa lên GitHub hoặc chia sẻ ZIP.
- Phòng `robot_01`, track `front_camera`, `LIVEKIT_PUBLISHER=1`, `JETSON_LOCAL_CAMERA=1`, `LIVEKIT_VIEWER=0`.
- Arduino CH341 mặc định `/dev/ttyUSB0`; vẫn tự dò lại cổng.

## Vercel app đã có
Dự án `waste-app` (`https://waste-app-control.vercel.app`) có giao diện Camera robot bằng `livekit-client` và `GET /api/livekit-token` tạo token người xem chỉ `canSubscribe=true`, `canPublish=false`; route `/api/robot/configuration` cung cấp robotId và tên track. LIVEKIT_URL, API_KEY, API_SECRET hiện có trong Vercel Production. **Không sao chép khóa sang frontend**.

## Trên Jetson
1. Giải nén ZIP **riêng tư** vào thư mục riêng. Không push thư mục lên repository.
2. Mở terminal tại `waste_robot_complete`.
3. Chạy `python3 python/main.py --stream-check` (chỉ đọc cấu hình, không mở camera, không chạy bánh). Nếu SDK chưa cài, chạy `python3 python/main.py` để bootstrap tùy theo OS.
4. Chạy `python3 python/main.py` và chờ `[LiveKit] Đang phát camera lên phòng robot_01 / track front_camera`.
5. Mở `https://waste-app-control.vercel.app`, nhấn `Kết nối lại camera` khi trang mở trước Jetson.

## Xử lý lỗi
- `App LiveKit CHƯA BẬT`: kiểm tra môi trường Production ở Vercel có 3 khóa và deployment mới nhất đã nhận chúng.
- `RTC/API CHƯA SẴN SÀNG`: LiveKit chưa import được trên glibc/Python của Jetson; kiểm tra `--livekit-check`. JetPack 4/glibc 2.27 không tương thích các wheel RTC đã pin, cần nâng môi trường tương thích hoặc chọn giải pháp relay khác.
- Có camera ở localhost nhưng chưa thấy trên Vercel: nhìn log `[LiveKit] Đang phát camera...`; nếu không có, kiểm tra kết nối wss, secret có trùng Vercel, thông tin phòng/track, kết nối UDP/TCP tới LiveKit.
- App không tự kết nối lại khi track xuất hiện: bấm `Kết nối lại camera`.
- SDK nối được nhưng không thấy hình: kiểm tra camera chỉ mở một lần và LiveKit đã publish track.

## Bảo mật
File `python/.env` chứa khóa LiveKit thật từ ZIP cũ. KHÔNG đăng công khai tệp này hoặc ZIP V3.16.36. Nếu ZIP đã từng chia sẻ, hãy **đổi API key/secret trên LiveKit và cập nhật cả Vercel lẫn Jetson**. Dùng quyền truy cập phù hợp trên app vì endpoint cấp token người xem đang không có bước xác thực riêng.

Đã kiểm tra cú pháp và cấu trúc ZIP trên môi trường xây dựng, chưa có kết nối thực tế tới Jetson/LiveKit/Vercel để chứng thực luồng hình hoạt động.
