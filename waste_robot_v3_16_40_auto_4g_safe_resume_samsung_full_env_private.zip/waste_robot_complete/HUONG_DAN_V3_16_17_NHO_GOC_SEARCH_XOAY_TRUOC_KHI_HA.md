# Waste Robot V3.16.17 — Nhớ góc chai tại SEARCH, xoay D2 trước khi hạ tay

## Thứ tự hoạt động AUTO (luồng box/VL53)

1. Tay về SEARCH: P1=1300 µs, P10=950 µs, P11=1250 µs, D2=2100 µs, D3 đang mở.
2. Camera khóa đúng vật và BIN theo nhiều ảnh. Khi robot còn đứng yên ở SEARCH, lấy **3 ảnh MỚI** của **cùng một vật đã khóa**, xác định trục dài của vật bằng GrabCut/PCA, kiểm tra góc ổn định (chênh lệch từng ảnh tối đa 8°), ghi nhớ `angle_deg`, `mapped_deg`, `pulse_us`, `target_id`, `bin`, `label`, `source_pose` vào `AutoController.search_orientation`. **Chưa xoay D2 lúc này.**
3. Robot căn trái/phải và tiến FORWARD với cấu hình V3.16.16; lúc này D2 vẫn ở tư thế SEARCH. Camera và khóa vật tiếp tục hoạt động như cũ cho tới lúc chuyển VL53.
4. VL53 xác nhận khoảng cách 20–25 cm (200–250 mm): dừng bánh và kiểm tra thêm số đo, D19 chưa chạm, D3 mở, tay/bánh đứng yên, góc SEARCH đúng `target_id/BIN/label` của chu trình.
5. **Xoay D2 theo `pulse_us` ĐÃ LƯU ở SEARCH, trước khi hạ thêm P1/P10.** Đọc lại trạng thái servo theo xung lệnh; không dùng ảnh cận cuối để tính góc nữa.
6. Hạ tay dọc đường P1/P10 tới 2310/650 µs; **giữ D2 ở góc đã xoay trong MỌI bước hạ**. D19 lúc này mới là điều kiện xác nhận tiếp xúc để cho đóng kẹp D3=2300 µs. Nếu D19 chưa nhận, nhích tới từng nhịp 160 ms, giữ D2.
7. Sau gắp, nâng tay theo quỹ đạo và giữ góc D2 tới lúc đưa chai vào thùng; cảm biến D19 vẫn dùng để phát hiện mất vật. Khi quay lại SEARCH, D2 được trả về tư thế SEARCH. Góc nhớ **xóa khi bắt đầu lượt AUTO mới hoặc phục hồi do mất vật**, không dùng lại cho chai khác.

## Khi nào AUTO HOLD

- Không đo được 3 ảnh SEARCH mới, vật trôi/mất/đổi, góc không ổn định, ảnh cắt cụt hoặc trục không rõ.
- Ở SEARCH có nhiều vật cùng loại trong vùng nhận diện, không chắc đúng chai.
- Khi chuẩn bị xoay, cảm biến VL53 không hợp lệ/không nằm trong khoảng 20–25 cm, servo chưa đứng yên, kẹp chưa mở, D19 đã nhận vật, hoặc mã khóa vật/BIN không trùng với góc đã lưu.
- D19 báo **sớm** nhưng VL53 *chưa* xác nhận 20–25 cm: giữ chờ, **không xoay D2 và không hạ mù**. Nhánh này thay đổi so với cách tự hạ ngay theo D19 cũ để tránh xoay càng khi đã chạm vật.
- Hạ đến vị trí gắp nhưng D19 không xác nhận đúng theo giới hạn timeout hiện có.

## Góc servo và hiệu chuẩn

Cấu hình tại `python/robot_params.py`:

```python
AUTO_CONFIG['grasp_orientation'] = {
    'enabled': True, 'calibrated': True,
    'camera_sign': 1, 'offset_deg': 0.0,
    'calibration_pose': {'p1':2310, 'p10':650, 'p11':1250, 'd2':2100},
}
```

Lưu ý `calibration_pose` là tư thế **dành cho trợ giúp gắp thủ công cũ**; AUTO box/VL53 lấy tư thế SEARCH từ `arm_path.start`, không dùng ảnh cuối để tự xoay nữa.

Trục ảnh tính theo `grasp_orientation.py`, sau đó `mapped_deg = camera_sign * angle_deg + offset_deg`. Xung theo mốc cũ: -90°→500 µs, 0°→2100 µs, +60°→2500 µs; góc ngoài phạm vi hợp lệ sẽ HOLD. Chú ý trục 180° không có đầu/chân. `calibrated=True` **chỉ là cờ phần mềm**, chưa xác nhận góc hay chiều quay vật lý. Cần thử không tải và kiểm tra va chạm (đặc biệt tại cự ly 20–25 cm) trước khi gắp rác thật.

## Tệp được sửa

- `python/operator_control.py`: thêm `remember_search_orientation()` — ghi nhớ góc qua 3 ảnh SEARCH mới, có kiểm tra vật khóa, nhãn và BIN.
- `python/box_tof_flow.py`: thêm `rotate_saved_grip()` ở mốc VL53; giữ D2 qua toàn bộ bước hạ/kiểm tra D19.
- `python/auto_controller.py`: quản lý bộ nhớ góc cho mỗi chu trình; bỏ gọi nhận diện góc cuối trong AUTO box/VL53; không cho đóng D3 nếu D2 chưa xoay đúng xung được lưu.
- `python/robot_params.py`: chú thích lại trình tự mới, thông số còn lại không đổi.
- `tests/test_auto_orientation_v31617.py`: thêm kiểm thử SEARCH, VL53→D2→P1/P10, D19 sớm, thiếu hoặc sai bộ nhớ góc.
- `tests/test_box_tof_flow.py`: chạy kiểm thử logic căn bánh truyền thống khi không bật riêng cơ chế xoay góc.

## Phần được giữ nguyên

- Căn LEFT/RIGHT ×2, thời gian tiến FORWARD 560 ms danh định thực thi theo firmware, các nhịp VL53/IR 160 ms.
- FORWARD không giới hạn số đếm nhưng vẫn có chặn cảm biến/timeout/STOP.
- Quét tìm rác xoay phải tối đa 30 lượt; đổi quà 120 giây sau chu trình nhận rác D18 thành công.
- D19 mất vật sau gắp/nâng vẫn hủy lượt gắp và thu tay bằng logic phục hồi V3.16.15.
- Arduino/firmware không thay đổi so với V3.16.16.

**Kiểm thử là mô phỏng; chưa kiểm chứng thực tế với robot.**
