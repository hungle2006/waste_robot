> Tài liệu lịch sử trước V3.12. Với bản hiện tại, đọc README_CHAY_TRUOC.md và TINH_TOAN_V3_12.md.

# Dữ liệu chụp để nội suy khoảng cách và tư thế

Mục tiêu: xây dựng mô hình theo từng cặp xung S2/P1 và S1/P10. Ảnh gắp 27 cm hiện có là một mốc, chưa đủ đo khoảng cách liên tục khi camera thay góc.

## Bộ ảnh nên gửi

Ưu tiên 5 tư thế đã thử MANUAL an toàn, trải từ SEARCH tới gắp. Ghi P1/P10 thực tế đang giữ; P11 và D2 giữ nguyên. Không cần ép theo các xung trung gian do phần mềm nội suy nếu chưa thử được.
Mỗi tư thế chụp chai ở ít nhất 3 khoảng cách đo thật khác nhau trên cùng trục giữa, trong vùng camera còn thấy được. Có thể dùng 27/35/45 cm nếu các vị trí đó nhìn thấy; nếu không, chọn các khoảng nhìn thấy và ghi đúng số đo. Tổng dự kiến 15 ảnh; ảnh nào bị che thì ghi rõ, không hạ tiếp chỉ để đủ ảnh.

Mỗi ảnh ghi:
| Tên ảnh | P1/S2 (µs) | P10/S1 (µs) | X trên sàn (cm) | Y trên sàn (cm) | Ghi chú |
|---|---|---|---|---|---|
| pose01_Y27.jpg | điền xung thật | điền xung thật | 0 nếu giữa trục | số đo thật | thấy đủ / bị cắt / bị che |

Gốc X=Y=0: hình chiếu trục S2 xuống sàn. Y về trước xe; X ngang, phải dương/trái âm. Khoảng đo tới tâm đáy chai/hình chiếu tâm chai trên sàn. Không lấy mốc di chuyển như đầu kẹp hoặc ống kính.

## Cách chụp

- Dùng ảnh gốc từ camera USB gắn trên robot; giữ cùng độ phân giải, zoom và gá camera, không cắt ảnh. Không dùng ảnh điện thoại chụp robot thay ảnh USB.
- Giữ xe đứng yên và tay dừng hẳn trước mỗi ảnh. Đổi vị trí chai để lấy các khoảng khác nhau; ghi xung đang có cho từng ảnh.
- Kèm một ảnh chụp ngoài nhìn toàn bộ bố trí và thước để đối chiếu cách đo; không dùng ảnh ngoài đó làm hệ pixel USB.
- Nếu thuận tiện, đặt giấy vuông 17×17 cm trên sàn trong ảnh, đánh dấu rõ bốn góc và đo vị trí/chiều đặt giấy so với gốc S2. Giấy chỉ có kích thước mà chưa biết vị trí so với S2 sẽ không tự xác định được gốc robot.

Ảnh chai + khoảng cách dọc cho phép nội suy sơ bộ trong dải đã chụp, gần trục giữa. Để có tọa độ mặt sàn X/Y theo từng tư thế, cần thêm nhiều điểm sàn đã biết X/Y (ví dụ các góc giấy) và điểm kiểm tra độc lập không dùng để khớp mô hình.

Khi xử lý: trích điểm ảnh, xây bản đồ theo từng tư thế, nội suy giữa các tư thế lân cận, kiểm tra sai số bằng ảnh/điểm giữ lại. Không ngoại suy ngoài vùng đã đo và không dùng tâm box của chai cao như điểm nằm trên sàn.
