# V3.16.2 — Auto đủ khoảng cách thì chuyển gắp

Thay đổi theo yêu cầu: bỏ nhánh HOLD do tuổi mẫu VL53 trong Auto. Tài liệu này ưu tiên cho phần VL53 so với hướng dẫn các phiên bản trước.

## Hoạt động mới

- Sau khi khóa vật và chọn đúng BIN, Auto đọc trạng thái Arduino và dùng số đo VL53 hợp lệ gần nhất. Không dùng `age_ms` của VL53 để từ chối số đo trong Auto.
- Chỉ cần **một số đo hợp lệ trong 250–300 mm (25–30 cm)**, kể cả số thứ tự mẫu chưa đổi hoặc bộ đếm mẫu firmware chưa đủ ba. Auto thông báo đã đạt khoảng cách và chuyển sang đưa tay tới tư thế gắp.
- Có thể chuyển từ tư thế hiện tại trên quỹ đạo trước mốc 2050/727 khi đã đủ khoảng cách; không phải chờ thêm quyết định tiến/hạ từ camera.
- Điều kiện đủ khoảng cách được chốt cho lượt hiện tại. Không kiểm tra lại tuổi VL53, không có thời hạn một giây làm mất xác nhận trong lúc báo trạng thái, tắt chặn ToF hoặc đưa tay xuống.
- Tay đi đúng quỹ đạo S1/P10 trước S2/P1, tới 2310/650, rồi D19 xác nhận ổn định trước khi xoay/đóng kẹp và nâng. Chu trình thả theo BIN đã chốt tiếp tục như bản V3.16.1.

Auto chấp nhận **giá trị hợp lệ gần nhất, kể cả mẫu cũ**. Trường `valid`, trạng thái đo và số mm vẫn phải hợp lệ; số đo lỗi hoặc nằm ngoài cửa sổ không được coi là đã đạt khoảng cách. Dưới 250 mm vẫn ngoài cửa sổ gắp đang cấu hình.

## Phạm vi

- Thay đổi nằm trong Python chạy trên máy robot; giao thức điều khiển web vẫn tương thích.
- Nút gắp theo cảm biến ở Manual vẫn xác nhận mẫu mới riêng. Auto đỏ vẫn để người dùng điều khiển cơ khí.
- Trong Auto xanh, không cần bấm nút gắp khi nhánh VL53 đã đạt khoảng cách.
- STOP, mất kết nối USB, khóa vật/BIN, quỹ đạo và D19 vẫn được kiểm tra. Tuổi mẫu VL53 và tuổi trạng thái kết nối USB là hai điều kiện khác nhau.
- Firmware Arduino giữ nguyên. Phanh bánh của firmware khi VL53 cũ/lỗi vẫn hoạt động; khi Python đã nhận số đo hợp lệ trong cửa sổ, nhánh gắp vẫn đi tiếp. Không cần nạp lại Arduino cho sửa đổi này.
- `TOF_CONFIRM_SAMPLES=3` và `tof_max_age_ms=250` tiếp tục phục vụ xác nhận Manual. Auto nay dùng một số đo hợp lệ trong cửa sổ, không dùng hai tham số này làm cổng gắp.
- Nếu cảm biến chưa có số đo hợp lệ hoặc vẫn chưa tới khoảng cách gắp, Auto tiếp tục theo các giới hạn nhịp/thời gian chung; không có nhánh giữ chờ vĩnh viễn riêng mang lý do “VL53 quá cũ”.

## Cách cập nhật

1. Dừng chương trình Python cũ.
2. Giải nén ZIP V3.16.2 và chạy chương trình Python từ thư mục mới.
3. Kiểm tra dòng khởi động hiện **Waste Robot V3.16.2**; `python/check_system.py` cũng phải hiện V3.16.2.
4. Tải lại ứng dụng web và kết nối Python. Chỉ tải lại web mà không chạy lại Python sẽ vẫn dùng logic cũ.

Tệp `.env` giữ nguyên từng byte so với ZIP V3.16.1. Các hướng dẫn kết nối và điều khiển khác của V3.16 vẫn áp dụng.

## Kiểm thử

**122 trường hợp liên quan đã được xác minh qua các lượt chạy**, không phải toàn bộ danh mục kiểm thử của dự án.

| Kiểm tra | Kết quả | Nhật ký trong verification/ |
|---|---|---|
| Tám trường hợp mới trên mã cũ, trước khi sửa | Tái hiện lỗi/không đáp ứng hành vi mới | vl53_v3162_before.txt |
| Hồi quy Auto/VL53/camera, 87 trường hợp | 86 đạt; 1 lỗi phạm vi fixture đã sửa và chạy lại đạt | vl53_v3162_regression.txt |
| Nhóm mới cuối cùng, gồm ca fixture đã sửa | 10 đạt | vl53_v3162_final.txt |
| Manual, xoay 10°, HOLD/STOP và tranh chấp quyền | 35 đạt | vl53_v3162_manual_stop.txt |
| Cấu hình và quỹ đạo | Đạt | check_system_v3162.txt |
| Cú pháp Python | 31 tệp nguồn parse được | integrity_v3162.json |
| Arduino và .env | 81 tệp Arduino và 1 tệp .env giống từng byte | integrity_v3162.json |

Nhóm 10 ca mới trùng với lượt 87 ca; không cộng trực tiếp các dòng. 77 ca cũ trong lượt 87 đều đạt, 10 ca mới trong lượt cuối đều đạt, cùng 35 ca Manual/STOP, tổng cộng 122 ca khác nhau.

Lỗi fixture ở lượt rộng đã tính cả lệnh mở kẹp của bước khởi tạo vào phép kiểm “không đóng kẹp khi chưa có D19”. Fixture được sửa để chỉ xét các lệnh phát sinh từ thao tác đang kiểm tra; mã robot không được thay đổi để làm ca đó đạt. Giữ nhật ký lượt rộng để đối chiếu.

Các ca mới kiểm tra tuổi VL53 300/5000 ms và thiếu metadata tuổi, số thứ tự mẫu không đổi, bộ đếm firmware bằng 0, xác nhận khoảng cách già đi 30 giây, STOP chen vào trước bước hạ, D19 chưa nhận, và toàn bộ gắp–nâng–thả với metadata tuổi VL53 5 giây. Chu trình mô phỏng hoàn tất thành công.

Chưa chạy trên cơ khí/cảm biến thật trong môi trường này. Kết quả mô phỏng xác minh luồng phần mềm; góc D2 hiển thị vẫn tính từ xung lệnh đã nhận.

Chạy lại các nhóm liên quan từ thư mục gốc bộ robot:

```sh
python -m pytest tests/test_vl53_auto_ready_v3162.py tests/test_box_tof_flow.py tests/test_box_tof_recovery.py tests/test_operator_v316.py tests/test_logic_review_v3161.py -q
python python/check_system.py
```
