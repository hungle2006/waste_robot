> Tài liệu lịch sử trước V3.12. Với bản hiện tại, đọc README_CHAY_TRUOC.md và TINH_TOAN_V3_12.md.

# Kiểm tra V3.9

221 ca hiện có đạt qua các nhóm: 74 Mecanum/approach/khóa vật/V3.8.1, 120 cơ khí/AUTO/near/rear/realtime và 27 ca V3.9 (25 ca chính + 2 ca bổ sung cho IR đổi trạng thái đúng lúc gửi G). Các test vẽ ảnh lịch sử cũ đã được thay bằng kiểm tra video gốc, không có renderer và endpoint snapshot bị bỏ theo yêu cầu người dùng. Không tính các test tính năng đã bỏ vào kết quả mới.

27 ca mới gồm: PWM tăng/giảm đơn điệu và về 0 ở nhiều công suất; giữ diện tích PWM-thời gian danh nghĩa; biên dịch/chạy sketch .ino thật bằng g++ với Arduino/Servo/PCA giả lập trên host; vòng đầy đủ nhịp G → chuyển tay sớm → các bước 8 µs → IR → gắp/thả; lùi một bước khi camera đi sai hướng; mất vật, lệch ngang, mất phản hồi tay, vật đã bị vùng càng che; từ chối AUTO mềm trên firmware cũ; STOP giữa ramp không tái chạy; D19 phanh nhịp; D18/D19 đổi ngay lúc G bị firmware chặn vẫn chuyển luồng REAR/giữ tại chỗ thay vì lỗi kết thúc AUTO; tham số sai; bước dự đoán và giới hạn độ phân giải PCA; API preview gốc, snapshot 404, cấu hình có token và không được sửa khi AUTO đang sở hữu.

Sketch host kiểm tra: khởi động STOP; profile hữu hạn tự về 0; không thay profile đang chạy bằng C; XM/STOP hủy profile không tái khởi động; D18/D19 chặn profile; watchdog khóa sau mất liên lạc. Đây là kiểm tra C++ với phần cứng giả, KHÔNG phải biên dịch/nạp thử trên Mega thật bằng AVR toolchain và thư viện thật.

Python/JSON/JavaScript trang hiệu chuẩn kiểm tra cú pháp; ZIP kiểm tra CRC và loại cache/log/binary sinh ra. .env, robot_config.json, mốc pose/giới hạn servo và ma trận hiệu chuẩn tham khảo đối chiếu giữ nguyên. Firmware có thay đổi có chủ đích: lệnh G và smooth_protocol=1; phải nạp lại, không dùng nhận xét “firmware không đổi” của phiên bản trước.

Mốc chuyển tay 54%, vùng che 60%, bước 8/5 µs là giá trị thử theo ảnh/log, chưa kiểm tra tầm với/khoảng sáng/vị trí tiếp xúc thật. Không tự chạy bánh khi tay đã hạ. Độ phân giải PCA9685 hiện khoảng 4.88 µs/tick nên bước gần mép mặc định 5 µs, không dùng 1–2 µs để giả định servo đã dịch.

Kiểm tra dùng Python 3.12, OpenCV và robot giả lập/ảnh tổng hợp; chưa chạy trên Python 3.14 của người dùng, Arduino/camera vật lý, Modal thật hoặc LiveKit/Vercel thật. Không cam kết chuyển động hoàn hảo, nhìn thấy vật bị che hoàn toàn hoặc đo được khoảng cách cm. Mỗi nhịp vẫn dừng chờ ảnh mới từ Modal; profile chỉ làm mềm PWM trong nhịp, không có local tracker để điều khiển liên tục khi model đang xử lý.

Tài liệu AUTO_V3_3_HUONG_DAN.md và MODAL_BOX_V3_8.md cũ đã được thay bằng AUTO_V3_9_HUONG_DAN.md và MODAL_API.md. Bản cũ có thể khôi phục từ ZIP V3.8.1 trước đó. Nội dung kiểm tra cũ đã thay bằng tài liệu này cho đúng tính năng hiện tại.
