# WASTE ROBOT V3.16.27 — D18 ưu tiên AUTO và MANUAL

Phiên bản nền: V3.16.26. Thay đổi này là ở **Python**; firmware `arduino/robot_control_v3/robot_control_v3.ino` giữ nguyên so với bản nền.

## 1. D18 phát hiện (LOW) khi đang tìm/gắp rác phía trước

- D18 được giám sát tại máy Python, không phụ thuộc UI cloud đang online. Trong MANUAL, D18 tự được bật giám sát khi Arduino đã kết nối, camera có sẵn và chưa dùng nút `AUTO REAR OFF` để tắt chủ động.
- Khi có vật: phanh bánh ngay tại tầng Python, đồng thời Arduino vốn có chốt cứng D18 nên cũng từ chối nhịp bánh. Không mở kẹp đột ngột và không cắt ngang một lệnh servo khi chưa biết vị trí thật.
- Nếu chưa giữ vật: khi động tác servo hiện tại hoàn tất, rút cánh tay về SEARCH theo **đường rút hợp lệ**. Nhánh S2 xuống trước, S1 giữ SEARCH có đường rút S2 riêng. Sau đó đóng nắp, đưa camera REAR và phân loại.
- Nếu **AUTO đã gắp và đang giữ vật**: hoãn đổi sang REAR đến khi đã mang vật vào **BIN đã khóa**, mở D3 để thả đúng thùng, rút tay và đóng nắp. Nếu D19 phát hiện mất vật, quy trình xác minh/giữ an toàn như phiên bản trước vẫn có hiệu lực. Không xả chai đang giữ xuống nền để đáp ứng D18.
- Nếu **MANUAL đang kẹp**: chỉ tự đưa vật đến PLACE và thả khi biết BIN đã xác nhận (`held_bin`), D3 đang đóng, D19 báo đang giữ và quỹ đạo tay phù hợp. Nếu thiếu một điều kiện, máy **giữ kẹp**, hiển thị `rear_manual_inspection` và chờ người vận hành. Không tự suy đoán BIN hoặc tư thế.
- Trong MANUAL, thao tác mới tạm khóa khi D18 đang đợi/đang chạy; STOP/XM và nút tắt giám sát D18 còn khả dụng để xử lý có kiểm soát.

## 2. Quy trình nhận rác phía sau

D18 -> dừng bánh -> hoàn tất thả chai đang giữ nếu an toàn -> đóng nắp -> đưa tay REAR -> camera chụp, yêu cầu 2 lần phân loại cùng loại tối đa 4 lần -> xoay thùng BIN -> mở nắp -> chờ D18 hết phát hiện ổn định 500 ms -> đóng nắp -> về SEARCH. Chỉ khi nhận xong mới có quyền đổi quà 120 giây (tính năng giữ nguyên).

Nếu D18 không hết nhận trước thời hạn 12 giây hoặc phân loại chưa hợp lệ, hệ thống vẫn thực hiện bảo vệ lỗi, không đóng nắp vào vật cản.

## 3. AUTO tìm lại rác sau khi xử lý D18

**Chỉ AUTO cơ khí** tự điều khiển bánh sau D18. MANUAL không tự lùi/quay.

- Chỉ bắt đầu khi D18 đã rời, D3 mở, nắp đóng và toàn bộ tay đã về SEARCH.
- Chụp ảnh mới khi bánh đứng yên. Nếu thấy rác ngay thì không lùi, để chu trình SEARCH mới khóa vật và đo lại góc.
- Nếu ảnh hợp lệ mà chưa có rác: BACK **400 ms danh định/nhịp**, dừng **2.000 ms** kiểm tra ảnh, tối đa **10 nhịp**.
- Nếu sau 10 nhịp chưa thấy: chuyển sang quét phải đã có, khoảng **5 giây quay + 1 giây dừng**, lặp liên tục khi AUTO còn bật.
- Nếu camera lỗi hoặc không có ảnh mới thì không tiếp tục lùi mù. Nếu D18 kích hoạt lại trong khi lùi/quay thì ưu tiên xử lý D18.
- Thời gian FORWARD, căn LEFT/RIGHT ×2, góc D2 không xoay nếu |góc| < 10°, S2/S1 và xử lý rơi chai được giữ nguyên.

## 4. Các file Python đã sửa

- `python/brain.py`: ưu tiên D18, phanh bánh, khóa lệnh MANUAL khi có sự kiện; cho phép thao tác MANUAL bình thường khi D18 chưa kích hoạt.
- `python/auto_controller.py`: chuyển REAR có bảo vệ kẹp, thả vật MANUAL vào BIN hợp lệ, quỹ đạo rút S2 trước, lùi tìm rác AUTO sau D18.
- `python/operator_control.py`: không bắt tắt D18 chỉ để dùng gắp MANUAL khi D18 còn rảnh.
- `python/realtime_bridge.py`: D18 chạy cả không có kết nối UI cloud; camera DETECT MANUAL không bị khóa khi D18 đang rảnh.
- `python/robot_params.py`: thêm `rear.post_rear_back_steps`, `rear.post_rear_back_ms`, `rear.post_rear_settle_ms`.
- `python/main.py`: cập nhật tên phiên bản hiển thị.
- `tests/test_v31627_d18_manual_priority.py`: kiểm thử mới.

## 5. Yêu cầu thử nghiệm phần cứng

1. Thử riêng D18 khi bánh đang chạy MANUAL, xác nhận motor dừng và STOP vẫn hoạt động.
2. Thử D18 khi tay ở SEARCH và khi S2 đã hạ riêng; bảo đảm tay không quệt đất hoặc thành thùng.
3. Thử cầm chai đúng BIN ở cả AUTO và MANUAL, quan sát lệnh D3 chỉ mở khi tay tại PLACE, nắp mở và D19 còn tín hiệu.
4. Thử trường hợp MANUAL kẹp vật nhưng BIN chưa biết: hệ thống phải giữ kẹp, tuyệt đối không thả tự động.
5. Kiểm tra vùng trống **phía sau** trước khi bật lùi tự động: robot chưa có cảm biến tránh vật cản phía sau. Chạy có người giám sát và sẵn nút STOP.
6. Ngắt camera và mô phỏng D18 kích hoạt lại khi đang lùi để xác nhận bánh không chạy mù.

**Cảnh báo:** Xung servo được xác nhận bằng lệnh gửi/STATUS, không phải encoder phản hồi cơ khí. Chưa thử trực tiếp trên robot thực. Những tư thế chưa xác minh sẽ dừng bảo vệ thay vì tự thực hiện động tác nguy hiểm.

## 6. Kiểm thử

- 8/8 test mới V3.16.27 đạt (gồm MANUAL có vật và BIN hợp lệ -> tự thả -> REAR, điều kiện chưa biết BIN -> giữ kẹp, tìm ảnh sau REAR, MANUAL observer).
- 7 test REAR/định tuyến cũ được chọn đạt trong lần kiểm tra trước, gồm 4 BIN.
- Không khẳng định toàn bộ bộ kiểm thử hệ thống đã chạy hết hoặc phần cứng đã được xác thực.
