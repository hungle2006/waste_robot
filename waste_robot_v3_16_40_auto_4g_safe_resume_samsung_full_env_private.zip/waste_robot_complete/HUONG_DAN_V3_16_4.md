# V3.16.4 — AUTO vẫn tiến khi VL53 chưa đọc được

## Quy tắc mới theo yêu cầu

- Trong AUTO, chưa có mẫu VL53, cảm biến báo lỗi, mm không hợp lệ hoặc cảm biến chưa có mặt: tiếp tục các nhịp tiến của luồng hiện tại. Không chờ lỗi 6/45 giây trước nhịp tiến, không phát `auto_tof_retry`, không HOLD chỉ vì mẫu VL53 không hợp lệ.
- Khi có số đo hợp lệ 250–300 mm, dừng tiến và chuyển chu trình gắp. Chỉ một số đo đủ điều kiện; tuổi mẫu và việc seq chưa đổi không chặn AUTO. mm đi kèm cờ invalid không được dùng để xác nhận gắp.
- Trước mốc bàn giao, camera vẫn quyết định tiến/căn/hạ tay bằng box. Sau bàn giao, tiếp tục nhịp tiến chậm khi chưa có khoảng cách. Thiếu ảnh mới hoặc mất vật vẫn áp dụng kiểm tra camera riêng.
- Số đo hợp lệ dưới 250 mm vẫn dừng tiến vì đã vượt cửa sổ gắp. Cảm biến chưa bao giờ trả số đo phù hợp thì không tự gắp.
- Giữ STOP, quyền cơ khí, USB, D18/D19, thời gian và số nhịp tối đa hiện có. Sau số nhịp/thời gian tối đa mà chưa đủ khoảng cách, hệ thống vẫn dừng; không chạy vô hạn. D19 cuối chu trình vẫn xác nhận trước đóng kẹp.
- Nút ngắt cơ khí ở AUTO vẫn giữ quyền điều khiển thủ công như trước.

## Cài đặt bắt buộc

1. Dừng Python cũ.
2. Nạp sketch `arduino/robot_control_v3/robot_control_v3.ino` trong ZIP này vào Arduino Mega 2560. Thư viện cần thiết đã có trong `arduino/libraries` và hướng dẫn trong `arduino/LIBRARIES.md`.
3. Đóng Serial Monitor rồi chạy Python từ thư mục ZIP mới. Dòng khởi động phải hiện V3.16.4.
4. Phải cập nhật cả hai phía. Python mới kiểm tra khả năng firmware trước AUTO để tránh chạy với firmware cũ vẫn chặn bánh khi VL53 lỗi. Không cần sửa Vercel cho thay đổi điều khiển này.

## Chi tiết tương thích

Lệnh mới `TF AUTO 250 300` chọn chính sách bỏ qua mẫu lỗi khi chạy bánh, vẫn phanh khi có số đo hợp lệ <=300 mm. Firmware báo `tof_auto_continue: true` và `tof.invalid_policy: "continue"`. Lệnh cũ `TF 250 300` vẫn giữ chính sách chặn mẫu lỗi/quá cũ; `TF OFF` và STOP xóa chính sách AUTO này. Manual vẫn dùng quy tắc xác nhận khoảng cách riêng.

## Kiểm tra

Kết quả hiện tại trong `verification/v3164_regression.txt`, `verification/vl53_continue_focused.txt` và `verification/integrity_v3164.json`. Kiểm tra firmware bằng biên dịch/chạy sketch thực tế trên bộ mô phỏng host C++; không thay thế việc biên dịch cho board và chạy thử robot thật. Các log V3.16.3 trở về trước trong ZIP chỉ là lịch sử, không chứng minh hành vi V3.16.4.
