# Waste Robot V3.12 — năm mốc tay và thời gian bánh theo đoạn

Bản này dùng trực tiếp `python/robot_params.py`. ZIP có `.env` gốc của bạn,
Arduino, Python, mã web, ảnh tham chiếu và bộ kiểm thử. Không cần mở trang
hiệu chuẩn hoặc chụp thêm ảnh chỉ để khởi động cấu hình này.

## Chạy

1. STOP AUTO, tắt Python cũ và giải nén toàn bộ ZIP.
2. Nếu chưa cài thư viện: chạy `python/INSTALL_WINDOWS_AUTO.bat` trên Windows;
   trên Linux, cài `python/requirements.txt` và `python/requirements-camera.txt`.
3. Kiểm tra cổng Arduino trong `python/.env`. Giữ cấu hình LiveKit/ứng dụng đã có.
   Bỏ biến `ROBOT_CONFIG`/`AUTO_CONFIG` nếu trước đây tự đặt trỏ tới JSON cũ.
4. Mở terminal tại thư mục `python`, kích hoạt venv nếu đã cài bằng trình cài
   (`.venv\Scripts\activate` trên Windows), chạy `python check_system.py`.
5. Chạy `python main.py` hoặc `start_windows.bat`/`start_linux.sh`, kết nối app,
   kiểm tra ảnh USB rồi START AUTO như trước.

Firmware giao thức V3.9 vẫn dùng được; V3.12 không sửa firmware. Nếu Arduino
chưa có giao thức chạy bánh mềm, nạp sketch đi kèm.

Kiểm tra phần mềm hoàn toàn offline, không dùng Arduino/camera/tài khoản:

```bash
python check_system.py
python analyze_measurements.py
python demo_auto.py
```

`demo_auto.py` tự tạo box và D19 giả lập để chạy hết gắp → nâng → thả. Kết quả
mô phỏng không xác nhận độ chính xác trên robot thật.

## Các mốc đang dùng

Khoảng cách trong bảng do bạn xác nhận đo từ **ống kính tới chai**.

| Tư thế | P1/S2 µs | P10/S1 µs | Ống kính → chai | Ảnh |
|---|---:|---:|---:|---|
| SEARCH | 1300 | 950 | 60 / 75 / 90 cm | 1 / 2 / 3 |
| Mốc 2 | 1550 | 876 | 45 cm | 4 |
| Mốc 3 | 1800 | 801 | 24 cm | 7 |
| Mốc 4 | 2050 | 727 | 12 cm | 5 |
| Gắp | 2310 | 650 | 5 cm | 6 |

Mốc **27 cm từ hình chiếu S2 tới chai** của ảnh trước được giữ riêng. Không
lấy 5 cm thay cho 27 cm hoặc lấy hiệu hai khoảng camera làm quãng đường bánh.

SEARCH chọn ảnh75 cm làm mục tiêu chuyển tay vì ảnh60 cm đã bị gá kẹp che
phần dưới chai. Có thể lùi từng nhịp nếu vật đã vượt vùng này; không cố giữ
SEARCH đến khi chai cách S2 27 cm.

## Chỉnh trong robot_params.py

| Nhóm | Ý nghĩa |
|---|---|
| `ARM_MEASURED_POINTS` | Năm cặp xung và số cm tham chiếu |
| `STAGE_TIMING` | Tiến/lùi/ngang, nghỉ, nhịp servo và số nhịp tối đa mỗi đoạn |
| `S2_STEP_US` | Bước P1 danh định50 µs; bước cuối10 µs |
| `MAX_WHEEL_P1_US` | Tắt bánh từ2260 µs trở đi |
| `USB_MEASUREMENTS` | Chú giải pixel trên ảnh gốc1920×1080 |
| `pose_profile` | Dung sai ảnh, số ảnh ổn định và giới hạn phản hồi |
| `ROBOT_CONFIG` | SEARCH/PLACE/REAR, thùng, nắp, kẹp, giới hạn servo |

STOP rồi chạy lại Python sau khi sửa. `.py` là cấu hình chính; JSON cũ chỉ để
tương thích. Không có quy trình tự ghi đè thông số bạn vừa chỉnh.

Thời gian mặc định, đơn vị ms:

| Đoạn bắt đầu ở P1 | Tiến | Lùi | Ngang | Nghỉ sau nhịp/bước tay | Nhịp servo |
|---|---:|---:|---:|---:|---:|
| 1300 | 120 | 60 | 80 | 500 | 60 |
| 1550 | 80 | 60 | 60 | 500 | 70 |
| 1800 | 60 | 60 | 60 | 600 | 80 |
| 2050 | 60 | 60 | 60 | 700 | 90 |
| 2310 | Bánh tắt | Bánh tắt | Bánh tắt | 700 | 90 |

Tiến/lùi/ngang là thời gian **danh định theo diện tích PWM**. Với ramp hiện tại,
60 ms thực thi trong120 ms; 80→160 ms; 120→240 ms. Sau đó còn thời gian nghỉ.
Các nhịp này chưa quy đổi thành cm. Chỉnh từng giá trị nhỏ rồi đánh giá ảnh
mới sau nhịp; không nhập thời gian dài để chạy mù.

## AUTO hoạt động

Khóa cùng vật/phân loại → xoay đúng BIN khi nắp đóng → ở mỗi tư thế so chai
với mốc ảnh nội suy → nhích bánh nếu cần, phanh và lấy ảnh mới → khi ảnh ổn
định mới hạ P1/P10 một bước → lặp tới gắp. P11/D2 giữ nguyên.

Tiến khi đáy chai còn cao hơn vùng mục tiêu; lùi khi vượt vùng mục tiêu. Căn
ngang trước, giới hạn số nhịp từng chiều/đoạn. Phản hồi bánh chỉ so ở cùng tư
thế tay. Nếu sai chiều, không cải thiện, mất chai, cắt ngang/đáy hoặc D19 xuất
hiện sớm: giữ tại chỗ. Từ P1≥2260 µs không chạy bánh thêm.

Ảnh gần cho phép cắt đầu từ P1=1800. Mốc cuối cần ảnh mới ổn định, đúng vùng
ngang/đáy, đủ phần chai và D19 xác nhận mới đóng kẹp. Nâng ngược quỹ đạo P1/P10,
kiểm tra giữ vật rồi đưa tới BIN, mở nắp/thả. D18 nhận rác sau vẫn hoạt động;
STOP hủy quyền điều khiển và chặn lệnh đến muộn.

## Phạm vi kiểm chứng

Đọc `TINH_TOAN_V3_12.md` để xem công thức, ma trận giấy17×17 cm tính lại, bảng
pixel và nguồn kỹ thuật. Viền chai được đọc thủ công, có che khuất và sai số;
dung sai/thời gian là giá trị khởi đầu để thử. Các ảnh này không xác định đầy
đủ K camera, góc cơ khí hoặc cm/pixel ở mọi tư thế. Phần mềm không biến phép
đo chưa có thành số đo thật. Chưa chạy kiểm chứng trên robot thật.

Tài liệu V3.11 trở về trước được giữ để truy vết. Hướng dẫn V3.12 và
`robot_params.py` có ưu tiên cho bản hiện tại.
