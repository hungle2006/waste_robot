# Waste Robot V3.16.39 — Supabase Realtime tự khôi phục khi 4G chập chờn

**Bản ZIP đầy đủ**, kế thừa trực tiếp từ V3.16.38. Không thay đổi firmware Arduino, chân D18/D19, logic gắp, mô hình nhận diện Modal, giao diện Vercel hay cấu hình LiveKit.

## Lỗi được xử lý

Ở phiên bản cũ, thư viện `realtime` đôi khi rơi vào `_reconnect()` rồi gọi `asyncio.wait(rejoins)` khi danh sách rỗng, gây `ValueError: Set of Tasks/Futures is empty.`. Thêm băng thông 4G/5G không giải quyết được đường xử lý ngoại lệ đó. Bản V3.16.39 **không sửa global `asyncio.wait` hoặc tự ý ghi đè site-packages**. Thay vào đó, `realtime_supervisor.py` giám sát kênh Realtime, bắt lỗi nền phù hợp và **tạo lại client WebSocket + channel mới**, kể cả khi callback reconnect của thư viện gặp lỗi.

- Phân biệt `SUBSCRIBED` với `CLOSED`, `TIMED_OUT`, `CHANNEL_ERROR`; thông báo trạng thái rõ ràng.
- Đăng ký lại kênh `robot:<robot_id>` và sự kiện `command`; bỏ qua callback của kênh cũ.
- Kiểm tra trạng thái gửi: `mechanical_state`, `mechanical_ack`, `status` có timeout 6 giây. Nếu không xác minh được trạng thái trong 12 giây, thay phiên kết nối.
- Thử lại theo cấp số nhân 1 → 2 → 4 → 8 → 16 → 30 giây, có dao động nhỏ, tránh spam Supabase khi mạng chết.
- Khi khởi động, nếu tải cấu hình Vercel thất bại vì mạng, tự thử lại thay vì kết thúc chương trình; khi cấu hình sai, vẫn báo lỗi rõ ràng.
- **Không đổi phiên/ID của Dispatcher:** cùng một phiên Python giữ nguyên `session_id`, `request_id` đã ghi nhận và `epoch`, nhằm tránh thực thi lại lệnh cũ khi cloud kết nối lại.
- Giữ ACK riêng của **robot**, không nhầm với việc Supabase xác nhận nhận Broadcast.

## An toàn khi mất mạng

- Khi mất kênh điều khiển, `RealtimeService.disconnected()` dừng AUTO và gửi STOP qua Arduino (nếu Arduino còn kết nối). Không thực thi tiếp lệnh DRIVE cũ; không khởi động lại AUTO chỉ vì 4G có sóng trở lại.
- Sau khi WebSocket khôi phục, app cần nhận trạng thái mới. **Người điều khiển phải kiểm tra robot và chủ động RESUME/START khi phù hợp.** Không tự mở D3 hay chạy bánh xe khi chưa xác minh trạng thái.
- Đường ảnh Jetson → Modal AI **vẫn trực tiếp**, không trung chuyển qua Supabase. LiveKit tiếp tục là luồng video riêng.
- Nếu 4G bị chặn WebSocket, mất Internet kéo dài, sai khóa Supabase, hỏng USB hay firmware, ZIP không thể khôi phục kết nối cho đến khi nguyên nhân bên ngoài được sửa.

## Cài đặt nâng cấp (Jetson Nano / VS Code)

1. Dừng Python cũ; đảm bảo bánh đã dừng, không còn thao tác gắp dang dở.
2. Giải nén ZIP trong thư mục mới, **không ghi đè ngay bản đang chạy**.
3. Chép tệp `python/.env` **của bạn** từ bản cũ sang `waste_robot_complete/python/.env` mới. Bản ZIP **không chứa** tệp `.env` có thông tin bí mật.
4. Giữ hoặc chép `robot_params.py` nếu bạn đã tự hiệu chuẩn giá trị khớp, PWM, camera; cũng kiểm tra đường `AUTO_CONFIG`, `ROBOT_PARAMETERS`, `ROBOT_CONFIG` trong `.env` nếu có.
5. Mở Terminal trong thư mục `waste_robot_complete`, chạy:

```bash
python3 python/main.py
```

Chương trình vẫn có cơ chế kiểm tra/cài thư viện dành cho Jetson như bản cũ. Nếu đã dùng `.venv`, có thể kích hoạt đúng môi trường rồi chạy chương trình. Bộ ZIP không cần thay đổi ứng dụng Vercel.

## Thông báo có thể thấy ở Terminal

```text
[Realtime] ONLINE · robot_01 · sẵn sàng nhận lệnh từ Vercel
[Realtime] TIMED_OUT · - · chuẩn bị kết nối lại
[Realtime] Offline: ConnectionError: ...
[Realtime] Thử lại sau 2.0s (lần 2)
[Realtime] ONLINE · robot_01 · sẵn sàng nhận lệnh từ Vercel
```

Nếu lại gặp lỗi thư viện `Set of Tasks/Futures is empty`, bộ giám sát sẽ ghi nhận và **thay kết nối lỗi**. Đừng nhầm thông báo **ONLINE** của Supabase với việc robot đã sẵn sàng chạy: sau ngắt mạng phải xem `STOP`, quyền điều khiển và trạng thái phần cứng trên app.

## Kiểm tra mạng 4G (không điều khiển cơ khí)

```bash
ping -c 20 1.1.1.1
python3 -m pip show supabase realtime
```

Ping không chứng minh WebSocket đã kết nối; hãy quan sát dòng `[Realtime] ONLINE` và `Robot online` trên Vercel. Muốn đánh giá độ ổn định phải đo thực tế bằng cả Wi-Fi và 4G, không chỉ số Mbps.

## Kiểm thử offline (không mở USB, không gọi Modal)

```bash
python3 -m pip install -r python/requirements-test.txt
PYTHONPATH=python python3 -m pytest -q tests/test_realtime_supervisor_v31639.py tests/test_realtime.py tests/test_control.py
```

Các bài test mô phỏng lỗi kênh, reconnect thất bại, mất ACK, callback phiên cũ, lệnh STOP và idempotency. Test giả lập **không thay thế được chạy thử trên Jetson/4G thực tế**.

## Khôi phục về bản cũ

Nếu phiên bản mới có vấn đề, STOP robot và tắt ứng dụng Python, rồi chạy lại thư mục V3.16.38 đã giữ. Không cần cập nhật firmware hoặc Vercel. Không chạy cùng lúc hai phiên Python điều khiển chung cổng Arduino.

## Files thay đổi so với V3.16.38

- `python/realtime_supervisor.py` — mới: quản lý phiên Supabase, timeout, backoff, kết nối mới và bắt lỗi async `_reconnect`.
- `python/main.py` — khởi tạo supervisor, giữ đầy đủ camera/Modal/AUTO/LiveKit và khởi động lại cấu hình từ Vercel khi mất mạng.
- `python/realtime_bridge.py` — timeout gửi Broadcast, cập nhật tín hiệu thành công và thông báo lỗi mạng, giữ nguyên dispatcher & kiểm tra TTL/epoch.
- `tests/test_realtime_supervisor_v31639.py` — mới: thử ngắt kết nối và khôi phục mô phỏng.
- `python/requirements-test.txt` — bổ sung thư viện kiểm thử bất đồng bộ.

Không có thay đổi sơ đồ đấu dây, xung servo, hay thuật toán AUTO. Không hứa loại bỏ tuyệt đối lỗi khi nhà mạng/Cloud mất kết nối; mục tiêu là *khôi phục điều khiển khi mạng trở lại, không treo Python vì lỗi Realtime, và dừng an toàn khi mất liên lạc*.
