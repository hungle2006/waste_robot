# Waste Robot V3.16.15 – AUTO quét phải / xử lý rơi rác / quyền đổi quà D18

Bản này kế thừa **V3.16.14 căn ngang x2**, không thay đổi tham số `FORWARD_MS=400`, các giá trị `lateral_ms` (160/120/120/120), servo gắp D3=2300 us, PWM20, hoặc firmware.

## 1. Bỏ bộ đếm số nhịp tiến
- `robot_params.py`: `STAGE_TIMING[].max_forward_steps=None`, `AUTO_CONFIG['approach']['max_forward_steps']=None`, `AUTO_CONFIG['box_tof_flow']['max_forward_steps']=None`, `max_tof_pulses=None`, `max_final_pulses=None`.
- `auto_controller.py`, `pose_profile.py`, `box_tof_flow.py`: `None` nghĩa là không áp dụng **giới hạn số nhịp**. Bộ đếm vẫn dùng để báo trạng thái.
- **KHÔNG bỏ các chặn an toàn:** VL53 <200mm, dải VL53 200–250mm, D19, kiểm tra vật/ảnh, không tiến triển, STOP/USB; thời gian VL53 tối đa 45s và IR cuối tối đa 15s. Giới hạn thời gian chu trình 1200s vẫn giữ nguyên.
- Giới hạn căn ngang 25 nhịp, số bước hạ tay và nhịp cơ khí *đơn lẻ* vẫn giữ nguyên.

## 2. AUTO tự tìm rác bằng quay phải
- Khi bắt đầu AUTO và đã ở SEARCH, nhận diện camera trả về ảnh mới không có rác: quay `TURN_RIGHT` tại chỗ **khoảng 5.04s** (9 nhịp ramp tối đa 560ms), dừng **1s** rồi lấy ảnh mới.
- 30 lần không thấy rác => dừng bánh bằng `XM`, nhả quyền AUTO và hiển thị `auto_search_exhausted`. Không STOP ngắt toàn hệ thống.
- Nếu đã thấy rác nhưng đang xác nhận nhãn/BIN, không quay; chờ khung hình tiếp theo. Lỗi camera/AI 3 lần => HOLD, không quay mù.
- `robot_params.py`: `AUTO_SEARCH_TURN_SECONDS=5.0`, `AUTO_SEARCH_STOP_SECONDS=1.0`, `AUTO_SEARCH_MAX_TURNS=30`.
- **Quan trọng:** 5s là thời gian quay, KHÔNG có encoder/góc phản hồi để bảo đảm mỗi lần quay đúng 360 độ. Cần hiệu chuẩn thực nghiệm nếu muốn một vòng chính xác.

## 3. Khi D19 mất tín hiệu lúc gắp/nâng/đưa đi thả
- D19 không đọc được vật trong 3 lần kiểm tra lại (mỗi lần 100ms): phát `LostGrip` thay vì mặc định dừng lỗi.
- Không ghi hoàn thành chu trình, không mở kẹp để thả (nếu chưa mở), không cấp quyền đổi quà; dừng bánh, thu tay theo quỹ đạo về SEARCH, bảo đảm tay ra khỏi vùng nắp, đóng nắp rồi mở kẹp ở SEARCH.
- Quay về tìm rác mới nếu phục hồi cơ khí hợp lệ; nếu tư thế không xác định/USB lỗi vẫn phải STOP an toàn.
- Không có cảm biến lực, **D19 chỉ đo sự hiện diện**, không chắc chắn phân biệt rác tuột khỏi tay hay cảm biến bị lệch. Kiểm tra thực tế trước khi dùng không giám sát.

## 4. D18 và nút ĐỔI QUÀ chỉ có 120 giây
- Khi D18 phát hiện người đưa rác vào phía sau, camera nhận diện vật ổn định, xoay đúng BIN, mở nắp, D18 hết phát hiện ổn định và nắp đã đóng, hoàn tất tư thế SEARCH => cấp 120s đổi quà.
- Nút trong `web/operator.html` chỉ cho phép khi kết nối hợp lệ, chưa STOP, quyền còn hạn, chưa đổi, không bận. Hiển thị số giây còn lại.
- Lệnh `GIFT DISPENSE` ở `gift_control.py` cũng **kiểm tra quyền phía server**. Sau 120s bị từ chối. Sau một lần đổi, quyền được tiêu thụ tức thì; nhấn lặp không phát quà. Lượt D18 hợp lệ tiếp theo mở cửa sổ 120s mới.
- STOP/mất kết nối hủy quyền còn hạn. D18 chỉ xác nhận trình tự đưa vật ra khỏi sensor, không trực tiếp đo vật đã rơi xuống đáy thùng; muốn xác thực vật vào thùng tuyệt đối cần bổ sung cảm biến bên trong.
- `robot_params.py`: `GIFT_CLAIM_SECONDS=120`.

## 5. File thay đổi
- `python/robot_params.py`: thông số quét, forward unbounded, thời gian đổi quà.
- `python/auto_controller.py`: quét phải, hết 30 lần tự tắt AUTO, phục hồi khi D19 mất vật, cấp thưởng sau REAR hoàn tất.
- `python/box_tof_flow.py`: bỏ giới hạn đếm FORWARD/ToF/IR, vẫn kiểm tra cảm biến và timeout.
- `python/pose_profile.py`: hỗ trợ max_forward_steps=None.
- `python/gift_control.py`: entitlement 120s, tiêu thụ một lần, hết hạn server-side.
- `web/operator.html`: vô hiệu hóa nút đổi quà khi chưa đủ điều kiện.
- `tests`: cập nhật kiểm thử quà theo yêu cầu và kiểm thử bổ sung.

## Chạy và thử an toàn
1. Giải nén. Kiểm tra nguồn, nút STOP và bánh mecanum quay phải đúng chiều `TURN_RIGHT`.
2. Cài dependencies theo hướng dẫn cũ, chạy `python/main.py` như V3.16.14. Chưa cần đổi sketch Arduino nếu firmware đang là V3.16.14 tương thích với VL53 và D4.
3. Test đầu tiên đặt robot trong khu vực TRỐNG, kê bánh lên khỏi mặt đất nếu được. Kiểm tra chiều quay, 5s/1s, nút STOP khi đang quay.
4. Thử vật rơi chủ động khi tay nâng để xác nhận robot rút an toàn; tránh khu vực có người sát tay/nắp.
5. Thử cảm biến D18 và quy trình phân loại, nút đổi quà trong 120s; thử nhấn lặp và hết hạn.

Không có kiểm định trên robot thực tế. Cần giám sát trong lần vận hành đầu tiên.
