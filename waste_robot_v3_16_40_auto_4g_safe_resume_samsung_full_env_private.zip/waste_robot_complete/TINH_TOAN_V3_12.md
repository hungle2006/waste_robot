# Tính toán và đối chiếu dữ liệu V3.12

## Định nghĩa và nguồn ảnh

Các số mới60/75/90/45/24/12/5 cm đo từ **ống kính → chai**, theo xác nhận của
người dùng. Mốc **S2 chiếu xuống đất → chai =27 cm** thuộc ảnh gắp trước
`WIN_20261016_00_22_10_Pro.jpg` tại cùng cặp xung2310/650. Hai số khác gốc đo.
Không trừ27−5 để tuyên bố độ vươn camera: còn khác điểm đo trên chai và hình học.

Bảy ảnh USB gốc1920×1080 nằm trong `calibration_reference`.
`usb_measurements_v312.json` lưu tên ảnh, số đo, chất lượng và SHA-256.

| Ảnh | Tên rút gọn | P1/P10 µs | cm ống kính | Box đọc bằng mắt [x1,y1,x2,y2] | Chất lượng |
|---|---|---|---:|---|---|
| 1 | 00_50_07 | 1300/950 | 60 | [942,540,1052,751] | Dưới chai bị gá che |
| 2 | 00_50_48 | 1300/950 | 75 | [947,402,1046,621] | Đủ chai; mốc SEARCH |
| 3 | 00_52_00 | 1300/950 | 90 | [974,285,1055,448] | Đủ chai |
| 4 | 00_55_48 | 1550/876 | 45 | [918,28,1075,454] | Đầu chai gần mép trên |
| 7 | 01_19_13 | 1800/801 | 24 | [947,28,1202,790] | Đầu chai gần mép trên |
| 5 | 01_03_16 | 2050/727 | 12 | [780,0,1240,755] | Cắt đầu chai |
| 6 | 01_05_13 | 2310/650 | 5 | [260,0,1450,900] | Cắt đầu và che dưới |

Đây là chú giải thủ công sơ bộ, chưa được detector/đo kiểm xác nhận. Sai số
đọc ước chừng±25 px, ảnh gần±40 px; không phải khoảng tin cậy thống kê. Ảnh6
có chai nghiêng và che khuất, tâm bbox không nhất thiết là điểm kẹp hay tâm
vật thật. Không biến chiều cao box bị cắt thành khoảng cách hay gắp chỉ theo box.

Không dùng pixel ảnh chụp robot từ bên ngoài thay cho pixel camera USB.

## Nội suy P1/P10

Với hai mốc lân cận `(a,A)` và `(b,B)`, lệnh P10 tại P1=p:

`P10(p) = round(A + (B−A) × (p−a)/(b−a))`.

| P1 | Công thức trước làm tròn | dP10/dP1 |
|---|---|---:|
| 1300–1550 | 950 −74×(p−1300)/250 | −0.296 |
| 1550–1800 | 876 −75×(p−1550)/250 | −0.300 |
| 1800–2050 | 801 −74×(p−1800)/250 | −0.296 |
| 2050–2310 | 727 −77×(p−2050)/260 | −0.296153846 |

Hạ mặc định1350,1400,…,2300,2310 µs:21 bước, bước cuối10 µs. Nếu đổi bước,
bộ điều khiển vẫn dừng đúng mốc trung gian. P11=1250, D2=2100 giữ nguyên.
Nâng/rút trước REAR dùng cùng công thức theo P1 đang có.

Đây là lệnh PWM µs, không phải góc khớp. Chưa có đo góc/chiều dài khâu đủ tin
cậy để giải động học nghịch hoặc xác nhận đường đi thẳng theo cm. Góc195°,
90°,60° cũ chưa thống nhất hệ quy chiếu nên chỉ giữ tham khảo.

Khoảng ống kính tham chiếu75→45→24→12→5 cm cũng nội suy từng đoạn, có độ dốc
−0.12, −0.084, −0.048, −0.026923077 cm/µs. **Đây là lịch tham chiếu ảnh khi cả
xe và tay đổi vị trí, không đo khoảng cách chai hiện tại từ P1.** AUTO dùng
phản hồi ảnh, không dừng bánh vì lịch này hiển thị5 hoặc27 cm.

## Pixel theo từng tư thế

Chuẩn hóa `x_n=x/1920`, `y_n=y/1080`. Ở640×360 cùng FOV/crop, pixel bằng ảnh
gốc chia3. Không kéo ảnh4:3 thành16:9. Nếu driver đổi crop/FOV dù cùng tỷ lệ,
các mốc vẫn cần kiểm tra lại.

| Mốc | Tâm ngang chuẩn hóa | Đáy nhìn thấy chuẩn hóa | Tâm ngang / đáy ở640×360 |
|---|---:|---:|---|
| SEARCH75 | 0.5190 | 0.5750 | 332.2 /207.0 px |
| 1550/876 | 0.5190 | 0.4204 | 332.2 /151.3 px |
| 1800/801 | 0.5596 | 0.7315 | 358.2 /263.3 px |
| 2050/727 | 0.5260 | 0.6991 | 336.7 /251.7 px |
| 2310/650 | 0.4453 | 0.8333 | 285.0 /300.0 px |

Vùng mục tiêu nội suy giữa hai ảnh theo P1. Đây là đường tham chiếu theo ảnh,
chưa đo trực tiếp các tư thế giữa hai ảnh. Dung sai ngang±0.06, đáy±0.07; ảnh
cuối±0.09 và±0.10 do cắt/che. Cần ít nhất hai ảnh mới ổn định và giữ cùng vật.

Tại SEARCH, ba ảnh có đỉnh chai y=540/402/285 tương ứng60/75/90 cm. Chương trình
tra tuyến tính từng đoạn để hiển thị ước lượng cho cùng chai/thế đặt, chỉ
trong miền này, không ngoại suy. Độ dốc−15/138 và−15/117 cm/pixel gốc. Sai số
chú giải25 px đã tương đương2.7–3.2 cm, chưa tính camera/vật/phép đo. Đây là
tra thực nghiệm, không là đo sâu hoặc khoảng S2; không dùng nó điều khiển AUTO.
Giá trị tự xóa khỏi trạng thái khi rời bước quan sát.

Mỗi tư thế hạ chỉ có một ảnh/một khoảng cách, không đủ xác định ánh xạ pixel→cm
tùy ý. Không suy tiêu cự từ chiều dài chai chưa biết hoặc bbox bị cắt.

## Ma trận giấy17×17 cm đã tìm lại và tính lại

Góc sơ bộ ở SEARCH: (816,606),(1007,594),(1050,711),(838,737), gán lần lượt
(0,0),(17,0),(17,17),(0,17) cm. Giải lại8 ẩn homography cho kết quả trùng dữ
liệu cũ trong sai số<10⁻¹²:

```text
H_pixel_to_paper_cm =
[[ 0.1235603893, -0.0207505997,  -88.2504142051],
 [ 0.0140319213,  0.2233414145, -146.7949450063],
 [-0.0005816990,  0.0016644035,    1.0000000000]]
```

Tính `[u,v,w]ᵀ=H[x,y,1]ᵀ`, rồi `X=u/w`, `Y=v/w`. Gốc là góc giấy, chưa phải
S2. Với640×360 cùng góc nhìn: `H_runtime=H × diag(3,3,1)`.

Tại điểm trung bình bốn góc(927.75,662), tỉ lệ cục bộ theo hướng ảnh x/y là
**0.08303 /0.13516 cm/pixel gốc**, tương ứng0.24910 /0.40547 cm/pixel ở640×360.
Các cạnh giấy cho7.33–12.56 pixel/cm do phối cảnh; không có một hệ số duy nhất
cho cả ảnh. Các số này thuộc mặt phẳng giấy, vùng giấy và tư thế SEARCH.

Số cũ ống kính–giấy92–93 cm, camera cao64 cm, nếu tới cùng điểm trên sàn, cho
khoảng ngang66.09–67.48 cm từ hình chiếu **camera**, không phải từ S2. Không
ghép cao64 với khoảng mới60 cm nếu điểm đo ở trên mặt chai hoặc cách đặt
camera khác, rồi ép các gốc đo khác nhau thành một mô hình.

H là phép biến đổi mặt phẳng, **không phải ma trận nội tại K của camera**.
Một tờ vuông ở một góc nhìn chưa xác định đủ K, méo ống kính và ngoại tại cả
năm tư thế. Camera trên tay đổi ngoại tại khi hạ. Bản này giữ H để truy vết/
kiểm tra ở SEARCH, không áp sang ảnh hạ; `distance.enabled=False` vẫn cho phép
AUTO theo ảnh chạy đầy đủ.

Kiểm tra bằng `python analyze_measurements.py`, thêm `--json` để xem dữ liệu
có cấu trúc. Công cụ không sửa thông số hoặc phát lệnh robot.

## Thời gian và cách đo kiểm

`STAGE_TIMING` có tiến/lùi/ngang, nghỉ và nhịp servo theo từng đoạn. Chưa đo
vận tốc bánh trên sàn, nên đây là thời gian khởi đầu để thử. Có ramp tăng/
giảm tốc: thời gian thực thi dài hơn danh định. Không tự quy ra cm.

Ở cùng tư thế: sai ngang thì căn ngang; đáy cao hơn vùng thì tiến; đáy vượt
vùng thì lùi. Phải lấy ảnh mới sau mỗi nhịp, cùng vật/cùng tư thế và sai lệch
giảm. Đi ngược mục tiêu rõ rệt thì giữ ngay; không tiến triển4 lần thì giữ.
Có thêm giới hạn tổng số nhịp từng chiều/đoạn. Nếu hướng camera/bánh khác giả
định, giữ để chỉnh, không tự đổi chiều thiếu dữ liệu.

P1≥2260: bánh tắt. Ở2310/650 cần ảnh gần ổn định +D19 ổn định mới gắp. Nếu chưa
đủ ảnh/IR thì giữ, không hạ thêm. Đây là kiểm tra phản hồi, không phải lỗi
thiếu dữ liệu cấu hình.

Khi thử thật, ghi P1/P10, chiều, ms danh định, ảnh trước/sau và quãng bánh nếu
muốn đo vận tốc. Chỉnh một trường trong `STAGE_TIMING`, STOP/chạy lại rồi so
ảnh. Đo thêm giúp kiểm chứng; không có bước bắt buộc ghi tệp hiệu chuẩn mới
để khởi động bản hiện tại.

## Nguồn kỹ thuật và phần suy luận

- OpenCV: [Homography tutorial](https://docs.opencv.org/4.13.0/d9/dab/tutorial_homography.html),
  phép biến đổi mặt phẳng/ảnh; tính pose cần nội tại camera đã biết.
- OpenCV: [Perspective-n-Point](https://docs.opencv.org/4.13.0/d5/d1f/calib3d_solvePnP.html),
  mô hình dùng điểm3D/2D, K và méo; không thay thế số đo cơ khí chưa có.
- Espiau, Chaumette &Rives: [A New Approach to Visual Servoing in Robotics](https://www-sop.inria.fr/members/Patrick.Rives/Publications/ITRA-espiau-chaumette-rives-92.pdf),
  IEEE Transactions on Robotics and Automation1992, cơ sở dùng đặc trưng ảnh
  làm phản hồi điều khiển.

Chọn ảnh75 cm, chú giải box, dung sai, nội suy vùng ảnh và nhịp bánh là quyết
định triển khai từ số đo/ảnh của bạn, chưa đo kiểm trên robot thật. Nguồn tài
liệu không chứng nhận các giá trị cụ thể này.
