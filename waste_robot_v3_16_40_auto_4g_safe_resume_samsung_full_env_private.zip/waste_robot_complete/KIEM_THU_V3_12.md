# Kiểm thử V3.12

## Kết quả

282 ca trong lần hồi quy đầy đủ đạt, thời gian442.85 giây. Sau đó bổ sung
một ca D18 riêng cho nhánh điều khiển theo mốc ảnh; ca này cũng đạt. Tổng
283 ca khác nhau đạt. Nhật ký nằm trong `tests/RESULTS_V3_12.txt`.

Có một cảnh báo deprecation từ Starlette/httpx ở môi trường chạy kiểm thử;
không có ca lỗi. Không thay phụ thuộc chỉ để xóa cảnh báo này.

## Nội dung đã xác minh

- Năm cặp P1/P10 khớp đúng các mốc1300/950,1550/876,1800/801,2050/727,2310/650.
- Các khoảng ống kính60/75/90/45/24/12/5 cm và S2=27 cm được lưu tách biệt.
- Nội suy từng đoạn, số bước và quỹ đạo nâng/rút ngược giữ P11/D2.
- Bánh tiến/lùi theo ảnh, chỉ khi tay đứng yên; sai chiều hoặc không cải thiện
  thì giữ. Có kiểm tra mất vật, che ngang/đáy, IR sớm và sai vùng ở tư thế cuối.
- Không tự chạy bánh ở mốc cuối. Ảnh ổn định và D19 cùng cần thiết để đóng kẹp.
- STOP khi đang nhích bánh chặn lệnh đến muộn. D18 giữa nhận diện tại tư thế
  trung gian hủy chờ ảnh, rút cả P1/P10 rồi chuyển REAR.
- Hướng dẫn ảnh đổi theo tư thế; ảnh gốc đưa nhận diện không bị vẽ đè.
- Các ca cũ cho MANUAL, realtime, kẹp/nắp/BIN, khóa mục tiêu, D18, D19, ảnh
  cũ/mất kết nối và thời gian chờ vẫn đạt.
- Firmware được biên dịch/chạy harness C++ trên host trong bộ kiểm thử.
  Các tệp Arduino giữ nguyên byte so với V3.11.1.
- `.env` giữ nguyên byte từ bộ gốc đã được người dùng yêu cầu đóng kèm.
- Ma trận giấy tính lại từ bốn góc lệch<10⁻¹² so với ma trận đã truy lại.

`python demo_auto.py` đã chạy thành công với đủ21 bước hạ theo năm mốc thật,
ảnh/D19 giả lập, nâng ngược, mở nắp và thả mô phỏng: `auto_done`,1 chu trình,
`released=True`. Nhật ký ở `tests/OFFLINE_DEMO_V3_12.txt`.

## Chạy lại

Từ thư mục gốc bộ mã, sau khi cài phụ thuộc runtime và pytest:

```bash
python -m pytest -q tests
```

Cần g++ để chạy ca firmware host. Từ thư mục `python` có thể chạy kiểm tra
offline nhẹ hơn, không cần pytest/g++, camera hoặc tài khoản:

```bash
python check_system.py
python analyze_measurements.py
python demo_auto.py
```

## Giới hạn kết quả

Chưa có kết nối vật lý tới robot/camera/tài khoản của người dùng trong lần
kiểm thử này. Không xác nhận độ chính xác detector ngoài thực tế, giao tiếp
USB trên máy người dùng, phản ứng cơ khí, độ trượt bánh hoặc khoảng dừng.
Vùng ảnh và thời gian trong `robot_params.py` là thông số khởi đầu theo số
đo/ảnh hiện có; không là chứng nhận hiệu chuẩn camera hoặc góc khớp.
